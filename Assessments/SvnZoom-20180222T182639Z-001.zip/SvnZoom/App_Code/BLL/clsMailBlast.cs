﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for clsMailBlast
/// </summary>
public class clsMailBlast : BaseClass
{
	public clsMailBlast()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public DataTable GetEmailBlast()
    {
        try
        {
            string SQLQuery = "select * from tbl_sendingmaildetails";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}