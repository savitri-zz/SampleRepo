﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for clsbit2byteadmin
/// </summary>
public class clsbit2byteadmin : BaseClass
{
    public clsbit2byteadmin()
    {
        //
        // TODO: Add constructor logic here
        //
    }
   public DataTable AdminLogin(string username, string password)
    {
        try
        {
            string SQLQuery = "select * from tbl_admindetails where username='" + username + "' and pwd='" + password + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
   public DataTable getreferalid_binary123(string userid, string date)
   {
       try
       {
           string SQLQuery = "SELECT * FROM tbl_invitefriends where inivted_user = '" + userid + "' and CAST(invited_date as DATE) <=  '" + date + "'";
           return GetDataTable(SQLQuery, true);
       }
       catch (Exception Ex)
       {
           throw Ex;
       }
   }


   public DataTable Getpersonalcommisionday(string refid, string inviteddate)
   {
       try
       {
           string SQLQuery = "select * from tbl_registration where referid='" + refid + "'  and CAST(joindate as DATE) =  '" + inviteddate + "'";
           return GetDataTable(SQLQuery, true);
       }
       catch (Exception Ex)
       {
           throw Ex;
       }
   }

   public DataTable getreferalid_binary234(string userid, string date, string date1)
   {
       try
       {
           string SQLQuery = "SELECT * FROM tbl_invitefriends where inivted_user = '" + userid + "' and CAST(invited_date as DATE) between  '" + date + "' and '" + date1 + "'";
           return GetDataTable(SQLQuery, true);
       }
       catch (Exception Ex)
       {
           throw Ex;
       }
   }
   public DataTable invitbetweendates(string userid, string date, string date1)
   {
       try
       {
           string SQLQuery = "SELECT * FROM tbl_registration where userid = '" + userid + "' and CAST(joindate as DATE) between  '" + date + "' and '" + date1 + "'";
           return GetDataTable(SQLQuery, true);
       }
       catch (Exception Ex)
       {
           throw Ex;
       }
   }

   public DataTable invitbetweendates1(string userid, string date)
   {
       try
       {
           string SQLQuery = "SELECT * FROM tbl_registration where userid = '" + userid + "' and CAST(joindate as DATE) <= '" + date + "'";
           return GetDataTable(SQLQuery, true);
       }
       catch (Exception Ex)
       {
           throw Ex;
       }
   }
    
    
    public void updateadmindetails(string userid, string password)
    {
        try
        {

            string SQLQuery = "update tbl_admindetails set pwd='" + password + "' where admin_userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getmemregistrations()
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where sno > 1";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getmemregistrationsponceruserid(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno = '" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void InsertSpotBonusAmtuser(string userid, string mobileno, string name, string SpotBounusAmt, string date)
    {
        try
        {
            string SQLQuery = "insert into tbl_Data_SpotBonusAmt(userid, mobileno, name, SpotBounusAmt, date) values ('" + userid + "', '" + mobileno + "', '" + name + "', '" + SpotBounusAmt + "', '" + date + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getfreememregistrationsponceruserid(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where mobileno = '" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getreferalid(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getProductsname(string sno)
    {
        try
        {
            string SQLQuery = "select * from tbl_Products where sno = '" + sno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getreferedname(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getreferedname1(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    

    public DataTable GetmemPersonalAmtCV(string refid, string dates)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + refid + "' and CAST(joindate as DATE) = '" + dates.ToString() + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetmemPlacementid(string refid, string placement, string dates)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid = '" + refid + "' and placement = '" + placement + "' and CAST(joindate as DATE) <= '"+dates.ToString()+"'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable getreferedname11(string referid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid = '" + referid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getreferedname111(string referal_id)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where referal_id = '" + referal_id + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
   
    public DataTable getnonmemreferedname(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable refredmemcount(string userid, string joindate)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user = '" + userid + "' and CAST(invited_date as DATE) <= '" + joindate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getpaidmemreferedname(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getbetweenmem(string from, string to)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where joindate between '" + from + "' and  '" + to + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getmemdetails(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where sno = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getpaidmemdetails(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where sno = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getpaidmemdetails1(string sno)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where sno = '" + sno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getnonmemdetails(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where sno = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getdatapayout1(string date)
    {
        try
        {
            string SQLQuery = "SELECT *  FROM tbl_invitefriends WHERE CAST(invited_date as DATE) <=  '" + date + "' order by sno ASC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getusersno(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getuserpayout(string fromdate, string todate)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where joindate like '" + fromdate + "%' and '" + todate + "%' order by sno ASC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getuserpayout1(string date)
    {
        try
        {
            string SQLQuery = "SELECT *  FROM tbl_registration WHERE CAST(joindate as DATE) <=  '" + date + "' order by sno ASC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetUserstatustype()
    {
        try
        {
            string SQLQuery = "SELECT *  FROM tbl_Accountsms";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetUserstatustype1(string sno)
    {
        try
        {
            string SQLQuery = "SELECT *  FROM tbl_Accountsms where sno='" + sno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    
    public DataTable Getmemregisterddetails(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration reg , tbl_editprofile edp where reg.userid = edp.userid and reg.userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void EditUpadateRegister(string fullname, string gender, string state, string city, string mobileno, string email, string sno)
    {
        try
        {
            //string SQLQuery = "update tbl_registration set fullname = '" + fullname + "', usertype = '" + gender + "', state = '" + state + "',city = '" + city + "', mobileno = '" + mobileno + "', emailid = '" + email + "' where sno='" + sno + "'";
            string SQLQuery = " USP_EditUpadateRegister '" + fullname + "', '" + gender + "', '" + state + "','" + city + "','" + mobileno + "','" + email + "' ,'" + sno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void EditUpadateRegister1(string address, string country, string district, string postalcode, string dob, string userid)
    {
        try
        {
            string SQLQuery = "update tbl_editprofile set address = '" + address + "', country = '" + country + "', district = '" + district + "', postalcode = '" + postalcode + "', dob = '" + dob + "' where userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getnewsupdates()
    {
        try
        {
            string SQLQuery = "select * from add_news";
            return GetDataTable(SQLQuery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

     }

    public DataTable GetCreditwalletamount()
    {
        try
        {
            string SQLQuery = "select * from tbl_creditwallet";
            return GetDataTable(SQLQuery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable GetAlluserdetails()
    {
        try
        {
            string SQLQuery = "select * from tbl_registration";
            return GetDataTable(SQLQuery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetAlluserdetails1()
    {
        try
        {
            string SQLQuery = "select * from tbl_registration order by sno DESC";
            return GetDataTable(SQLQuery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
     public DataTable getuseradmin(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_admindetails where admin_userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

     }
     public DataTable freemember()
     {
         try
         {
             string SQLQuery = "select * from tbl_freememreg where userid";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }
     public DataTable freemember(string userid)
     {
         try
         {
             string SQLQuery = "select * from tbl_freememreg where userid='" + userid + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }
     public DataTable freemember1()
     {
         try
         {
             string SQLQuery = "select * from tbl_freememreg order by sno DESC";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }
     public DataTable paidmembers(string userid)
     {
         try
         {
             string SQLQuery = "select * from tbl_registration where userid='" + userid + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }
     


     public DataTable paidmembers1()
     {
         try
         {
             string SQLQuery = "select * from tbl_registration order by sno DESC";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }

     public DataTable paidmembers3()
     {
         try
         {
             string SQLQuery = "select * from tbl_registration order by cast(joindate as datetime) DESC";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }

     public DataTable paidmembers2()
     {
         try
         {
             string SQLQuery = "select * from tbl_registration order by cast(joindate as date) DESC";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }

    public DataTable nonmembers(string userid)
     {
         try
         {
             string SQLQuery = "select * from tbl_invitefriends where userid='" + userid + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }

     public DataTable nonmembers1()
     {
         try
         {
             string SQLQuery = "select * from tbl_invitefriends ";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }
    public void Adminchngepwd(string userid, string pwd)
    {
        try
        {
            //string SQLQuery = "update tbl_admindetails set pwd = '" + pwd + "' where admin_userid=" + userid + "";
            string SQLQuery = "USP_Adminchngepwd '" + pwd + "'," + userid + "";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable countinvite(string mobileno)
    {
        try
        {
            string SQLQuery = "Select count(mobileno) as mobileno from tbl_invitecount where mobileno='" + mobileno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void updatenews(int sno, string newstype, string description)
    {
        try
        {

            //string SQLQuery = "update add_news set newstype='" + newstype + "', description='" + description + "' where sno='" + sno + "'";
            string SQLQuery = "USP_updatenews '" + newstype + "','" + description + "','" + sno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery , true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

   

    public void updateAlluserdetails(string fullname, string mobileno, string Password, string emailid, string referid, string state, string city, string userid)
    {
        try
        {

            string SQLQuery = "update tbl_registration set fullname='" + fullname + "', mobileno='" + mobileno + "',  Password='" + Password + "',  emailid='" + emailid + "',  referid='" + referid + "', state='" + state + "',  city='" + city + "' where sno='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
   

    public void updatefreeuserdetails(string name, string mobileno, string userpwd, string emailid, string referal_id, string state, string city, string userid)
    {
        try
        {

            string SQLQuery = "update tbl_freememreg set name='" + name + "', mobileno='" + mobileno + "', userpwd='" + userpwd + "', emailid='" + emailid + "', referal_id='" + referal_id + "', state='" + state + "', city='" + city + "' where sno='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatenonuserdetails(string fname, string mobileno, string emailid, string inivted_user, string state, string city, string userid)
    {
        try
        {

            string SQLQuery = "update tbl_invitefriends set fname='" + fname + "', mobileno='" + mobileno + "', emailid='" + emailid + "', inivted_user='" + inivted_user + "', state='" + state + "', city='" + city + "' where sno='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Deleterow(int sno)
    {
        try
        {
            //string SQLQuery = "delete from add_news where sno='" + sno + "'";
            string SQLQuery = " USP_Deleterow '" + sno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable viewpassword()
    {
        try
        {
            string SQLQuery = "select sno,mobileno,password,fullname,emailid  from tbl_registration";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
       }

     }

    public DataTable alluserdetails()
    {
        try
        {
            string SQLQuery = "select *  from tbl_registration";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable totalusers()
    {
        try
        {
            string SQLQuery = "select * from tbl_registration";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable searchuid(string userid)
    {
        try
        {
            
            string SQLQuery = "select *  from tbl_freememreg where userid= '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable searchfreemem(string name)
    {
        try
        {
            string SQLQuery = "select *  from tbl_freememreg where mobileno LIKE '" + name + "%' or name LIKE '" + name + "%' or userid LIKE '" + name + "%' ";
            
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable searchufreedate(string fromdate, string todate)
    {
        try
        {
            string SQLQuery = "select *  from tbl_freememreg where joindate BETWEEN '" + fromdate + "' AND  '" + todate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable searchuid2(string userid)
    {
        try
        {
            string SQLQuery = "select *  from tbl_registration where userid= '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable searchuid1(string uid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration WHERE userid  IN (" + uid.ToString() + ")";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable betweenjoiningmembers(string fromdate, string todate)
    {
        try
        {
            string SQLQuery = "select fullname,SponsorUserID,password,mobileno ,producttype from tbl_registration where joindate BETWEEN '" + fromdate + "' AND  '" + todate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable totalinvites()
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable updateaccount(string accno)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where AccountNo != ''";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable notupdateaccount(string accno)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where AccountNo = ''";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable invites()
    {
        try
        {
            string SQLQuery = "select * from tbl_registration";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable searchmemb(string state, string city)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where state = '"+state+"' and city = '"+city+"'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getAccountno1(string transactionid)
    {
        try
        {
            string SQLQuery = "select * from tbl_regtransactionDetails where transactionid = '" + transactionid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getAccountholdername(string Name)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration where account_no = '" + Name + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

   public DataTable searchmemb1(string state, string city)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where state = '" + state + "' and city = '" + city + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable alluserdetails2(string state, string city)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration , tbl_freememreg where state = '" + state + "' and city = '" + city + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable todaydate( string todaydate)
    {
        try
        {
            string SQLQuery = "select fullname,SponsorUserID, mobileno ,producttype, password from tbl_registration where joindate='" + todaydate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable getlaststate()
    {
        try
        {
            string SQLQuery = "select * from tbl_indianstates order by id desc ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getlastdist(string x)
    {
        try
        {
            string SQLQuery = "select * from tbl_district order by sno desc where id=x";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getlastcity()
    {
        try
        {
            string SQLQuery = "select * from tbl_cities order by cityid desc";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Addstates(string states)
    {

        try
        {
            //string SQLQuery = "select * from tbl_indianstates where states='" + states + "'";
            string SQLQuery = " USP_Addstates '" + states + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getstates(string id )
    {

        try
        {
            string SQLQuery = "select * from tbl_indianstates where id='" + id + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Adddistics(string District)
    {

        try
        {
            //string SQLQuery = "select * from tbl_district where District='" + District + "'";
            string SQLQuery = "USP_Adddistics'" + District + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable Addcity(string cityname)
    {

        try
        {
            //string SQLQuery = "select * from tbl_cities where cityname='" + cityname + "'";
            string SQLQuery = " USP_Addcity '" + cityname + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getcity(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_cities where cityid='" + id + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getcities()
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getddlcities()
    {
        try
        {
            string SQLQuery = "select * from tbl_cities";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Insertnewstates(string states, int id)
    {
        try
        {
            //string SQLQuery = "insert into tbl_indianstates(id, states) values (" + id + ",'" + states + "')";
            string SQLQuery = " USP_Insertnewstates " + id + ",'" + states + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Insertnewdist(int sno, int id, string District)
    {
        try
        {
            //string SQLQuery = "insert into tbl_district(sno, id, District) values (" + sno + "," + id + ",'" + District + "')";
            string SQLQuery = " USP_Insertnewdist " + sno + "," + id + ",'" + District + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Insertnewcity(int cityid, int stateid, string cityname)
    {
        try
        {
            //string SQLQuery = "insert into tbl_cities(cityid, stateid, cityname) values (" + cityid + "," + stateid + ",'" + cityname + "')";
            string SQLQuery = " USP_Insertnewcity " + cityid + "," + stateid + ",'" + cityname + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertBulkSMS(string mobileno, string message, string date)
    {
        try
        {
            string SQLQuery = "insert into tbl_bulksms(mobileno, message, date) values ('" + mobileno + "','" + StringValidation.checkStringOrigFormat(message) + "','" + date + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    
    public DataTable Getsmsdate(string date)
    {
        try
        {
            string SQLQuery = "SELECT *  FROM tbl_bulksms where date like '" + date + "%'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetallBulkSMS()
    {
        try
        {
            string SQLQuery = "select * from tbl_bulksms";
            return GetDataTable(SQLQuery, true);
            
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void addNews(string newstype, string description)
    {
        try
        {
            //string SQLQuery = "insert into add_news(newstype, description) values ('" + newstype + "', '" + description + "')";
            string SQLQuery = " USP_addNews'" + newstype + "', '" + description + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getddldistricts(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_district where id =" + id;

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddldistrict1()
    {
        try
        {
            string SQLQuery = "select * from tbl_district";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddlstates()
    {
        try
        {
            string SQLQuery = "select * from tbl_indianstates";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getddlcity(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_cities where stateid =" + id;

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void EditUpadatePwd(string txt_newpwd, string txt_oldpwd)
    {
        while (txt_oldpwd != txt_newpwd)
        {
            //string SQLQuery = "update tbl_registration set password = '" + txt_newpwd + "' where password='" + txt_oldpwd + "'";
            string SQLQuery = " USP_EditUpadatePwd '" + txt_newpwd + "','" + txt_oldpwd + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
            return;

        }

    }

    public DataTable acceptinvetation(string uid)
    {
        try
        {
            string SQLQuery = "select count(*) from tbl_invitefriends a inner join tbl_registration b on a.mobileno= b.mobileno where userid='" + uid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    //public DataTable GetProdNmae(string prodname)
    //{
    //    {
    //        try
    //        {
    //            string SQLQuery = "select * from tbl_Products where Product_name = '" + prodname. + "'";
    //            return GetDataTable(SQLQuery, true);
    //        }
    //        catch (Exception Ex)
    //        {
    //            throw Ex;
    //        }
    //    } 
    //}

    public DataTable searchumobile(string mobile)
    {
        try
        {
            string SQLQuery = "select *  from tbl_registration where mobileno= '" + mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable searchuname(string name )
    {
        try
        {
            string SQLQuery = "select *  from tbl_registration where mobileno LIKE '" + name + "%' or fullname LIKE '" + name + "%' or userid LIKE '" + name + "%'  ";
            return GetDataTable(SQLQuery, true);        
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable searchudate(string fromdate, string todate)
    {
        try
        {
            string SQLQuery = "select *  from tbl_registration where   cast(joindate as date) BETWEEN '" + fromdate + "' AND  '" + todate + "' order by cast(joindate as date) DESC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable searchuproducttype(string producttype)
    {
        try
        {
            string SQLQuery = "select *  from tbl_registration where producttype= '" + producttype + "' order by cast(joindate as date) DESC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable searchunonname(string name)
    {
        try
        {
            string SQLQuery = "select *  from tbl_invitefriends where mobileno LIKE '" + name + "%' or fname LIKE '" + name + "%' or userid LIKE '" + name + "%' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable alluserdetails1()
    {
        try
        {
            string SQLQuery = "select * from tbl_registration , tbl_freememreg ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable Getdownline()
    {
        try
        {
            string SQLQuery = "select * from tbl_registration";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getplacement(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where placement='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getstatus(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where status='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getstatus1(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where status='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getstatus2(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where status='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Gettotmembers(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getparentnodes(string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetmemWithDate1(string refid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid = '" + refid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getparentsunnodes(string parentid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where placementid = '" + parentid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable paidmembersdate(string todaydate)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where joindate LIKE '" + todaydate + "%'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable freemembersdate(string todaydate)
    {
        try
        {
            string SQLQuery = "select *from tbl_freememreg where joindate LIKE  '" + todaydate + "%'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable getsponsersname(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getsponserid(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getsponserid1(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getreferedname(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where SponsorUserID = '" +userid +"' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getimportmail(string Userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_mailContacts where Userid = '" + Userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getimportcontacts(string userid)
    {
        try
        {
            string SQLQuery = "select * from test_contacts where Reference = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getsponserid3(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getsponserid2(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getsinvituserids()
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getBV(string sno)
    {
        try
        {
            string SQLQuery = "select * from tbl_Products where sno='"+sno+"'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getBV1(string BV)
    {
        try
        {
            string SQLQuery = "select * from tbl_Products where Product_name='"+BV+"'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getfreememreferalname(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where referal_id = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getnonmemreferalname1(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getfreeuseridname(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getreferalname(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetAccountno(string AccountNo)
    {
        try
        {
            string SQLQuery = "select * from tbl_regtransactionDetails where AccountNo != '' and transactionid = '" + AccountNo + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBankdetails(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getaccountusingtransaction(string transid)
    {
        try
        {
            string SQLQuery = "select * from tbl_transactionDetails where transactionid = '" + transid + "' ";
            return GetDataTable(SQLQuery, false);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getdownloadpaymentstmts(string date)
    {
        try
        {
            //string SQLQuery = "SELECT reg.sno, prod.Product_name, reg.mobileno, reg.fullname, prod.Cost, prod.QTY, prod.BALANCE, prod.CV, prod.Tax,prod.MRP from tbl_registration reg, tbl_Products prod  where reg.joindate like 'date%' and prod.sno = reg.producttype";
            string SQLQuery = "SELECT reg.sno as sno, prod.Product_name, reg.mobileno, reg.fullname, prod.Cost, prod.QTY, prod.BALANCE, prod.Tax, prod.CV, prod.MRP from tbl_registration reg, tbl_Products prod  where reg.joindate like '" + date + "%' and prod.sno = reg.producttype";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void creditwalletdata(string userid, string name, string amount, string date, string description, string approval)
    {
        try
        {
            string SQLQuery = "insert into tbl_creditwallet(userid, name, amount, date, description, approval) values ('" + userid + "', '" + name + "', '" + amount + "', '" + date + "', '" + description + "', '" + approval + "' )";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getpaidmembers()
    {
        try
        {
            string SQLQuery = "select distinct inivted_user as inivted_user from tbl_invitefriends where invited_user_status='1'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable Getpaidmembers1()
    {
        try
        {
            string SQLQuery = "select distinct inivted_user as inivted_user from tbl_invitefriends where invited_user_status='2'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable Getsearchmembers()
    {
        try
        {
            string SQLQuery = "select * from tbl_registration , tbl_freememreg, tbl_invitefriends";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable getemailcontacts()
    {
        try
        {
            string SQLQuery = "select distinct Userid as Userid from tbl_mailContacts ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getuseridea()
    {
        try
        {
            string SQLQuery = "select * from tbl_writeidea  order by  sno desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable Getideadate(string date)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_writeidea where date like '" + date + "%' order by sno desc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable getexcelcontacts()
    {
        try
        {
            string SQLQuery = "select distinct Reference as Reference from test_contacts ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable getwallet()
    {
        try
        {
            string sqlquery = "Select * from tbl_productwallet";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updatwallet(string tds, string productwallet, string other)
    {
        try
        {

            string SQLQuery = "update tbl_productwallet set Tds='" + tds + "', productwallet='" + productwallet + "', others='" + other + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getexcelcontacts1(string userid)
    {
        try
        {
            string SQLQuery = "select * from test_contacts where Reference = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void debitpwdetails(string userid, string mobileno, string TDS, string PW, string others, string total, string date, string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_pw_deductions(userid, mobileno, TDS, PW, others, total, date,status) values ('" + userid + "', '" + mobileno + "', '" + TDS + "', '" + PW + "', '" + others + "', '" + total + "', '" + date + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getdatefrompw(string date, string status, string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_pw_deductions where date='" + date + "' and status='" + status + "' and userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable Getdatefrompw1(string date, string status)
    {
        try
        {
            string SQLQuery = "select * from tbl_pw_deductions where date='" + date + "' and status='" + status + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getpindlrinfo(string pinno)
    {
        try
        {
            string SQLQuery = "select * from tbl_delrpintransfer where pinno='" + pinno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getAccountno11(string transactionid)
    {
        try
        {
            string SQLQuery = "select * from tbl_regtransactionDetails where transactionid = '" + transactionid + "' and Pinno='' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getpino1(string transactionid)
    {
        try
        {
            string SQLQuery = "select * from tbl_regtransactionDetails where transactionid = '" + transactionid + "' and AccountNo='' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    

    public DataTable getpinholdername(string pino)
    {
        try
        {
            string SQLQuery = "select r.account_no ,r.Name  from tbl_pindealerregistration as r inner join tbl_delrpintransfer as p  on r.id=p.dealerid where p.pinno='" + pino + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertBinarypayoutdetails(string PayoutDate, string userid, string Name, string Mobileno, string NetBV, string BeforeDeductionNetAmt, string PW, string DeductionAmt, string CV, string PayabeAmt, string bank, string branch, string accno, string ifsc, string pan, string date, string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_Binarypayoutdetails(PayoutDate, userid, Name, Mobileno, NetBV, BeforeDeductionNetAmt, PW, DeductionAmt, CV, PayabeAmt,Bankname ,Branchname,Accno,IFSCode,Panno, date, status) values ('" + PayoutDate + "','" + userid + "', '" + Name + "', '" + Mobileno + "', '" + NetBV + "', '" + BeforeDeductionNetAmt + "', '" + PW + "',  '" + DeductionAmt + "', '" + CV + "','" + PayabeAmt + "','" + bank + "','" + branch + "','" + accno + "','" + ifsc + "','" + pan + "','" + date + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void insertBinarypayoutdetails1(string userid, string Name, string Mobileno, string NetBV, string BeforeDeductionNetAmt, string PW, string Others, string Others1, string DeductionAmt, string CV, string Bankname, string Branchname, string Accno, string IFSCode, string Panno, string PayabeAmt, string date, string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_Binarypayoutdetails(userid, Name, Mobileno, NetBV, BeforeDeductionNetAmt, PW, Others, Others1, DeductionAmt, CV, Bankname, Branchname, Accno, IFSCode, Panno, PayabeAmt, date, status) values ('" + userid + "', '" + Name + "', '" + Mobileno + "', '" + NetBV + "', '" + BeforeDeductionNetAmt + "', '" + PW + "', '" + Others + "','" + Others1 + "', '" + DeductionAmt + "', '" + CV + "', '" + Bankname + "','" + Branchname + "','" + Accno + "', '" + IFSCode + "', '" + Panno + "','" + PayabeAmt + "','" + date + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void DeleteBinarypayoutdetails()
    {
        try
        {
            string SQLQuery = "delete from tbl_Binarypayoutdetails";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinarypayoutdetails(string date)
    {
        try
        {
            string SQLQuery = "select * from tbl_Binarypayoutdetails where PayoutDate='"+date+"'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBPW(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Binarypayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetRPW(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Referalpayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetSelectenddate()
    {
        try
        {
            string SQLQuery = "select * from tbl_Binarypayoutdetails";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertReferalpayoutdetails(string Payoutdate, string userid, string Name, string Mobileno, string Actualamt, string PW, string Deductions, string Bankname, string Branchname, string Accno, string IFSCode, string Panno, string Balance, string date, string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_Referalpayoutdetails(Payoutdate, userid, Name, Mobileno,Actualamt, PW, Deductions, Bankname, Branchname, Accno, IFSCode, Panno, Balance, date, status) values ('" + Payoutdate + "', '" + userid + "', '" + Name + "', '" + Mobileno + "','" + Actualamt + "', '" + PW + "', '" + Deductions + "', '" + Bankname + "','" + Branchname + "', '" + Accno + "', '" + IFSCode + "', '" + Panno + "','" + Balance + "','" + date + "', '" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void insertReferalInfo(string Payoutdate, string userid, string name, string mobileno, string BV, string Refmem, string BonusBV, string TotalBV, string Totamt)
    {
        try
        {
            string SQLQuery = "insert into tbl_ReferalInfo(Payoutdate, userid, name, mobileno,BV, Refmem, BonusBV,TotalBV, Totamt) values ('" + Payoutdate + "','" + userid + "', '" + name + "', '" + mobileno + "','" + BV + "', '" + Refmem + "', '" + BonusBV + "','" + TotalBV + "', '" + Totamt + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void insertReferalInfo1(string Payoutdate, string Fromdate, string Todate)
    {
        try
        {
            string SQLQuery = "insert into tbl_ReferalInfo1(Payoutdate,Fromdate,Todate) values ('" + Payoutdate + "','" + Fromdate + "','" + Todate + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    
    

    public DataTable GetReferalpayoutdetails(string Payoutdate)
    {
        try
        {
            string SQLQuery = "select * from tbl_Referalpayoutdetails where Payoutdate = '" + Payoutdate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

     public DataTable GetReferalInfo(string Payoutdate)
    {
        try
        {
            string SQLQuery = "select * from tbl_ReferalInfo where Payoutdate = '" + Payoutdate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

     public DataTable GetReferalbetweendates(string Payoutdate)
     {
         try
         {
             string SQLQuery = "select * from tbl_ReferalInfo1 where Payoutdate = '" + Payoutdate + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
    
    public void Referalpayoutdetails()
    {
        try
        {
            string SQLQuery = "delete from tbl_Referalpayoutdetails";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetSelectenddate1()
    {
        try
        {
            string SQLQuery = "select * from tbl_Referalpayoutdetails";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertDatapayoutdetails(string userid, string Name, string Mobileno, string Numofinvitations, string totalpoints, string Elgpoints, string Bonuspoints, string BonusAmt, string totalamt, string date, string status, string pw, string balanceamt)
    {
        try
        {
            string SQLQuery = "insert into tbl_Datapayoutdetails(userid, Name, Mobileno, Numofinvitations, totalpoints, Elgpoints, Bonuspoints,BonusAmt,totalamt, date, status, PW, BalaceAmt) values ('" + userid + "', '" + Name + "', '" + Mobileno + "', '" + Numofinvitations + "','" + totalpoints + "', '" + Elgpoints + "', '" + Bonuspoints + "','" + BonusAmt + "', '" + totalamt + "', '" + date + "','" + status + "','" + pw + "','" + balanceamt + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void Datapayoutdetails()
    {
        try
        {
            string SQLQuery = "delete from tbl_Datapayoutdetails";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetDatapayoutdetails(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Datapayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetSelectenddate2()
    {
        try
        {
            string SQLQuery = "select * from tbl_Datapayoutdetails";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getusermessage()
    {

        try
        {
            string SQLQuery = "select * from tbl_Accountsms";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getusermessage12(string sno)
    {

        try
        {
            string SQLQuery = "select * from tbl_Accountsms where sno = '" + sno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Insertusermessage(string usertype)
    {
        try
        {
            string SQLQuery = "insert into tbl_Accountsms(usertype) values ('" + usertype + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Insertusermessage1(string message)
    {
        try
        {
            string SQLQuery = "insert into tbl_Accountsms(message) values ('" + message + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBankwallet(string userid)
    {

        try
        {
            string SQLQuery = "select  sum(CAST(PW as float)) as PW from tbl_pw_deductions where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

     public DataTable GetProductwallet(string userid)
    {

        try
        {
            string SQLQuery = "select  sum(CAST(PW as int)) as PW from tbl_Binarypayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

     

     public DataTable GetProductwallet1(string userid)
     {

         try
         {
             string SQLQuery = "select  sum(CAST(PW as int)) as PW from tbl_Referalpayoutdetails where userid='" + userid + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }

     public DataTable GetBankwalletAmt(string userid)
     {

         try
         {
             string SQLQuery = "select  sum(CAST(PayabeAmt as int)) as PayabeAmt from tbl_Binarypayoutdetails where userid='" + userid + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }

     public DataTable getreferids(string refid, string placement)
     {
         try
         {
             string SQLQuery = "select * from tbl_registration where referid='" + refid + "' and placement='" + placement + "' order by sno ASC  ";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }

     public DataTable GetBankwalletAmt1(string userid)
     {

         try
         {
             string SQLQuery = "select  sum(CAST(Balance as int)) as Balance from tbl_Referalpayoutdetails where userid='" + userid + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
   
    public DataTable GetBankwallet1()
    {

        try
        {
            string SQLQuery = "select distinct tbl_Binarypayoutdetails.userid from tbl_Binarypayoutdetails union select distinct tbl_Referalpayoutdetails.userid from tbl_Referalpayoutdetails";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetPrduwalltused(string userid)
    {

        try
        {
            string SQLQuery = "select sum(CAST(amt as float))as amt from tbl_prduwalltused where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryDetailedPWused(string userid)
    {

        try
        {
            string SQLQuery = "select * from tbl_Binarypayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetReferalDetailedPWused(string userid)
    {

        try
        {
            string SQLQuery = "select  * from tbl_Referalpayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetDatawallet()
    {

        try
        {
            string SQLQuery = "select * from tbl_Datapayoutdetails";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetInviteddatadetails(string userid)
    {
        try
        {
            string SQLQuery = "select top 50* from tbl_invitefriends where inivted_user = '" + userid + "' order by sno ASC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetInviteddatadetails2(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user = '" + userid + "' order by sno ASC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetInviteddatadetails1(string userid)
    {
        try
        {
            string SQLQuery = "select top 50* from tbl_invitefriends where inivted_user = '" + userid + "' order by invited_date DESC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetInviteddatadetailsDESC(string userid, string date)
    {
        try
        {
            string SQLQuery = "select top 50* from tbl_invitefriends where inivted_user = '" + userid + "'  and CAST(invited_date as DATE) <=  '" + date + "'  order by sno desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetPrduwalltused1(string userid)
    {

        try
        {
            string SQLQuery = "select * from tbl_prduwalltused where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetTotalPWAmount(string userid)
    {

        try
        {
            string SQLQuery = "(select Payoutdate,PW,status FROM tbl_Binarypayoutdetails where userid='" + userid + "') union all (select Payoutdate,PW,status FROM tbl_Referalpayoutdetails where userid='" + userid + "')";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetmemWithDate(string refid, string date)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid = '" + refid + "' and CAST(joindate as DATE) <= '" + date.ToString() + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getproductBVsum(string productid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Products where sno = '" + productid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetUserwallet(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_Userwalletstatus where mobileno='" + mobileno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void InsertUserwallet(string mobileno, string useid, string Delearname, string Delearmobile, string walletstatus, string Activatedate)
    {
        try
        {
            string SQLQuery = "insert into tbl_Userwalletstatus(mobileno, useid, Delearname, Delearmobile, walletstatus,Activatedate) values (" + mobileno + ",'" + useid + "','" + Delearname + "', '" + Delearmobile + "','" + walletstatus + "','" + Activatedate + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void UpdateUserWallet(string mobileno, string useid, string Delearname, string Delearmobile, string walletstatus, string Activatedate)
    {
        try
        {

            string SQLQuery = "update tbl_Userwalletstatus set useid='" + useid + "', Delearname='" + Delearname + "',Delearmobile='" + Delearmobile + "', walletstatus='" + walletstatus + "',Activatedate='" + Activatedate + "' where mobileno='" + mobileno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetmemPlacementid1(string refid, string placement)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid = '" + refid + "' and placement = '" + placement + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetmemPersonalAmtCV1(string refid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + refid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetDirectsMem()
    {
        try
        {
            string SQLQuery = "select referid as userid,COUNT(referid) as referid from tbl_registration group  by referid having  count(referid)>=4";
            return GetDataTable(SQLQuery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetTotCV(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(CV as int))as CV from tbl_Binarypayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable GetTotCV1(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_TOTCV where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetUserwallet1()
    {
        try
        {
            string SQLQuery = "select * from tbl_Userwalletstatus";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void zGetUserwallet2(string mobileno)
    {
        try
        {
            string SQLQuery = "delete from tbl_Userwalletstatus  where mobileno='" + mobileno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateUserWallet1(string mobileno, string Delearname, string Delearmobile, string walletstatus)
    {
        try
        {

            string SQLQuery = "update tbl_Userwalletstatus set Delearname='" + Delearname + "', Delearmobile='" + Delearmobile + "', walletstatus='" + walletstatus + "' where mobileno='" + mobileno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetTransferedAmt(string userid, string sno)
    {
        try
        {
            string SQLQuery = "select * from tbl_BWTransferAmt  where userid='" + userid + "' and sno='" + sno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetTransferedAmt143(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_BWTransferAmt_temporary  where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetDatapayoutExitsUser(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Datapayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateDatapayoutdetails2(string totalamt, string Totmonths, string CurrentBal, string Currentmonths, string BalaceAmt, string PW, string CurrentPW, string userid)
    {
        try
        {
            string SQLQuery = "update tbl_Datapayoutdetails set totalamt='" + totalamt + "', Totmonths='" + Totmonths + "', CurrentBal='" + CurrentBal + "',Currentmonths='" + Currentmonths + "', BalaceAmt='" + BalaceAmt + "', PW='" + PW + "', CurrentPW='" + CurrentPW + "' where userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertDatapayoutdetails1(string userid, string Name, string Mobileno, string Numofinvitations, string totalamt, string date, string status, string pw, string balanceamt, string calcMns, string CurrentBal, string Currentmonths)
    {
        try
        {
            //string SQLQuery = "insert into tbl_Datapayoutdetails(userid, Name, Mobileno, Numofinvitations, totalamt, date, status, PW, BalaceAmt, Totmonths,Currentmonths,CurrentBal) values ('" + userid + "', '" + Name + "', '" + Mobileno + "', '" + Numofinvitations + "', '" + totalamt + "', '" + date + "','" + status + "','" + pw + "','" + balanceamt + "','" + calcMns + "','" + Currentmonths + "','" + CurrentBal + "')";
            string SQLQuery = "USP_insertDatapayoutdetails1 '" + userid + "', '" + Name + "', '" + Mobileno + "', '" + Numofinvitations + "', '" + totalamt + "', '" + date + "','" + status + "','" + pw + "','" + balanceamt + "','" + calcMns + "','" + Currentmonths + "','" + CurrentBal + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBankwalletAmt2(string userid)
    {

        try
        {
            string SQLQuery = "select  sum(CAST(Actualamt as int)) as Actualamt from tbl_Referalpayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBankwalletAmt3(string userid)
    {

        try
        {
            string SQLQuery = "select  sum(CAST(PayabeAmt as int)) as PayabeAmt from tbl_Binarypayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

 public DataTable GetBinarySpotAmt(string userid)
    {

        try
        {
            string SQLQuery = "select  sum(CAST(PW as int)) as PW from tbl_Binarypayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

 public DataTable GetDataSpotBonusAmt(string userid)
    {

        try
        {
            string SQLQuery = "select sum(CAST(SpotBounusAmt as int)) as SpotBounusAmt from tbl_Data_SpotBonusAmt where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetDataBankwalletAmt(string userid)
    {

        try
        {
            string SQLQuery = "select  sum(CAST(totalamt as int)) as totalamt from tbl_Datapayoutdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable calculateWalletBankAmount(string userid, string columnName, string tblname)
    {
        try
        {
            string SQLQuery = "select sum(cast(" + columnName + " as bigint)) as amount from " + tblname + "  where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBW2PW(string userid)
    {

        try
        {
            string SQLQuery = "select sum(cast(Tranferamt as int)) as Tranferamt from tbl_PWTransferAmt where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetTransferedAmt1()
    {
        try
        {
            string SQLQuery = "select * from tbl_BWTransferAmt where PaymentStatus is null order by cast(date as date) DESC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBankName(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetReqAmt(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_BWTransferAmt where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

 public DataTable GetReqAmt1(string userid)
    {
        try
        {
            string SQLQuery = "select sum(CAST(Tranferamt as float)) as Tranferamt from tbl_BWTransferAmt where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void InsertBWTransferAmt1(string userid, string PaymentStatus, string date)
    {
        try
        {

            //string SQLQuery = "update tbl_BWTransferAmt set PaymentStatus='" + PaymentStatus + "' where userid='" + userid + "' and date='" + date + "'";
            string SQLQuery = "USP_InsertBWTransferAmt1'" + PaymentStatus + "','" + userid + "','" + date + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBWTransferAmt(string userid, string date)
    {
        try
        {
            string SQLQuery = "select * from tbl_BWTransferAmt_temporary where userid = '" + userid + "' and date='" + date + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertBWTransferAmt(string userid, string name, string mobileno, string Tranferamt, string TDS, string Netamt, string Deductamt, string Balamt, string date, string Tranferdate, string status, string PaymentStatus)
    {
        try
        {
            string SQLQuery = "insert into tbl_BWTransferAmt_temporary(userid, name, mobileno, Tranferamt, TDS, Netamt, Deductamt, Balamt, date, Tranferdate, status, PaymentStatus) values ('" + userid + "', '" + name + "', '" + mobileno + "', '" + Tranferamt + "', '" + TDS + "', '" + Netamt + "','" + Deductamt + "','" + Balamt + "', '" + date + "','" + Tranferdate + "','" + status + "','" + PaymentStatus + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetTransferedAmt2()
    {
        try
        {
            string SQLQuery = "select * from tbl_BWTransferAmt_temporary order by cast(Tranferdate as date) DESC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetReqAmt1(string userid, string date)
    {
        try
        {
            string SQLQuery = "select * from tbl_BWTransferAmt where userid='" + userid + "' and Tranferdate = '" + date.ToString() + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

     public void InsertMLCLK(string userid, string mobileno, string Totamt, string Paidamt, string BaltoPaid, string Bankname, string Name, string Vocherno, string Chequeno)
    {
        try
        {
            string SQLQuery = "insert into tbl_mlsckv1(userid, mobileno, Totamt, Paidamt, BaltoPaid, Bankname, Name, Vocherno, Chequeno) values ('" + userid + "', '" + mobileno + "', '" + Totamt + "', '" + Paidamt + "', '" + BaltoPaid + "', '" + Bankname + "','" + Name + "','" + Vocherno + "', '" + Chequeno + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetMLCLK(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_mlsckv1 where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateMLCLK(string mobileno, string Totamt, string Paidamt, string BaltoPaid, string Bankname, string Name, string Vocherno, string Chequeno, string userid)
    {
        try
        {
            string SQLQuery = "update tbl_mlsckv1 set mobileno='" + mobileno + "', Totamt='" + Totamt + "', Paidamt='" + Paidamt + "', BaltoPaid='" + BaltoPaid + "', Bankname='" + Bankname + "', Name='" + Name + "', Vocherno='" + Vocherno + "', Chequeno='" + Chequeno + "' where userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetMLCHK()
    {
        try
        {
            string SQLQuery = "select * from tbl_mlsckv";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable Getentrypass()
    {
        try
        {
            string SQLQuery = "select * from tbl_Entrypass";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GettotalBankwalletAmt()
    {

        try
        {
            string SQLQuery = "select sum(CAST(Tranferamt as int)) as Transferamount from tbl_BWTransferAmt_temporary ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetSpotBonusAmt(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Data_SpotBonusAmt where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertSpotBonusAmt(string userid, string mobileno, string name, string SpotBounusAmt, string date, string PayoutDate)
    {
        try
        {
            string SQLQuery = "insert into tbl_Data_SpotBonusAmt(userid, mobileno, name, SpotBounusAmt, date,PayoutDate) values ('" + userid + "', '" + mobileno + "', '" + name + "', '" + SpotBounusAmt + "', '" + date + "','" + PayoutDate + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetUserwalletStatus(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Userwalletstatus where useid='" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetPaidMemActiveStatus(string useid)
    {
        try
        {
            string sqlquery = "Select * from tbl_Userwalletstatus where useid='" + useid + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception EX)
        {
            throw EX;
        }
    }


    public void UpdateUserWallet2(string mobileno, string walletstatus, string Activatedate)
    {
        try
        {

            string SQLQuery = "update tbl_Userwalletstatus set walletstatus='" + walletstatus + "',Activatedate='" + Activatedate + "' where mobileno='" + mobileno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertUserwallet1(string mobileno, string useid, string walletstatus, string Activatedate)
    {
        try
        {
            string SQLQuery = "insert into tbl_Userwalletstatus(mobileno, useid,  walletstatus,Activatedate) values (" + mobileno + ",'" + useid + "','" + walletstatus + "','" + Activatedate + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetDepositeUsers()
    {
        try
        {
            string SQLQuery = "select * from tbl_bankdepositusers";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

	public DataTable GetDepositeUsersNA()
    {
        try
        {
            string SQLQuery = "select * from tbl_bankdepositusers where Activateuser = 'NA' order by sno desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetDepositeUsers1(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_bankdepositusers where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateDepostedUserstatus(string userid, string productremarkname)
    {
        try
        {

            string SQLQuery = "update tbl_bankdepositusers set Activateuser='" + productremarkname + "' where userid='" + userid + "'";
            //string SQLQuery = "USP_UpdateDepostedUserstatus '" + productremarkname + "' , '" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable checkpaiduserid1(string useid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Userwalletstatus where  useid='" + useid + "' and walletstatus='0' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable nonmembers12(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable GetActiveMembers(string refid)
    {
        try
        {
            //string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.fullname as fullname,tbl_registration.mobileno as mobileno, tbl_registration.placement as placement,tbl_registration.sno as sno,";
            //SQLQuery = SQLQuery + " tbl_registration.referid as referid,tbl_registration.status as status ";
            //SQLQuery = SQLQuery + " FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            //SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_registration.userid='" + refid + "' and tbl_Userwalletstatus.walletstatus='0' order by sno DESC ";
            
            string SQLQuery = " USP_GetActiveMembers '"+ refid +"'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetUserwalletPaidStatus(string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Userwalletstatus where useid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetAlluserdetails2()
    {
        try
        {
            //string SQLQuery = " SELECT tbl_registration.userid as userid";
            //SQLQuery = SQLQuery + " FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            //SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_Userwalletstatus.walletstatus='0'";
            string SQLQuery = "USP_GetAlluserdetails2";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetPayoutwalletAmt(string userid)
    {

        try
        {
            string SQLQuery = "select  sum(CAST(Amount as int)) as Amount from tbl_Debit_Wallet where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getcreditwallet(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno = '" + mobileno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable searchdeposited(string name)
    {
        try
        {
            string SQLQuery = "select *  from tbl_bankdepositusers where codename LIKE '" + name + "%'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public void UpgradeFreeMemberToPaidDeactive(string sUserID)
    {

        string sQry = "INSERT INTO TBL_REGISTRATION ( PRODUCTTYPE, MOBILENO, PASSWORD, FULLNAME ";
        sQry += "   , EMAILID , STATE , CITY , PLACEMENT, PLACEMENTID, SPONSORUSERID ";
        sQry += "   , LEVELNO , REFERID , USERTYPE , JOINDATE , STATUS , VERIFICATIONCODE ";
        sQry += "   , USERID , TRANSACTIONID , UPGRADE , INITPAKG , ACTIVESTATUS  ";
        sQry += "   , PAIDSTATUS , UPGRADEDATE , FIRSTLOG, IS_TERMS_AGREED, ACTIVATION_DATE , AFFILIATE_DATE ) ";

        sQry += " SELECT 0, MOBILENO, USERPWD, NAME ";
        sQry += "   , EMAILID , STATE , CITY , PLACEMENT , PLACEMENTID , SPONSORUSERID ";

        // The below statement modified by Sudhindra on 4-Jul-2014. Purpose : REFERAL_ID has serail no. Hence, Should pass REFERALID . Correction done.
        //sQry += "   , LEVELNO , REFERAL_ID , MEMTYPE , JOINDATE , STATUS , VERIFYCODE ";
        sQry += "   , LEVELNO , REFERALID , MEMTYPE , JOINDATE , STATUS , VERIFYCODE ";

        sQry += "   , USERID , NULL , NULL , NULL , ACTIVEUSER  ";
        sQry += "   , NULL , NULL , FIRSTLOG, IS_TERMS_AGREED  , ACTIVATION_DATE , GETDATE() ";
        sQry += " FROM TBL_FREEMEMREG ";
        sQry += " WHERE USERID = '"+ sUserID +"' ";

        int intRowAffect = fnExecuteNonQuery(sQry, true);

        sQry = "";
        sQry = " INSERT INTO TBL_USERWALLETSTATUS(MOBILENO, USEID,  WALLETSTATUS, ACTIVATEDATE)";
        sQry += " SELECT MOBILENO, USERID,  1, '"+ DateTime.Now.ToString() +"' FROM TBL_FREEMEMREG ";
        sQry += " WHERE USERID = '" + sUserID + "' ";

        intRowAffect = fnExecuteNonQuery(sQry, true);

        sQry = "";
        sQry += " UPDATE TBL_FREEMEMREG SET UPGRADED_PAID_DEACTIVE = 1 WHERE USERID = '" + sUserID + "'";
        intRowAffect = fnExecuteNonQuery(sQry, true);

    }

    public DataTable PremiumAffiliates()
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype > 0 order by cast(joindate as datetime) DESC";
            //string SQLQuery = "select reg1.joindate,reg1.ACTIVATION_DATE,reg1.AFFILIATE_DATE, reg1.sno,reg1.fullname,reg1.userid,reg1.referid ,reg2.name AS refName from tbl_registration reg1 left join tbl_freememreg as reg2 ON reg1.referid = reg2.userid where producttype > 0 order by cast(reg1.joindate as datetime) DESC";
            //string SQLQuery = " select reg1.AFFILIATE_DATE,reg1.mobileno,reg1.fullname,reg1.userid,reg1.referid ,reg2.name AS refName,reg2.mobileno AS refMobile,cities.city_name AS city from tbl_registration reg1 left join tbl_freememreg as reg2 ON reg1.referid = reg2.userid left join Cities as cities ON reg1.city = cities.city_id where producttype > 0 order by cast(reg1.AFFILIATE_DATE as datetime) DESC";
            // string SQLQuery = "SELECT USERID, FULLNAME, EMAILID, MOBILENO,REF_NAME,REFERID,BV,ACTIVATION_DATE,AFFILIATE_DATE,  DBO.FN_GET_DETAILS_BY_USERID( USERID,'CITY')CITY  FROM REGISTRION_DETAILS_VIEW V WHERE USER_STATUS like '%P%' order by cast(AFFILIATE_DATE as datetime) DESC";
            //string SQLQuery = "SELECT V.USERID, V.FULLNAME, V.EMAILID, V.MOBILENO, V.REF_NAME, V.REFERID, V2.MOBILENO as REFERMobile, V.BV, V.ACTIVATION_DATE,V.AFFILIATE_DATE, DBO.FN_GET_DETAILS_BY_USERID( V.USERID,'CITY')CITY,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS='') InActive,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS <>'') Active FROM REGISTRION_DETAILS_VIEW V LEFT OUTER JOIN ALL_MEMBERS_VIEW V2 ON V.REFERID = V2.USERID WHERE V.USER_STATUS IN ('P' ,'PA')ORDER BY CAST(V.AFFILIATE_DATE AS DATETIME) DESC";
            string SQLQuery = "SELECT V.USERID, V.FULLNAME,V.MOBILENO,  V.REFERID, V.REF_NAME,V2.MOBILENO as REFERMobile,V.PLACEMENT, V.BV,V.AFFILIATE_DATE, DBO.FN_GET_DETAILS_BY_USERID( V.USERID,'CITY')CITY,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS='') InActive,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS <>'') Active FROM REGISTRION_DETAILS_VIEW V LEFT OUTER JOIN ALL_MEMBERS_VIEW V2 ON V.REFERID = V2.USERID WHERE V.USER_STATUS IN ('P' ,'PA')ORDER BY CAST(V.AFFILIATE_DATE AS DATETIME) DESC";





            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable Affiliates()
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype = 0 order by cast(joindate as datetime) DESC";
            // string SQLQuery = "select reg1.AFFILIATE_DATE,reg1.mobileno,reg1.fullname,reg1.userid,reg1.referid ,reg2.name AS refName,reg2.mobileno AS refMobile,cities.city_name AS city from tbl_registration reg1 left join tbl_freememreg as reg2 ON reg1.referid = reg2.userid left join Cities as cities ON reg1.city = cities.city_id where producttype = 0 order by cast(reg1.AFFILIATE_DATE as datetime) DESC";
            //string SQLQuery = "SELECT USERID, FULLNAME, EMAILID, MOBILENO,REF_NAME,REFERID,BV,ACTIVATION_DATE,AFFILIATE_DATE,  DBO.FN_GET_DETAILS_BY_USERID( USERID,'CITY')CITY  FROM REGISTRION_DETAILS_VIEW V WHERE USER_STATUS = 'FA' order by cast(AFFILIATE_DATE as datetime) DESC";
            string SQLQuery = "SELECT V.USERID, V.FULLNAME, V.EMAILID, V.MOBILENO, V.REF_NAME, V.REFERID, V2.MOBILENO as REFERMobile, V.ACTIVATION_DATE,V.AFFILIATE_DATE, DBO.FN_GET_DETAILS_BY_USERID( V.USERID,'CITY')CITY,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS='') InActive,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS <>'') Active FROM REGISTRION_DETAILS_VIEW V LEFT OUTER JOIN ALL_MEMBERS_VIEW V2 ON V.REFERID = V2.USERID WHERE V.USER_STATUS ='FA' ORDER BY CAST(V.AFFILIATE_DATE AS DATETIME) DESC";


            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void getUserNetworkDataVersion2_AdminReports(string Criteria, string sSessionID)
    {
        try
        {
            string sQry = "EXEC USP_ADMIN_SHOW_USERS_DATA '" + Criteria + "' , '" + sSessionID + "'";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }



    public DataTable getAFFILIATESFromAdminSession(string sSessionID)
    {
        try
        {
            string sQry = "SELECT SESSION_ID,USER_ID,MOBILE_NO,FULLNAME,EMAIL_ID,CITY_NAME,JOIN_DATE,JOIN_DATE_106,ACTIVATION_DATE,ACTIVATION_DATE_106,AFFILIATE_DATE,AFFILIATE_DATE_106,REF_ID,REF_NAME,REF_MOBILE, ISNULL(TOTAL_ACTIVATED, 0) TOTAL_ACTIVATED, ISNULL(TOTAL_ELIGIBLE, 0) TOTAL_ELIGIBLE, ISNULL(TOTAL_INVITED, 0) TOTAL_INVITED, ISNULL(TOTAL_INACTIVE ,0) TOTAL_INACTIVE,I.IMAGENAME  FROM TMP_USER_DATA  INNER JOIN TBL_IMAGEDETAIL I ON TMP_USER_DATA.USER_ID = I.userid  WHERE SESSION_ID = '" + sSessionID + "' ORDER BY AFFILIATE_DATE DESC, ACTIVATION_DATE DESC, JOIN_DATE DESC";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    //public DataTable getAFFILIATESStatus(string sSessionID)
    //{
    //    try
    //    {
    //        string sQry = "SELECT SESSION_ID,USER_ID,MOBILE_NO,FULLNAME,EMAIL_ID,CITY_NAME,JOIN_DATE,JOIN_DATE_106,ACTIVATION_DATE,ACTIVATION_DATE_106,AFFILIATE_DATE,AFFILIATE_DATE_106,REF_ID,REF_NAME,REF_MOBILE, ISNULL(TOTAL_ACTIVATED, 0) TOTAL_ACTIVATED, ISNULL(TOTAL_ELIGIBLE, 0) TOTAL_ELIGIBLE, ISNULL(TOTAL_INVITED, 0) TOTAL_INVITED, ISNULL(TOTAL_INACTIVE ,0) TOTAL_INACTIVE,I.IMAGENAME,adinfo.IS_VALID_AFFILIATE_IMAGE FROM TMP_USER_DATA  INNER JOIN TBL_IMAGEDETAIL I ON TMP_USER_DATA.USER_ID = I.userid inner join TBL_USER_ADDITIONAL_INFO adinfo on adinfo.userid=I.userid  WHERE SESSION_ID = '" + sSessionID + "' ORDER BY AFFILIATE_DATE DESC, ACTIVATION_DATE DESC, JOIN_DATE DESC";
    //        return GetDataTable(sQry, true);
    //    }
    //    catch (Exception ex)
    //    {

    //        throw ex;
    //    }
   // }
    public DataTable getPREMIUMAFFILIATESFromAdminSession(string sSessionID)
    {
        try
        {
            string sQry = "SELECT SESSION_ID,USER_ID,MOBILE_NO,FULLNAME,EMAIL_ID,CITY_NAME,JOIN_DATE,JOIN_DATE_106,ACTIVATION_DATE,ACTIVATION_DATE_106,AFFILIATE_DATE,AFFILIATE_DATE_106,REF_ID,REF_NAME,REF_MOBILE, ISNULL(TOTAL_ACTIVATED, 0) TOTAL_ACTIVATED, ISNULL(TOTAL_INVITED, 0) TOTAL_INVITED, ISNULL(TOTAL_INACTIVE ,0) TOTAL_INACTIVE,BV  FROM TMP_USER_DATA  WHERE SESSION_ID = '" + sSessionID + "' ORDER BY AFFILIATE_DATE DESC,ACTIVATION_DATE DESC, JOIN_DATE DESC";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable Affiliates(string userid)
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype > 0 order by cast(joindate as datetime) DESC";
            string SQLQuery = "select * from tbl_registration where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable ActiveUsers()
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype = 0 order by cast(joindate as datetime) DESC";
            //string SQLQuery = "select view1.name,view1.mobileno,view1.referal_mobile as refMobile,view1.ACTIVATION_DATE,view1.referalID,view1.userid,view2.name as refName,tbl.city_name as city from ALL_MEMBERS_VIEW as view1 left join ALL_MEMBERS_VIEW view2 ON view1.referalID = view2.userid left join Cities as tbl ON view1.city = tbl.city_id where activeuser='A' order by cast(view1.ACTIVATION_DATE as datetime) DESC";
            //string SQLQuery = "SELECT USERID, FULLNAME, EMAILID, MOBILENO,REF_NAME,REFERID,BV,ACTIVATION_DATE,AFFILIATE_DATE,  DBO.FN_GET_DETAILS_BY_USERID( USERID,'CITY')CITY  FROM REGISTRION_DETAILS_VIEW V WHERE USER_STATUS = 'U' order by cast(AFFILIATE_DATE as datetime) DESC";
            // string SQLQuery = "SELECT top 5 V.USERID, V.FULLNAME, V.EMAILID, V.MOBILENO, V.REF_NAME, V.REFERID, V2.MOBILENO as REFERMobile, V.ACTIVATION_DATE, DBO.FN_GET_DETAILS_BY_USERID( V.USERID,'CITY')CITY,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS='') InActive,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS <>'') Active FROM REGISTRION_DETAILS_VIEW V LEFT OUTER JOIN ALL_MEMBERS_VIEW V2 ON V.REFERID = V2.USERID WHERE V.USER_STATUS ='U' ORDER BY CAST(V.ACTIVATION_DATE as datetime) DESC";
            //string SQLQuery = "select f.userid,f.joindate ,f.ACTIVATION_DATE,f.name,f.mobileno,tf.name as ref_name,f.referal_mobile,f.referalID,c.cityname from tbl_freememreg f left outer join tbl_freememreg tf on f.referalID = tf.userid left outer join tbl_cities c on c.cityid = f.city where f.activeuser='A' ORDER BY  f.joindate DESC";
            //string SQLQuery = "select f.userid, f.joindate ,f.ACTIVATION_DATE,f.name,f.mobileno,tf.name as ref_name,f.referal_mobile,f.referalID,c.cityname,";
            //SQLQuery = SQLQuery + "(select count (*) from tbl_freememreg  f where f.referalID=tf.userid  and f.activeuser ='A')as Active ,";
            //SQLQuery = SQLQuery + "(select count (*) from tbl_freememreg  f where f.referalID=tf.userid  and f.activeuser ='NA')as InActive ";
            //SQLQuery = SQLQuery + "from tbl_freememreg f left outer join tbl_freememreg tf on f.referalID = tf.userid left outer join ";
            //SQLQuery = SQLQuery + "tbl_cities c on c.cityid = f.city where f.activeuser='A' ORDER BY f.ACTIVATION_DATE DESC";

            //string SQLQuery = "exec [dbo].[USP_ADMIN_SHOW_USERS_DATA] 'ACTIVE_USERS'";

            string SQLQuery = "select f.userid, f.joindate ,f.ACTIVATION_DATE,f.name,f.mobileno,tf.name as ref_name,f.referal_mobile,f.referalID,";
            SQLQuery = SQLQuery + "c.cityname,(select count (*) from tbl_freememreg  f where f.referalID=tf.userid and f.activeuser ='A')as Active ,";
            SQLQuery = SQLQuery + "(select count (*) from tbl_freememreg  f where f.referalID=tf.userid and f.activeuser ='NA')as InActive ";
            SQLQuery = SQLQuery + "from tbl_freememreg f left outer join tbl_freememreg tf on f.referalID = tf.userid left outer join tbl_cities c ";
            SQLQuery = SQLQuery + "on c.cityid = f.city where f.activeuser='A' and (select count (*) from tbl_freememreg  f where f.referalID=tf.userid and f.activeuser ='A')>20 ";
            SQLQuery = SQLQuery + "and f.userid not in(select userid from tbl_registration) ORDER BY f.ACTIVATION_DATE DESC";
            return GetDataTable(SQLQuery, true);


        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable ActiveUsers(string userid)
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype > 0 order by cast(joindate as datetime) DESC";
            string SQLQuery = "select * from ALL_MEMBERS_VIEW where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable AllUsers()
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype = 0 order by cast(joindate as datetime) DESC";
            //string SQLQuery = "select view1.name,view1.mobileno,view1.referal_mobile as refMobile,view1.ACTIVATION_DATE,view1.referalID,view1.userid,view2.name as refName,tbl.city_name as city from ALL_MEMBERS_VIEW as view1 left join ALL_MEMBERS_VIEW view2 ON view1.referalID = view2.userid left join Cities as tbl ON view1.city = tbl.city_id where activeuser='A'  order by cast(view1.ACTIVATION_DATE as datetime) DESC";
            // string SQLQuery = "SELECT USERID, FULLNAME, EMAILID, MOBILENO,REF_NAME,REFERID,BV,ACTIVATION_DATE,AFFILIATE_DATE,USER_STATUS,  DBO.FN_GET_DETAILS_BY_USERID( USERID,'CITY')CITY  FROM REGISTRION_DETAILS_VIEW V WHERE USER_STATUS <> ''  order by cast(AFFILIATE_DATE as datetime) DESC";
            //string SQLQuery = "SELECT V.USERID, V.FULLNAME, V.EMAILID, V.MOBILENO, V.REF_NAME, V.REFERID, V2.MOBILENO as REFERMobile,V.ACTIVATION_DATE,V.AFFILIATE_DATE,V.USER_STATUS, DBO.FN_GET_DETAILS_BY_USERID( V.USERID,'CITY')CITY,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS='') InActive,(select count (*) from REGISTRION_DETAILS_VIEW as v1 where V2.USERID=v1.REFERID and USER_STATUS <>'') Active FROM REGISTRION_DETAILS_VIEW V LEFT OUTER JOIN ALL_MEMBERS_VIEW V2 ON V.REFERID = V2.USERID WHERE V.USER_STATUS IN ('P' ,'PA' ,'FA', 'U')ORDER BY CAST(V.AFFILIATE_DATE AS DATETIME) DESC";
            // string SQLQuery = "select f.userid,f.joindate ,f.ACTIVATION_DATE,f.name,f.mobileno,tf.name as ref_name,f.referal_mobile,f.referalID,c.cityname from tbl_freememreg f left outer join tbl_freememreg tf on f.referalID = tf.userid left outer join tbl_cities c on c.cityid = f.city ORDER BY  f.joindate DESC";
            // string SQLQuery = "SELECT userid,mobileno,name,emailid,city,referalID,joindate,ACTIVATION_DATE FROM tbl_freememreg where activeuser='A' UNION ALL SELECT userid,mobileno,fullname,emailid,city,referid,joindate,ACTIVATION_DATE FROM tbl_registration";


            // string SQLQuery = "exec [dbo].[USP_ADMIN_SHOW_USERS_DATA] 'ALL_USERS' ";
            string SQLQuery = "exec [dbo].[USP_ADMIN_SHOW_USERS_DATA] 'ALL_USERS','ABCD'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable AllUsers(string userid)
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype > 0 order by cast(joindate as datetime) DESC";
            string SQLQuery = "select * from ALL_MEMBERS_VIEW where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable RawData()
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype = 0 order by cast(joindate as datetime) DESC";
            //string SQLQuery = "select view1.name,view1.mobileno,view1.referal_mobile as refMobile,view1.ACTIVATION_DATE,view1.referalID,view1.userid,view2.name as refName,tbl.city_name as city from ALL_MEMBERS_VIEW as view1 left join ALL_MEMBERS_VIEW view2 ON view1.referalID = view2.userid left join Cities as tbl ON view1.city = tbl.city_id  where activeuser='NA' order by cast(view1.ACTIVATION_DATE as datetime) DESC";
            // string SQLQuery = "SELECT USERID, FULLNAME, EMAILID, MOBILENO,REF_NAME,REFERID,BV,ACTIVATION_DATE,AFFILIATE_DATE,USER_STATUS,  DBO.FN_GET_DETAILS_BY_USERID( USERID,'CITY')CITY  FROM REGISTRION_DETAILS_VIEW V WHERE USER_STATUS =''  order by cast(AFFILIATE_DATE as datetime) DESC";
            //string SQLQuery = "SELECT V.USERID, V.FULLNAME, V.EMAILID, V.MOBILENO, V.REF_NAME, V.REFERID, V2.MOBILENO as REFERMobile,V2.ACTIVATION_DATE,V.JOINDATE,V.ACTIVESTATUS, DBO.FN_GET_DETAILS_BY_USERID( V.USERID,'CITY')CITY FROM REGISTRION_DETAILS_VIEW V LEFT OUTER JOIN ALL_MEMBERS_VIEW V2 ON V.REFERID = V2.USERID WHERE V.USER_STATUS ='' ORDER BY V.JOINDATE DESC";
            //string SQLQuery = "SELECT V.USERID, V.FULLNAME, V.EMAILID, V.MOBILENO, V.REF_NAME, V.REFERID, V2.MOBILENO as REFERMobile,V2.ACTIVATION_DATE,V.JOINDATE, DBO.FN_GET_DETAILS_BY_USERID( V.USERID,'CITY')CITY FROM REGISTRION_DETAILS_VIEW V LEFT OUTER JOIN ALL_MEMBERS_VIEW V2 ON V.REFERID = V2.USERID WHERE V.USER_STATUS ='' ORDER BY V.JOINDATE DESC";
            string SQLQuery = "select f.userid,f.joindate ,f.ACTIVATION_DATE,f.name,f.mobileno,tf.name as ref_name,f.referal_mobile,f.referalID,c.cityname from tbl_freememreg f left outer join tbl_freememreg tf on f.referalID = tf.userid left outer join tbl_cities c on c.cityid = f.city where f.activeuser='NA' ORDER BY  f.joindate DESC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable RawData(string userid)
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype > 0 order by cast(joindate as datetime) DESC";
            string SQLQuery = "select * from ALL_MEMBERS_VIEW where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataSet ReferalMember(string referid, string userid)
    {
        try
        {
            //string SQLQuery = "select * from tbl_registration where producttype > 0 order by cast(joindate as datetime) DESC";
            // string SQLQuery = "select * from ALL_MEMBERS_VIEW where userid='" + userid + "'";
            string SQLQuery = "select * from REGISTRION_DETAILS_VIEW where USERID='" + referid + "';select * from REGISTRION_DETAILS_VIEW where REFERID='" + userid + "';";

            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getActiveUserDataFromAdminSession(string sSessionID)
    {
        try
        {
            string sQry = "SELECT SESSION_ID,USER_ID,MOBILE_NO,FULLNAME,EMAIL_ID,CITY_NAME,JOIN_DATE,JOIN_DATE_106,ACTIVATION_DATE,ACTIVATION_DATE_106,AFFILIATE_DATE,AFFILIATE_DATE_106,REF_ID,REF_NAME,REF_MOBILE, ISNULL(TOTAL_ACTIVATED, 0) TOTAL_ACTIVATED,ISNULL(TOTAL_ELIGIBLE, 0) TOTAL_ELIGIBLE, ISNULL(TOTAL_INVITED, 0) TOTAL_INVITED, ISNULL(TOTAL_INACTIVE ,0) TOTAL_INACTIVE  FROM TMP_USER_DATA  WHERE SESSION_ID = '" + sSessionID + "' AND isnull(TOTAL_ACTIVATED ,0) < 20 ORDER BY ACTIVATION_DATE DESC, JOIN_DATE DESC";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getInActiveUserDataFromAdminSession(string sSessionID)
    {
        try
        {
            string sQry = "SELECT SESSION_ID,USER_ID,MOBILE_NO,FULLNAME,EMAIL_ID,CITY_NAME,JOIN_DATE,JOIN_DATE_106,ACTIVATION_DATE,ACTIVATION_DATE_106,AFFILIATE_DATE,AFFILIATE_DATE_106,REF_ID,REF_NAME,REF_MOBILE,isnull(TOTAL_INVITED ,0) TOTAL_INVITED,isnull(TOTAL_ACTIVATED ,0) TOTAL_ACTIVATED,isnull(TOTAL_INACTIVE ,0) TOTAL_INACTIVE,RECORD_DATETIME  FROM TMP_USER_DATA  WHERE SESSION_ID = '" + sSessionID + "'  ORDER BY JOIN_DATE DESC";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getAllUserDataFromAdminSession(string sSessionID)
    {
        try
        {
            string sQry = "SELECT SESSION_ID,USER_ID,MOBILE_NO,FULLNAME,EMAIL_ID,CITY_NAME,JOIN_DATE,JOIN_DATE_106,ACTIVATION_DATE,ACTIVATION_DATE_106,AFFILIATE_DATE,AFFILIATE_DATE_106,REF_ID,REF_NAME,REF_MOBILE,isnull(TOTAL_INVITED ,0) TOTAL_INVITED,isnull(TOTAL_ACTIVATED ,0) TOTAL_ACTIVATED,ISNULL(TOTAL_ELIGIBLE, 0) TOTAL_ELIGIBLE,isnull(TOTAL_INACTIVE ,0) TOTAL_INACTIVE,RECORD_DATETIME  FROM TMP_USER_DATA  WHERE SESSION_ID = '" + sSessionID + "'  ORDER BY AFFILIATE_DATE DESC , ACTIVATION_DATE DESC, JOIN_DATE DESC";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable testQuery(string querry)
    {

        try
        {
            string sQry = querry;
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    //select userid, mobileno, fullname from tbl_registration where userid in (
    //SELECT  dbo.FN_GET_IMMEDIATE_APPLAINER(i.userid) FROM TBL_INVITEFRIENDS I 
    //INNER JOIN ALL_MEMBERS_VIEW V ON I.USERID = V.USERID 
    //LEFT OUTER JOIN TBL_EDITPROFILE E ON V.USERID = E.USERID 
    //WHERE ISNULL(I.CITY , E.[CITY/AREA]) IN (SELECT CITY_ID FROM CITIES WHERE ISNULL(DIST_ID, '0') IN ('231','232')) And v.activeuser='A')


    public DataTable GeneralReportActiveUsers()
    { 
        try
        {
            // string SQLQuery = "select userid, mobileno, fullname from tbl_registration where userid in ";
            //SQLQuery = SQLQuery + " (SELECT  dbo.FN_GET_IMMEDIATE_APPLAINER(i.userid) FROM TBL_INVITEFRIENDS I ";
            //SQLQuery = SQLQuery + " INNER JOIN ALL_MEMBERS_VIEW V ON I.USERID = V.USERID ";
            //SQLQuery = SQLQuery + " LEFT OUTER JOIN TBL_EDITPROFILE E ON V.USERID = E.USERID ";
            //SQLQuery = SQLQuery + " WHERE ISNULL(I.CITY , E.[CITY/AREA]) IN (SELECT CITY_ID FROM CITIES WHERE ISNULL(DIST_ID, '0') IN ('231','232')) And v.activeuser='A')";
            //SQLQuery = SQLQuery + " order by fullname";

            //string SQLQuery = "select userid, mobileno, fullname from tbl_registration where userid in  (SELECT  dbo.FN_GET_IMMEDIATE_APPLAINER(userid) ";
            //SQLQuery = String.Concat(SQLQuery, " FROM TBL_ACTIVE_USERS WHERE CITY IN (SELECT CITY_ID FROM CITIES WHERE ISNULL(DIST_ID, '0') IN ('231','232')) ) order by fullname");

            string SQLQuery = "select userid, mobileno, fullname from tbl_registration where userid in  (SELECT  top 100 dbo.FN_GET_IMMEDIATE_APPLAINER(userid) ";
            SQLQuery = String.Concat(SQLQuery, " FROM TBL_ACTIVE_USERS WHERE CITY IN (SELECT CITY_ID FROM CITIES WHERE ISNULL(DIST_ID, '0') IN ('231','232')) order by newid() ) order by fullname");

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
//    SELECT  i.mobileno, i.fname FROM TBL_INVITEFRIENDS I 
//INNER JOIN ALL_MEMBERS_VIEW V ON I.USERID = V.USERID 
//LEFT OUTER JOIN TBL_EDITPROFILE E ON V.USERID = E.USERID 
//WHERE ISNULL(I.CITY , E.[CITY/AREA]) IN (SELECT CITY_ID FROM CITIES WHERE ISNULL(DIST_ID, '0') IN ('231','232')) And v.activeuser='A'
//and i.userid in (select userid from dbo.FN_USER_TREE_ACTIVE_NETWORK_MEMBERS('2328441831183451'))


    public DataTable GeneralReportReferalUsers(string userid)
    {
        try
        {
            /*
            string SQLQuery = "SELECT  i.mobileno, i.fname , d.PERSONAL_INVITED, d.PERSONAL_ACTIVATED, d.NETWORK_INVITED, d.NETWORK_ACTIVATED FROM TBL_INVITEFRIENDS I ";
            SQLQuery = SQLQuery + " INNER JOIN ALL_MEMBERS_VIEW V ON I.USERID = V.USERID ";
            SQLQuery = SQLQuery + " LEFT OUTER JOIN TBL_EDITPROFILE E ON V.USERID = E.USERID ";
            SQLQuery = SQLQuery + " LEFT OUTER JOIN TBL_USER_INVITATIONS_DATA D on v.userid = d.userid";
            SQLQuery = SQLQuery + " WHERE ISNULL(I.CITY , E.[CITY/AREA]) IN (SELECT CITY_ID FROM CITIES WHERE ISNULL(DIST_ID, '0') IN ('231','232')) And v.activeuser='A' ";
            SQLQuery = SQLQuery + " and i.userid in (select userid from dbo.FN_USER_TREE_AFFILIATE_ACTIVE_NETWORK_MEMBERS('" + userid + "'))";
            
            */

            string sQry = "SELECT  A.mobileno, CASE WHEN a.UPGRADED_PAID_DEACTIVE = 1 THEN  A.name + '**' ELSE A.NAME END FNAME,  d.PERSONAL_INVITED, d.PERSONAL_ACTIVATED, d.NETWORK_INVITED, d.NETWORK_ACTIVATED ";
            sQry = string.Concat(sQry, " FROM tbl_active_users a");
            sQry = string.Concat(sQry, " LEFT OUTER JOIN TBL_USER_INVITATIONS_DATA D on a.userid = d.userid ");
            sQry = string.Concat(sQry, " WHERE A.DISTRICT IN ('231','232')");
            sQry = string.Concat(sQry, " and A.userid in (select userid from dbo.FN_USER_TREE_AFFILIATE_ACTIVE_NETWORK_MEMBERS('" + userid + "'))");


            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getAffiliateImageDetails()
    {
        try
        {
            string sqlquery = "SELECT R.USERID, R.FULLNAME, I.IMAGENAME,I.ORIGINAL_CURRENT_IMAGE, ISNULL(AI.IS_VALID_AFFILIATE_IMAGE , 0) IS_VALID_AFFILIATE_IMAGE, R.AFFILIATE_DATE FROM TBL_REGISTRATION R INNER JOIN TBL_IMAGEDETAIL I ON R.USERID = I.USERID LEFT OUTER JOIN TBL_USER_ADDITIONAL_INFO AI ON R.USERID = AI.USERID ORDER BY ISNULL(AI.IS_VALID_AFFILIATE_IMAGE , 0) ASC, R.AFFILIATE_DATE DESC ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable getAffiliateImageDetails(string searchcriteria)
    {
        try
        {
            string sqlquery = "SELECT R.USERID, R.FULLNAME, I.IMAGENAME,I.ORIGINAL_CURRENT_IMAGE, ISNULL(AI.IS_VALID_AFFILIATE_IMAGE , 0) IS_VALID_AFFILIATE_IMAGE, R.AFFILIATE_DATE FROM TBL_REGISTRATION R INNER JOIN TBL_IMAGEDETAIL I ON R.USERID = I.USERID LEFT OUTER JOIN TBL_USER_ADDITIONAL_INFO AI ON R.USERID = AI.USERID  where fullname like '%" + searchcriteria + "%' or emailid like '%" + searchcriteria + "%' or mobileno like '%" + searchcriteria + "%' ORDER BY ISNULL(AI.IS_VALID_AFFILIATE_IMAGE , 0) ASC, R.AFFILIATE_DATE DESC";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable GetValidAffiliates()
    {
        try
        {
            string SQLQuery = "select I.imagename IMAGE,F.fullname NAME from TBL_USER_ADDITIONAL_INFO AI inner join tbl_imagedetail I on AI.USERID=I.userid ";
            SQLQuery += "inner join tbl_registration F on F.userid= AI.USERID where IS_VALID_AFFILIATE_IMAGE=1";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {   
            throw Ex;
        }
    }
    public DataTable GetValidAffiliatesBycount(int count)
    {
        try
        {
            string SQLQuery = "select top " + count + " I.imagename IMAGE,F.fullname NAME,F.USERID from TBL_USER_ADDITIONAL_INFO AI inner join tbl_imagedetail I on AI.USERID=I.userid ";
            SQLQuery += "inner join tbl_registration F on F.userid= AI.USERID where IS_VALID_AFFILIATE_IMAGE=1 order by newid()";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}

