﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for EntScreen
/// </summary>
public class EntScreen
{
    private string screenName;
    private string menuID;
    private int parentID;
    private string screenURL;
    private int statusID;
    private DateTime createdDate;
    private DateTime updatedDate;

    public string ScreenName
    {
        get { return screenName; }
        set { screenName = value; }
    }

    public string MenuID
    {
        get { return menuID; }
        set { menuID = value; }
    }

    public int ParentID
    {
        get { return parentID; }
        set { parentID = value; }
    }

    public string ScreenURL
    {
        get { return screenURL; }
        set { screenURL = value; }
    }

    public int StatusID
    {
        get { return statusID; }
        set { statusID = value; }
    }

    public DateTime CreatedDate
    {
        get { return createdDate; }
        set { createdDate = value; }
    }

    public DateTime UpdatedDate
    {
        get { return updatedDate; }
        set { updatedDate = value; }
    }



	public EntScreen()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}