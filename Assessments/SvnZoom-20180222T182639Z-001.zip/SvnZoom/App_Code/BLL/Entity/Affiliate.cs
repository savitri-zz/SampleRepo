﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Affiliate
/// </summary>
public class Affiliate
{
    private int sno;

    public int Sno
    {
        get { return sno; }
        set { sno = value; }
    }
    private string userid;

    public string Userid
    {
        get { return userid; }
        set { userid = value; }
    }
    private string fullname;

    public string Fullname
    {
        get { return fullname; }
        set { fullname = value; }
    }
    private string emailId;

    public string EmailId
    {
        get { return emailId; }
        set { emailId = value; }
    }
    private string mobileNo;

    public string MobileNo
    {
        get { return mobileNo; }
        set { mobileNo = value; }
    }
    private string joindate;

    public string Joindate
    {
        get { return joindate; }
        set { joindate = value; }
    }
    private DateTime aCTIVATION_DATE;

    public DateTime ACTIVATION_DATE
    {
        get { return aCTIVATION_DATE; }
        set { aCTIVATION_DATE = value; }
    }
    private DateTime aFFILIATE_DATE;

    public DateTime AFFILIATE_DATE
    {
        get { return aFFILIATE_DATE; }
        set { aFFILIATE_DATE = value; }
    }

	public Affiliate()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}