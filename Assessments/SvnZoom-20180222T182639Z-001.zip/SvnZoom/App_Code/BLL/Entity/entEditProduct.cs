﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for entEditProduct
/// </summary>
public class entEditProduct
{
	public entEditProduct()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    private string _Product_name = "";
    private string _mrp = "";
    private string _BV = "";
    private string _Points = "";
    private string _Pindelear_charges = "";
    private string _tax = "";
    private string _otherServices_Charge = "";
    private string _point_value = "";
    private string _DP_DelearPrice = "";
    private string _SMS_SetupCost = "";
    private string _SMS_SetupCost_percentage = "";
    private string _Net_Amount = "";
    private string _DevelopMentCharges = "";
    private string _DevelopMentCharges_percentage = "";
    private string _Balance = "";
    private string _Binary_CV = "";
    private string _Unilevel_CV = "";
    private string _Network_Sharing = "";
    private string _Bit2byte_profit = "";

    public string Product_name
    {
        get
        {
            return _Product_name;

        }
        set
        {
            _Product_name = value;

        }

    }

    public string mrp
    {
        get
        {
            return _mrp;
        }
        set
        {
            _mrp = value;
        }
    }
    public string BV
    {
        get
        {
            return _BV;
        }
        set
        {
            _BV = value;
        }
    }

    public string Points
    {
        get
        {
            return _Points;

        }
        set
        {
            _Points = value;

        }

    }

    public string Pindelear_charges
    {
        get
        {
            return _Pindelear_charges;
        }
        set
        {
            _Pindelear_charges = value;
        }
    }

    public string tax
    {
        get
        {
            return _tax;
        }
        set
        {
            _tax = value;
        }
    }
    public string otherServices_Charge
    {
        get
        {
            return _otherServices_Charge;

        }
        set
        {
            _otherServices_Charge = value;

        }

    }

    public string point_value
    {
        get
        {
            return _point_value;
        }
        set
        {
            _point_value = value;
        }
    }
    public string DP_DelearPrice
    {
        get
        {
            return _DP_DelearPrice;

        }
        set
        {
            _DP_DelearPrice = value;

        }

    }

    public string SMS_SetupCost
    {
        get
        {
            return _SMS_SetupCost;
        }
        set
        {
            _SMS_SetupCost = value;
        }
    }


    public string SMS_SetupCost_percentage
    {
        get
        {
            return _SMS_SetupCost_percentage;
        }
        set
        {
            _SMS_SetupCost_percentage = value;
        }
    }
    public string Net_Amount
    {
        get
        {
            return _Net_Amount;

        }
        set
        {
            _Net_Amount = value;

        }

    }

    public string DevelopMentCharges
    {
        get
        {
            return _DevelopMentCharges;
        }
        set
        {
            _DevelopMentCharges = value;
        }
    }

    public string DevelopMentCharges_percentage
    {
        get
        {
            return _DevelopMentCharges_percentage;
        }
        set
        {
            _DevelopMentCharges_percentage = value;
        }
    }
    public string Balance
    {
        get
        {
            return _Balance;
        }
        set
        {
            _Balance = value;
        }
    }

    public string Binary_CV
    {
        get
        {
            return _Binary_CV;
        }
        set
        {
            _Binary_CV = value;
        }
    }
    public string Unilevel_CV
    {
        get
        {
            return _Unilevel_CV;
        }
        set
        {
            _Unilevel_CV = value;
        }
    }
    public string Network_Sharing
    {
        get
        {
            return _Network_Sharing;
        }
        set
        {
            _Network_Sharing = value;
        }
    }

    public string Bit2byte_profit
    {
        get
        {
            return _Bit2byte_profit;
        }
        set
        {
            _Bit2byte_profit = value;
        }
    }
    
}