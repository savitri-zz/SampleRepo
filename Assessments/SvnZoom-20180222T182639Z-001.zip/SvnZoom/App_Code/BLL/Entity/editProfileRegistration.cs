﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for editProfileRegistration
/// </summary>
public class editProfileRegistration 
{
	public editProfileRegistration()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private string _inivted_user = "";
    private string _fname = "";
    private string _lname = "";
    private string _gender = "";
    private string _agegroup = "";
    private string _mobileno = "";
    private string _emailid = "";
    private string _area = "";
    private string _address = "";
    private string _pincode = "";
    private string _country = "";
    private string _state = "";
    private string _district = "";
    private string _city = "";
    private string _occupation = "";
    private string _checkeditem = "";
    private string _invited_date = "";

    private string _status = "";
    private string _invited_user_status = "";
    private string _active_status = "";
    private string _dob = "";
    private string _othercityarea = "";

    private string _education = "";
    private string _industry = "";
    private string _incomerange = "";
    private string _points = "25";
    private string _userid = "";
    private string _placement = "";
    private string _placementID = "";

    private string _InvitedThrough = "";

    public string PlacementID
    {
        get { return _placementID; }
        set { _placementID = value; }
    }
    private string _sponsorUserID = "";

    public string SponsorUserID
    {
        get { return _sponsorUserID; }
        set { _sponsorUserID = value; }
    }
    private string _referID = "";

    public string ReferID
    {
        get { return _referID; }
        set { _referID = value; }
    }

   

    public string inivted_user
    {
        get
        {
            return _inivted_user;

        }
        set
        {
            _inivted_user = value;

        }

    }

    public string fname
    {
        get
        {
            return _fname;
        }
        set
        {
            _fname = value;
        }
    }

    public string lname
    {
        get
        {
            return _lname;

        }
        set
        {
            _lname = value;

        }

    }

    public string gender 
    {
        get
        {
            return _gender;
        }
        set
        {
            _gender = value;
        }
    }

    public string agegroup
    {
        get
        {
            return _agegroup;
        }
        set
        {
            _agegroup = value;
        }
    }
    public string mobileno
    {
        get
        {
            return _mobileno;

        }
        set
        {
            _mobileno = value;

        }

    }

    public string emailid
    {
        get
        {
            return _emailid;
        }
        set
        {
            _emailid = value;
        }
    }
    public string area
    {
        get
        {
            return _area;

        }
        set
        {
            _area = value;

        }

    }

    public string address
    {
        get
        {
            return _address;
        }
        set
        {
            _address = value;
        }
    }
   

    public string pincode
    {
        get
        {
            return _pincode;
        }
        set
        {
            _pincode = value;
        }
    }
    public string country
    {
        get
        {
            return _country;

        }
        set
        {
            _country = value;

        }

    }

    public string state
    {
        get
        {
            return _state;
        }
        set
        {
            _state = value;
        }
    }

    public string district
    {
        get
        {
            return _district;
        }
        set
        {
            _district = value;
        }
    }
    public string city
    {
        get
        {
            return _city;
        }
        set
        {
            _city = value;
        }
    }

    public string occupation
    {
        get
        {
            return _occupation;
        }
        set
        {
            _occupation = value;
        }
    }
    public string checkeditem
    {
        get
        {
            return _checkeditem;
        }
        set
        {
            _checkeditem = value;
        }
    }
    public string invited_date
    {
        get
        {
            return _invited_date;
        }
        set
        {
            _invited_date = value;
        }
    }

    public string status
    {
        get
        {
            return _status;
        }
        set
        {
            _status = value;
        }
    }

    public string invited_user_status
    {
        get
        {
            return _invited_user_status;
        }
        set
        {
            _invited_user_status = value;
        }
    }
    public string active_status
    {
        get
        {
            return _active_status;
        }
        set
        {
            _active_status = value;
        }
    }
    public string othercityarea
    {
        get
        {
            return _othercityarea;
        }
        set
        {
            _othercityarea = value;
        }
    }
    public string education
    {
        get
        {
            return _education;
        }
        set
        {
            _education = value;
        }
    }
    public string dob
    {
        get
        {
            return _dob;
        }
        set
        {
            _dob = value;
        }
    }

    public string industry
    {
        get
        {
            return _industry;
        }
        set
        {
            _industry = value;
        }
    }
    public string incomerange
    {
        get
        {
            return _incomerange;
        }
        set
        {
            _incomerange = value;
        }
    }
    public string points
    {
        get
        {
            return _points;
        }
        set
        {
            _points = value;
        }
    }

    public string userid 
    {
        get
        {
            return _userid;
        }
        set
        {
            _userid = value;
        }
    }
    public string Placement
    {
        get { return _placement; }
        set { _placement = value; }
    }

    public string InvitedThrough
    {
        get { return _InvitedThrough; }
        set { _InvitedThrough = value; }
    }

}