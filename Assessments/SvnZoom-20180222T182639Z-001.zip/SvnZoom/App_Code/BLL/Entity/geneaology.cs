﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for geneaology
/// </summary>
public class geneaology:BaseClass 

{
	public geneaology()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable Getplacement(string refid, string placement)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where placementid='" + refid + "' and placement='" + placement + "'  ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getpersonalcommision(string refid , string inviteddate)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid='" + refid + "'  and CAST(joindate as DATE) <=  '" + inviteddate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getpersonalcommbetweendates(string refid, string startdate , string enddate)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid='" + refid + "'  and CAST(joindate as DATE) between  '" + startdate + "' and '" + enddate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getpersonalcommisionday(string refid, string inviteddate)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid='" + refid + "'  and CAST(joindate as DATE) =  '" + inviteddate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable imagedetails(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + uid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getpackagename(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Products where sno='" + uid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getproductBVsum(string productid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Products where sno = '" + productid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getreferids(string refid, string placement)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where referid='" + refid + "' and placement='" + placement + "'  ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public DataTable Getplacementref(string refid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + refid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable Getplaacementno(string refid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + refid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}