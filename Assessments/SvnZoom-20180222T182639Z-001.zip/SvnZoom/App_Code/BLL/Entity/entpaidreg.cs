using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for AdminFooter
/// </summary>
public class entpaidreg
{
    public entpaidreg()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private string _producttype = "";
    private string _mobileno;
    private string _password = "";
    private string _fullname = "";
    private string _emailid = "";
    private string _state = "";
    private string _city = "";
    private string _placement = "";
    private string _SponsorUserID = "";
    private string _levelno = "";
    private string _referid = "";
    private string _status = "";
    private string _usertype = "";
    private string _placementid = "";
    private string _userid = "";
    private string _joindate = "";
    private string _verificationcode = "";
    private string _TransactionId = "";
    private string _upgrade = "";
    private string _initpakg = "";
  



    public string producttype
    {
        get
        {
            return _producttype;
        }
        set
        {
            _producttype = value;
        }
    }

    public string mobileno
    {
        get
        {
            return _mobileno;
        }
        set
        {
            _mobileno = value;
        }
    }


    public string password
    {
        get
        {
            return _password;
        }
        set
        {
            _password = value;
        }
    }

    public string userid
    {
        get
        {
            return _userid;
        }
        set
        {
            _userid = value;
        }
    }


    public string fullname
    {
        get
        {
            return _fullname;
        }
        set
        {
            _fullname = value;
        }
    }

    public string emailid
    {
        get
        {
            return _emailid;
        }
        set
        {
            _emailid = value;
        }
    }

    public string state
    {
        get
        {
            return _state;
        }
        set
        {
            _state = value;
        }
    }

    public string city
    {
        get
        {
            return _city;
        }
        set
        {
            _city = value;
        }
    }

    public string placement
    {
        get
        {
            return _placement;
        }
        set
        {
            _placement = value;
        }
    }

    public string SponsorUserID
    {
        get
        {
            return _SponsorUserID;
        }
        set
        {
            _SponsorUserID = value;
        }
    }

    public string levelno
    {
        get
        {
            return _levelno;
        }
        set
        {
            _levelno = value;
        }
    }

    public string referid
    {
        get
        {
            return _referid;
        }
        set
        {
            _referid = value;
        }
    }

    public string status
    {
        get
        {
            return _status;
        }
        set
        {
            _status = value;
        }
    }
    public string usertype
    {
        get
        {
            return _usertype;
        }
        set
        {
            _usertype = value;
        }
    }
    public string placementid
    {
        get
        {
            return _placementid;
        }
        set
        {
            _placementid = value;
        }
    }

    public string joindate
    {

        get
        {
            return _joindate;
        }
        set
        {
            _joindate = value;
        }
    }

    public string verificationcode
    {
        get
        {

            return _verificationcode;
        }
        set
        {
            _verificationcode = value;
        }

    }

    public string TransactionId
    {
        get
        {

            return _TransactionId;
        }
        set
        {
            _TransactionId = value;
        }
    }

    public string upgrade
    {
        get
        {
            return _upgrade;
        }
        set 
        {
            _upgrade = value;
        }
    }

    public string initpakg
    {
        get
        {
            return _initpakg;
        }
        set
        {
            _initpakg = value;
        }
    
    }
}
