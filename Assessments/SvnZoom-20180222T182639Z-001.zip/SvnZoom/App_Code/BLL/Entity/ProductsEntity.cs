﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class ProductsEntity
{
	public ProductsEntity()
	{
		
	}
    private int _productid = 0;
    private string _code="";
    private string _productname = "";
    private double _cost = 0.0;
    private double _quantity = 0;
    private double _total = 0;
    private double _tax = 0.0;
    private double _mrp = 0.0;
    private double _dealerprice = 0.0;
    private double _profit = 0.0;
    private double _margin = 0;
    private double _devchrges = 0;
    private double _bonus = 0;
    private double _balance = 0;
    private int _cv = 0;
    private int _BV = 0;
    private int _bonusBV = 0;
    private int _data = 0;
    private int _extradata = 0;
    private int _ppdata = 0;
    private double _points = 0;
    private double _totalPoints = 0;
    private double _PV = 0;
    private double _totalPV = 0;
    private double _elgPV = 0;
    private double _extraPV = 0;
    private double _netElgPV = 0;
    private double _crtmpble = 0;
    private double _payable = 0;
    private double _paid = 0;
    private double _accountBalance = 0;
    private double _delerpricepersent=0.0;
    private double _marginpersent = 0;
    private double _devchargespersent = 0;
    private double _bonuspersent = 0;
    private double _cvpersent = 0;
    private double _elgpvpersent = 0;

    public int ProductId
    {
        get
        {
            return _productid;
        }
        set
        {
            _productid = value;
        }
    }

    public string code
    {
        get
        {
            return _code;
        }
        set
        {
            _code = value;
        }
    }

    public string productname
    {
        get
        {
            return _productname;
        }
        set
        {
            _productname = value;
        }
    }

    public double cost
    {
        get
        {
            return _cost;
        }
        set
        {
            _cost = value;
        }
    }

    public double quantity
    {
        get
        {
            return _quantity;
        }
        set
        {
            _quantity = value;
        }
    }

    public double total
    {
        get
        {
            return _total;
        }
        set
        {
            _total = value;
        }
    }

    public double tax
    {
        get
        {
            return _tax;
        }
        set
        {
            _tax = value;
        }
    }

    public double mrp
    {
        get
        {
            return _mrp;
        }
        set
        {
            _mrp = value;
        }
    }

    public double dealerprice
    {
        get
        {
            return _dealerprice;
        }
        set
        {
            _dealerprice = value;
        }
    }

    public double profit
    {
        get
        {
            return _profit;
        }
        set
        {
            _profit = value;
        }
    }

    public double margin
    {
        get
        {
            return _margin;
        }
        set
        {
            _margin = value;
        }
    }

    public double devchrges
    {
        get
        {
            return _devchrges;
        }
        set
        {
            _devchrges = value;
        }
    }

    public double bonus
    {
        get
        {
            return _bonus;
        }
        set
        {
            _bonus = value;
        }
    }

    public double balance
    {
        get
        {
            return _balance;
        }
        set
        {
            _balance = value;
        }
    }

    public int cv
    {
        get
        {
            return _cv;
        }
        set
        {
            _cv = value;
        }
    }

    public int BV
    {
        get
        {
            return _BV;
        }
        set
        {
            _BV = value;
        }
    }

    public int bonusBV
    {
        get
        {
            return _bonusBV;
        }
        set
        {
            _bonusBV = value;
        }
    }

    public int data
    {
        get
        {
            return _data;
        }
        set
        {
            _data = value;
        }
    }

    public int extradata
    {
        get
        {
            return _extradata;
        }
        set
        {
            _extradata = value;
        }
    }

    public int ppdata
    {
        get
        {
            return _ppdata;
        }
        set
        {
            _ppdata = value;
        }
    }

    public double points
    {
        get
        {
            return _points;
        }
        set
        {
            _points = value;
        }
    }

    public double totalPoints
    {
        get
        {
            return _totalPoints;
        }
        set
        {
            _totalPoints = value;
        }
    }

    public double pv
    {
        get
        {
            return _PV;
        }
        set
        {
            _PV = value;
        }
    }

    public double totalPV
    {
        get
        {
            return _totalPV;
        }
        set
        {
            _totalPV = value;
        }
    }

    public double elgPV
    {
        get
        {
            return _elgPV;
        }
        set
        {
            _elgPV = value;
        }
    }

    public double extraPV
    {
        get
        {
            return _extraPV;
        }
        set
        {
            _extraPV = value;
        }
    }

    public double netElgPV
    {
        get
        {
            return _netElgPV;
        }
        set
        {
            _netElgPV = value;
        }
    }

    public double crtmpble
    {
        get
        {
            return _crtmpble;
        }
        set
        {
            _crtmpble = value;
        }
    }

    public double payable
    {
        get
        {
            return _payable;
        }
        set
        {
            _payable = value;
        }
    }

    public double paid
    {
        get
        {
            return _paid;
        }
        set
        {
            _paid = value;
        }
    }

    public double accountBalance
    {
        get
        {
            return _accountBalance;
        }
        set
        {
            _accountBalance = value;
        }
    }

    public double delerpricePersent
    {
        get
        {
            return _delerpricepersent;
        }
        set
        {
            _delerpricepersent = value;
        }
    }

    public double marginpersent
    {
        get
        {
            return _marginpersent;
        }
        set
        {
            _marginpersent = value;
        }
    }

    public double devchargespersent
    {
        get
        {
            return _devchargespersent;
        }
        set
        {
            _devchargespersent = value;
        }
    }

    public double bonuspersent
    {
        get
        {
            return _bonuspersent;
        }
        set
        {
            _bonuspersent = value;
        }
    }

    public double cvpersent
    {
        get
        {
            return _cvpersent;
        }
        set
        {
            _cvpersent = value;
        }
    }

    public double elgpvpersent
    {
        get
        {
            return _elgpvpersent;
        }
        set
        {
            _elgpvpersent = value;
        }
    }

}