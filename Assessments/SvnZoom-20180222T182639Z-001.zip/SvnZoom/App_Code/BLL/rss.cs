﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for rss
/// </summary>
public class rss : BaseClass
{
    public rss()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //*************commented by vasu on 20 Nov 2014 for News on the basis ************

    //public DataTable selectnewsports()
    //{
    //    try
    //    {
    //        string sqlquery = "select * from table_sportsandnews order by sno desc";
    //        return GetDataTable(sqlquery, true);
    //    }
    //    catch (Exception Ex)
    //    {
    //        throw Ex;
    //    }

    //}

    public DataTable selectnewsports()
    {
        try
        {
            //string sqlquery = "select top 10 sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename from table_sportsandnews  where link not like '%youtube%' and category != 'beauty' order by pubdate desc,NEWID()";
            string sqlquery = "SELECT TOP 10 SNO, TITLE, LINK, DESCRIPTION, STATUS, DISPLAYINGTIME, IMAGE, PUBDATE, PUBLISHER, REPLACE(REPLACE(IMAGE, 'HTTP://',''), '/','') IMAGENAME FROM TABLE_SPORTSANDNEWS  WHERE LINK NOT LIKE '%YOUTUBE%' AND CATEGORY != 'BEAUTY' AND IS_ACTIVE = 1 ORDER BY CONVERT(VARCHAR(30), CAST(PUBDATE AS DATETIME) , 102)DESC, NEWID()";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable selectnewsports(string category)
    {
        try
        {
            string sqlquery = "select top 10 sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(  replace(image , 'https://' , '') , 'http://',''), '/','') imagename,category from table_sportsandnews  where link not like '%youtube%' and category='" + category + "' and  is_active = 1 order by newid() desc";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable Get_News_By_Count(int count)
    {
        try
        {
            string sqlquery = "select top " + count + " sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(  replace(image , 'https://' , '') , 'http://',''), '/','') imagename,category from table_sportsandnews  where link not like '%youtube%' and is_active = 1 order by newid() desc";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable Get_Liked_News(int count)
    {
        try
        {
            /*
            string SQLQuery = "select top " + count.ToString() + " u.name username,u.IMAGE_NAME  userimage,u.userid, s.sno, s.title, s.link, s.image newsimage, s.pubdate, s.publisher ";
            SQLQuery += " from tbl_active_users U inner join  TBL_NEWS_USER_LIKES N on n.userid=u.userid INNER join table_sportsandnews s on n.NEWS_ID=s.sno";
            SQLQuery += " WHERE IS_ACTIVE = 1 and N.userid != 'au'";
            SQLQuery += " order by newid()";
            */

            string SQLQuery = "SELECT TOP 1 DATEDIFF(DAY, CLICKED_DT, GETDATE()),  U.NAME USERNAME,U.IMAGE_NAME  USERIMAGE,U.USERID, S.SNO, S.TITLE, S.LINK, S.IMAGE NEWSIMAGE, S.PUBDATE, S.PUBLISHER  ";
            SQLQuery += " FROM TBL_ACTIVE_USERS U  ";
            SQLQuery += " INNER JOIN TBL_NEWS_USER_LIKES N ON N.USERID=U.USERID  ";
            SQLQuery += " INNER JOIN TABLE_SPORTSANDNEWS S ON N.NEWS_ID=S.SNO  ";
            SQLQuery += " WHERE IS_ACTIVE = 1 AND N.USERID != 'AU'  ";
           // SQLQuery += " ORDER BY 1, NEWID() ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable SelectNewsForFullPost(int iSNo)
    {
        try
        {
            string sqlquery = " Select top 15 * from (select 1 Priority , sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename from table_sportsandnews  where sno =" + iSNo.ToString() + " and is_active = 1  ";
            sqlquery = sqlquery + "  Union select  2 Priority, sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename from table_sportsandnews  where link not like '%youtube%' and sno != " + iSNo.ToString() + " and category != 'Beauty' and is_active = 1 ) as dfl  order by Priority, newid() ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable SelectNewsForFullPost(string iSNo, string USERID)
    {
        try
        {
            string sqlquery = " Select top 15 * from (select 1 Priority , sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename, isnull(z.ZoomStatus, 0) ZoomStatus from table_sportsandnews  N  left outer join TBL_ZOOM_COLLECTIONS z on z.ColumnID = n.sno   and z.UserID = '" + USERID + "'   and z.TableName = 'TABLE_SPORTSANDNEWS'  where sno =" + iSNo.ToString() + " and is_active = 1  ";
            sqlquery = sqlquery + "  Union select  2 Priority, sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename, isnull(z.ZoomStatus, 0) ZoomStatus from table_sportsandnews  N  left outer join TBL_ZOOM_COLLECTIONS z on z.ColumnID = n.sno   and z.UserID =  '" + USERID + "'   and z.TableName = 'TABLE_SPORTSANDNEWS'  where link not like '%youtube%' and sno != " + iSNo.ToString() + " and category != 'Beauty' and is_active = 1 ) as dfl  order by Priority, newid() ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable SelectNewsForFullPost(int iSNo, string category, string USERID)
    {
        try
        {
            string sqlquery = " Select top 15 * from (select 1 Priority , sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename, isnull(z.ZoomStatus, 0) ZoomStatus  from table_sportsandnews  N  left outer join TBL_ZOOM_COLLECTIONS z on z.ColumnID = n.sno   and z.UserID = '" + USERID + "'   and z.TableName = 'TABLE_SPORTSANDNEWS'   where sno =" + iSNo.ToString() + " and category='" + category + "' and is_active = 1 ";
            sqlquery = sqlquery + " Union select  2 Priority, sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename , isnull(z.ZoomStatus, 0) ZoomStatus from table_sportsandnews  N  left outer join TBL_ZOOM_COLLECTIONS z on z.ColumnID = n.sno   and z.UserID =  '" + USERID + "'   and z.TableName = 'TABLE_SPORTSANDNEWS'   where link not like '%youtube%' and category='" + category + "' and sno != " + iSNo.ToString() + " and is_active = 1 ) as dfl  order by Priority, newid() ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable SelectNewsForFullPost(int iSNo, string category)
    {
        try
        {
            string sqlquery = " Select top 15 * from (select 1 Priority , sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename from table_sportsandnews  where sno =" + iSNo.ToString() + " and category='" + category + "' and is_active = 1 ";
            sqlquery = sqlquery + " Union select  2 Priority, sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename from table_sportsandnews  where link not like '%youtube%' and category='" + category + "' and sno != " + iSNo.ToString() + " and is_active = 1 ) as dfl  order by Priority, newid() ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable selectrssmovies()
    {
        try
        {
            string SQLQuery = "select * from tbl_rssmovies order by sno desc";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Get_News_Likes_By_UserID(string sNewsID, string sUID)
    {
        try
        {
            string SQLQuery = "select * from TBL_NEWS_USER_LIKES where USERID='" + sUID + "' and NEWS_ID='" + sNewsID + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertNewsClicks(string sNewsID, string sUID)
    {
        try
        {
            bllOpmlData cls = new bllOpmlData();
            string ss=cls.InsertZoomData(sUID, "TABLE_SPORTSANDNEWS", sNewsID);
           // string SQry = "insert into TBL_NEWS_USER_LIKES(NEWS_ID,USERID) values('" + sNewsID + "','" + sUID + "')";
            string SQry = "insert into TBL_NEWS_USER_LIKES(NEWS_ID,USERID) values('" + sNewsID + "','" + sUID + "')";
            int intRowAffect = fnExecuteNonQuery(SQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Get_News_Liked_Users(int count)
    {
        try
        {
            string SQLQuery = "select * from TBL_NEWS_USER_LIKES";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    //public void insertnewsports(string title, string link, string description, string image, string pubtime, string publisher, string sNewsType, string sCategoryName)
    //{
    //    try
    //    {
    //        string sqlquery = "insert into table_sportsandnews (title,link,description,displayingtime,image,pubdate,publisher, NEWSTYPE,CATEGORY) values(N'" + StringValidation.checkStringOrigFormat(title) + "',N'" + StringValidation.checkStringOrigFormat(link) + "',N'" + StringValidation.checkStringOrigFormat(description) + "',N'" + DateTime.Now.ToString() + "',N'" + StringValidation.checkStringOrigFormat(image) + "',N'" + StringValidation.checkStringOrigFormat(pubtime) + "',N'" + StringValidation.checkStringOrigFormat(publisher) + "'  , '" + sNewsType + "','" + sCategoryName + "')";
    //        int intRowAffect = fnExecuteNonQuery(sqlquery, true);
    //    }
    //    catch (Exception Ex)
    //    {
    //        throw Ex;
    //    }

    //    //SUBSTRING(REPLACE(image, 'http://','') , 1, CHARINDEX('/',REPLACE(image, 'http://','')) - 1 )
    //}

    public void insertnewsports(string title, string link, string description, string image, string pubtime, string sPublisherValue, string sNewsType, string sCategoryName)
    {
        try
        {
            string sqlquery = "insert into table_sportsandnews (title,link,description,displayingtime,image,pubdate,publisher,NEWSTYPE,CATEGORY) values(N'" + StringValidation.checkStringOrigFormat(title) + "',N'" + StringValidation.checkStringOrigFormat(link) + "',N'" + StringValidation.checkStringOrigFormat(description) + "',N'" + DateTime.Now.ToString() + "',N'" + StringValidation.checkStringOrigFormat(image) + "',N'" + StringValidation.checkStringOrigFormat(pubtime) + "' ,N'" + StringValidation.checkStringOrigFormat(sPublisherValue) + "','" + sNewsType + "','" + sCategoryName + "')";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertrssmovies(string title, string link, string description, string image, string pubtime, string publisher)
    {
        try
        {

            string SQLQuery = "insert into tbl_rssmovies  (title,link,description,displayingtime,image,pubdate,publisher) values (N'" + StringValidation.checkStringOrigFormat(title) + "',N'" + StringValidation.checkStringOrigFormat(link) + "',N'" + StringValidation.checkStringOrigFormat(description) + "',N'" + DateTime.Now.ToString() + "',N'" + StringValidation.checkStringOrigFormat(image) + "',N'" + StringValidation.checkStringOrigFormat(pubtime) + "',N'" + StringValidation.checkStringOrigFormat(publisher) + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void deleterssmsgmovies()
    {
        try
        {
            string sqlquery = "Delete from tbl_rssmovies";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void deleterOldDataOfsportsnews()
    {
        try
        {
            string sqlquery = "delete from table_sportsandnews where pubdate < DATEADD(DAY, -2, GETDATE()) and category != 'beauty'";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void deleterssmsgsportsnews()
    {
        try
        {
            string sqlquery = "Delete from  table_sportsandnews";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    //written by vasu for Updating the data if News link already exists 

    public void updateSportsNewsExistingLinks(string sTitle, string sLink, string sDescription, string sStatus, string sDisplayingTime, string sImage, string sPubdate, string spublisher, string sNEWSTYPE, string sCATEGORY)
    {
        try
        {

            string sqlquery = "Update TABLE_SPORTSANDNEWS Set title = '" + sTitle + "', link = " + sLink + ", description= " + sDescription + ", ";
            sqlquery = sqlquery + "  image = '" + sImage + "' , pubdate = '" + sPubdate + "', ";   //status = " + sStatus + ", displayingtime = '" + sDisplayingTime + "',
            sqlquery = sqlquery + " publisher = '" + spublisher + "', NEWSTYPE = '" + sNEWSTYPE + "' , CATEGORY = '" + sCATEGORY + "'";
            sqlquery = sqlquery + "  WHERE link = " + sLink;

            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    // writing by uday for activating ad in sms products

    public int inActivatingSmsProduct(int snoAdVies)
    {
        try
        {
            string sqlquery = "update  tbl_ads_smsproducts set visibility_status = '0' where sno = '" + snoAdVies + "'";
            int rows = fnExecuteNonQuery(sqlquery, true);
            return rows;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public int inActivatingCoupon(int snoAdVies)
    {
        try
        {
            string sqlquery = "update  tbl_coupons set IS_ACTIVE = '0' where SNo = '" + snoAdVies + "'";
            int rows = fnExecuteNonQuery(sqlquery, true);
            return rows;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }



    public int activatingSmsProduct(int snoAdVies)
    {
        try
        {
            string sqlquery = "update  tbl_ads_smsproducts set visibility_status = '1' where sno = '" +snoAdVies +"' and pattern ='4'";
            int rows = fnExecuteNonQuery(sqlquery, true);
            return rows;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public int rejectingSmsProduct(int snoAdVies)
    {
        try
        {
            string sqlquery = "update  tbl_ads_smsproducts set pattern='6', visibility_status = 0,MODIFIED_DT = GETDATE() where sno = '" + snoAdVies + "'";
            int rows = fnExecuteNonQuery(sqlquery, true);
            return rows;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public int updateSmsAdDetails(int snoAdVies, string actualPrice, string offer, string offerPrice)
    {
        try
        {
            string sqlquery = "update  tbl_ads_smsproducts set actual_price = '" + actualPrice + "', Offer = '" + offer + "', Offer_price ='" + offerPrice + "',MODIFIED_DT = GETDATE() where sno = '" + snoAdVies + "'";
            int rows = fnExecuteNonQuery(sqlquery, true);
            return rows;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public int updateCoupon(int snoAdVies, string actualPrice, string finalPrice, string discount)
    {
        try
        {
            string sqlquery = "update  tbl_coupons set  Actual_Price = '" + actualPrice + "',Final_Price = '" + finalPrice + "', Discount ='" + discount + "' where sno = '" + snoAdVies + "'";
            int rows = fnExecuteNonQuery(sqlquery, true);
            return rows;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    


    public int updateSportsAndNews(int currentSno)
    {
        try
        {
            string sqlquery = "update  table_sportsandnews set IS_ACTIVE = '0' where sno = '" + currentSno + "'";
            int rows = fnExecuteNonQuery(sqlquery, true);
            return rows;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }






    public DataTable GetNewsfromLink(string sLink)
    {
        try
        {
            string SQLquery = "select * from table_sportsandnews where link = '" + sLink + "'";
            return GetDataTable(SQLquery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    public DataTable display()
    {
        try
        {
            string SQLQuery = "select * from table_sportsandnews";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    /////// get Ads from db---narendra////////
    public DataTable getInnerPageAds(string sCategorys)
    {
        try
        {
            string sqlquery = "SELECT TOP 4 DFL.sno, DFL.CTR AD_LIKES_CTR , ISNULL( CONVERT(VARCHAR(100), DFL.LIKED_MAX_DT , 106) , '')LIKED_MAX_DT_106 ,";
            sqlquery += "S.IMAGE, S.SNO,S.WEBSITE, S.DESCRIPTION, S.TITLE, s.category  , s.Offer_price  FROM TBL_ADS_SMSPRODUCTS S ";
            sqlquery += "INNER  JOIN (select s.sno, COUNT(l.AD_SRL_NO) ctr, MAX(LIKED_DT) LIKED_MAX_DT from tbl_ads_smsproducts s ";
            sqlquery += "left outer join TBL_ADS_USER_LIKES l on s.sno = l.AD_SRL_NO ";
            sqlquery += "where category in (select distinct category from tbl_ads_smsproducts where sno in(select AD_SRL_NO from TBL_ADS_USER_LIKES) and CHARINDEX(',' + CATEGORY + ',',',' + '" + sCategorys + "' + ',') > 0) group by s.sno) AS DFL ON S.SNO = DFL.sno ";
            sqlquery += "WHERE S.VISIBILITY_STATUS = 1 and CHARINDEX(',' + S.CATEGORY + ',',',' + '" + sCategorys + "' + ',') > 0 order by newid()";
            //string sqlquery = "SELECT TOP 4 SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE, CATEGORY,STATE, PATTERN, SENT_CRITERIA, PROCESSED_IMAGE_NAME FROM TBL_ADS_SMSPRODUCTS WHERE CHARINDEX(',' + CATEGORY + ',',',' + '" + sCategorys + "' + ',') > 0  AND VISIBILITY_STATUS='TRUE'  order by newid()";
            //string sqlquery = "select * from " + str + "";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetAdsbyCategoryId(int RequiredAds, string sCategoryId)
    {
        try
        {
            string sQry = "SELECT TOP " + RequiredAds + " SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE,";
            sQry += " CATEGORY,STATE, PATTERN, SENT_CRITERIA, PROCESSED_IMAGE_NAME FROM TBL_ADS_SMSPRODUCTS";
            sQry += " WHERE CATEGORY IN (SELECT L2_CATEGORY_ID FROM TBL_INTEREST_LEVEL_2 WHERE L1_CATEGORY_SNO = " + sCategoryId + ") ";
            sQry += " AND VISIBILITY_STATUS = 1 order by newid()";
            return GetDataTable(sQry, true);
        }
        catch (Exception Ex)
        {

            throw Ex;
        }
    }
    //getads on Basis of Merchant

    // Retreiving checked items
    public DataTable getCheckedCategories(string sUid)
    {
        //string sqlquery = "SELECT L1.SNO categoyid,L1.L1_CATEGORY_NAME FROM TBL_INTEREST_LEVEL_1 L1 LEFT JOIN TBL_EDITPROFILE E ON CHARINDEX(',' + CAST(L1.SNO AS VARCHAR(10))";
        //sqlquery += "+ ',' , ',' + E.CHECKEDITEM + ',') > 0 where e.userid='" + sUid + "'";
        string sqlquery = "EXEC DBO.USP_SHOW_ADS_CATEGORIES_BY_USER_INTEREST '" + sUid + "'";

        return GetDataTable(sqlquery, true);
    }
    // End of Retreiving checked items
    public DataTable GetAdsByCount(int count)
    {
        try
        {
            string sqlquery = " select top " + count + " * from tbl_ads_smsproducts where VISIBILITY_STATUS=1 order by newid()  ";
            //string sqlquery = "select * from " + str + "";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetLikedAdsByCount(int iCount)
    {
        try
        {
            /*
            string sQry = "SELECT TOP "+ iCount  +" SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE, CATEGORY ";
            sQry = String.Concat(sQry, " , PROCESSED_IMAGE_NAME, MERCHANT_PRODUCT_ID, MERCHANT_IMAGE_URL ");
            sQry = String.Concat(sQry, " , (SELECT TOP 1 USER_ID FROM TBL_ADS_USER_LIKES L WHERE A.SNO = L.AD_SRL_NO ORDER BY NEWID()) USERID ");
            sQry = String.Concat(sQry, " FROM TBL_ADS_SMSPRODUCTS A WHERE VISIBILITY_STATUS = 1 ");
            sQry = String.Concat(sQry, " AND SNO IN (SELECT AD_SRL_NO FROM  TBL_ADS_USER_LIKES) ");
            sQry = String.Concat(sQry, " ORDER BY NEWID()");

            */

            /*
            string sQry = " SELECT TOP " + iCount + " DFL.PRIORITY, DFL.SNO, DFL.MID, DFL.TITLE, DFL.WEBSITE, DFL.DESCRIPTION, DFL.IMAGE, DFL.URLLINK, DFL.ACTUAL_PRICE, DFL.OFFER, DFL.OFFER_PRICE, DFL.CATEGORY  , DFL.PROCESSED_IMAGE_NAME, DFL.MERCHANT_PRODUCT_ID, DFL.MERCHANT_IMAGE_URL  , (SELECT TOP 1 USER_ID FROM TBL_ADS_USER_LIKES L WHERE DFL.SNO = L.AD_SRL_NO ORDER BY NEWID()) USERID  ";
            sQry = String.Concat(sQry, " FROM (SELECT DISTINCT CASE WHEN DATEDIFF(DAY, L.LIKED_DT, GETDATE())  < 1 THEN 0 ELSE 1 END PRIORITY, SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE, CATEGORY  , PROCESSED_IMAGE_NAME, MERCHANT_PRODUCT_ID, MERCHANT_IMAGE_URL  ");
            sQry = String.Concat(sQry, " FROM TBL_ADS_SMSPRODUCTS A INNER JOIN TBL_ADS_USER_LIKES L ON A.SNO = L.AD_SRL_NO  ");
            sQry = String.Concat(sQry, " WHERE VISIBILITY_STATUS = 1  AND L.USER_ID != '8206341977133737' ) AS DFL ");
            sQry = String.Concat(sQry, " ORDER BY DFL.PRIORITY, NEWID() ");
            */

            string sQry = " SELECT TOP 1 DFL.PRIORITY, DFL.SNO, DFL.MID, DFL.TITLE, DFL.WEBSITE, DFL.DESCRIPTION, DFL.IMAGE, DFL.URLLINK, DFL.ACTUAL_PRICE, DFL.OFFER, DFL.OFFER_PRICE, DFL.CATEGORY  , DFL.PROCESSED_IMAGE_NAME, DFL.MERCHANT_PRODUCT_ID, DFL.MERCHANT_IMAGE_URL  ";
	        sQry = String.Concat(sQry, " , (SELECT TOP 1 USER_ID FROM TBL_ADS_USER_LIKES L WHERE DFL.SNO = L.AD_SRL_NO ORDER BY NEWID()) USERID   ");
            sQry = String.Concat(sQry, " FROM (SELECT TOP 1 0 PRIORITY, SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE, CATEGORY  , PROCESSED_IMAGE_NAME, MERCHANT_PRODUCT_ID, MERCHANT_IMAGE_URL   ");
		    sQry = String.Concat(sQry, " FROM TBL_ADS_SMSPRODUCTS A ");
		    sQry = String.Concat(sQry, " INNER JOIN TBL_ADS_USER_LIKES L ON A.SNO = L.AD_SRL_NO   WHERE VISIBILITY_STATUS = 1  AND L.USER_ID != '8206341977133737' ORDER BY L.LIKED_DT DESC ) AS DFL  ");

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }



    public DataTable getpro2()
    {
        try
        {
            string sqlquery = " select top 3 * from tbl_ads_smsproducts order by newid() ";
            //string sqlquery = "select * from " + str + "";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getproByUserCategory(string sUserID)
    {
        try
        {

            string sQry = "EXEC DBO.USP_SHOW_ADS_BY_USERID_INTEREST '" + sUserID + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getAdsOnUserInterestByUserID(string sUserID)
    {
        try
        {
            string sQry = "SELECT S.SNO, S.MID, S.TITLE, S.WEBSITE, S.DESCRIPTION, S.IMAGE, S.URLLINK,S.ACTUAL_PRICE,S.OFFER, S.OFFER_PRICE, S.STATE,";
            sQry += " S.CATEGORY, S.PATTERN,S.MERCHANT_IMAGE_URL FROM TBL_ADS_SMSPRODUCTS S INNER JOIN TBL_INTEREST_LEVEL_2 L ON S.CATEGORY = L.L2_CATEGORY_ID ";
            sQry += "INNER JOIN TBL_EDITPROFILE E ON CHARINDEX(',' + CAST(L.L1_CATEGORY_SNO AS VARCHAR(10)) + ',' , ',' + E.CHECKEDITEM + ',') > 0 ";
            sQry += " WHERE USERID = '" + sUserID + "' AND VISIBILITY_STATUS='TRUE' ";//order by newid()";

            return GetDataTable(sQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetAdsWithoutUserID()
    {
        try
        {
            string SQry = "SELECT top 5 S.SNO, S.MID, S.TITLE, S.WEBSITE, S.DESCRIPTION, S.IMAGE, S.URLLINK,S.ACTUAL_PRICE,S.OFFER, S.OFFER_PRICE, S.STATE,";
            SQry += "S.CATEGORY, S.PATTERN,S.MERCHANT_IMAGE_URL FROM TBL_ADS_SMSPRODUCTS S ";
            SQry += " INNER JOIN TBL_INTEREST_LEVEL_2 L ON S.CATEGORY = L.L2_CATEGORY_ID  ";
            SQry += " WHERE VISIBILITY_STATUS='TRUE' order by newid()";
            return GetDataTable("", true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    /********************Insert Ads*********************/

    public DataTable mrchntdetails()
    {
        try
        {
            string sqlquery = "select * from tbl_mrchnt";
            //string sqlquery = "select * from " + str + "";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    //*************** view adds by uday***********//
    public DataTable mrchntViewAddetailsStarting()
    {

        try
        {

            string sqlquery = "select top 1 title,sno, actual_price,image, Offer,Offer_price,urllink FROM tbl_ads_smsproducts WHERE pattern = '4' and  VISIBILITY_STATUS = '0' order by sno";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {

            throw Ex;

        }

    }

    public DataTable mrchntViewMultipleAds()
    {

        try
        {

            string sqlquery = "select  title,sno, actual_price, Offer,Offer_price,urllink FROM tbl_ads_smsproducts WHERE  VISIBILITY_STATUS = '1' order by title";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {

            throw Ex;

        }

    }
    // below  datatalble added by uday


    public DataTable viewMultipleCoupons()
    {

        try
        {

            string sqlquery = "select  * FROM TBL_COUPONS WHERE  IS_ACTIVE = '1' order by Product";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {

            throw Ex;

        }

    }

    




    public DataTable mrchntViewAddetailsSearch(string searchWord)
    {

        try
        {
            string sqlquery = "select top 1 title,sno, actual_price,image, Offer,Offer_price,urllink FROM tbl_ads_smsproducts WHERE  title Like '%" + searchWord + "%' order by NEWID() ";
            
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {

            throw Ex;

        }

    }



    
    ///////////// added by Uday and Bushan////////// 

    public DataTable NewsSearch(string searchNews)
    {

        try
        {
            string sqlquery = "select top 1 * FROM table_sportsandnews WHERE IS_ACTIVE = '1' and   title Like '%" + searchNews + "%' order by NEWID() ";

            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {

            throw Ex;

        }

    }


    public DataTable mrchntViewAddetailsUpdate(int editSno)
    {

        try
        {

            string sqlquery = "select  title,sno, actual_price,image, Offer,Offer_price,urllink FROM tbl_ads_smsproducts WHERE  sno = '" + editSno + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {

            throw Ex;

        }

    }
    
    
    public DataTable mrchntViewAddetails(int currentCase, Int32 currentSno)

    {

      
        if (currentCase == 1)
        {

            try
            {

                string sqlquery = "select top 1 title,sno, actual_price,image, Offer,Offer_price,urllink FROM tbl_ads_smsproducts WHERE pattern = '4' and  VISIBILITY_STATUS = '0' order by sno";
                return GetDataTable(sqlquery, true);
            
            }
            catch (Exception Ex)
            {

                throw Ex;
             
            }

        }
        else if (currentCase == 2)
        {
            try
            {

                string sqlquery = "select top 1 title,sno, actual_price,image, Offer,Offer_price,urllink FROM tbl_ads_smsproducts WHERE pattern = '4' and  VISIBILITY_STATUS = '0' and sno <'" + currentSno + "' order by sno desc";
                return GetDataTable(sqlquery, true);

            }
            catch (Exception Ex)
            {

                throw Ex;

            }
        }
        else if (currentCase == 3)
        {
            try
            {

                string sqlquery = "select top 1 title,sno, actual_price,image, Offer,Offer_price,urllink FROM tbl_ads_smsproducts WHERE pattern = '4' and  VISIBILITY_STATUS = '0' and sno >'" + currentSno + "' order by sno";
                return GetDataTable(sqlquery, true);

            }
            catch (Exception Ex)
            {

                throw Ex;

            }
        }


        else if (currentCase == 4)
        {
            try
            {

                string sqlquery = "select  title,sno, actual_price,image, Offer,Offer_price,urllink FROM tbl_ads_smsproducts WHERE pattern = '4' and  VISIBILITY_STATUS = '0' and sno ='" + currentSno + "' order by sno";
                return GetDataTable(sqlquery, true);

            }
            catch (Exception Ex)
            {

                throw Ex;

            }
        }

        return null;
    }






    //*************** view adds***********//


    public DataTable getctg()
    {
        try
        {
            string sqlquery = " select * from tbl_ctg";
            //string sqlquery = "select * from " + str + "";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getmid(string str)
    {
        try
        {
            string sqlquery = "select MID from tbl_mrchnt where Mname='" + str + "'";
            //string sqlquery = "select * from " + str + "";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertproducts(string mid, string category, int state, int pattern, string title, string website, string description, string image, string urllink, string actprc, string offer, string ofprc, string sImgUrl)
    {
        try
        {

            string sqlquery = "INSERT into tbl_ads_smsproducts (Mid,category,state,pattern,title,website,description,image,urllink,actual_price,Offer,Offer_price,merchant_image_url) VALUES ('" + mid + "','" + category + "','" + state + "','" + pattern + "','" + title + "','" + website + "','" + description + "','" + image + "','" + urllink + "','" + actprc + "','" + offer + "','" + ofprc + "','" + sImgUrl + "')";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    /*     modified by Ganga on 2-Aug-14. Purpose: Updating the ADS_SMSproducts data*/
    public void updatetproducts(int addno, string mid, int category, int state, int pattern, string title, string website, string description, string image, string urllink, string actprc, string offer, string ofprc)
    {
        try
        {

            string sqlquery = "Update tbl_ads_smsproducts Set Mid = '" + mid + "', Category = " + category + ", State= " + state + ", ";
            sqlquery = sqlquery + " pattern = " + pattern + ", title = '" + title + "', website = '" + website + "' , description = '" + description + "', ";
            sqlquery = sqlquery + " image = '" + image + "', urllink = '" + urllink + "' , actual_price = '" + actprc + "', Offer = '" + offer + "' , Offer_price = '" + ofprc + "' ";
            sqlquery = sqlquery + " where sno = " + addno;
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getpro(string url)
    {
        try
        {
            string sqlquery = " select * from tbl_ads_smsproducts where urllink='" + url + "' ";
            //string sqlquery = "select * from " + str + "";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    /******END*********/

    public DataTable getproWithRank()
    {
        // Function will display the list of all smsproducts data along with Add sequence number(rank). Used for displaying another ad after closing one ad
        try
        {
            string sqlquery = " SELECT RANK() OVER (PARTITION BY WEBSITE ORDER BY SNO ) AD_SRL_NO, SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE FROM TBL_ADS_SMSPRODUCTS ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getMerchantsByCategory(string sCategory = "ALL")
    {
        try
        {
            string sQry = "SELECT  DISTINCT M.MID, M.MNAME FROM TBL_ADS_SMSPRODUCTS S INNER JOIN tbl_mrchnt M ON S.Mid = M.MID ";
            if (sCategory != "ALL") { sQry = sQry + "WHERE S.category = '" + sCategory + "'"; }
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetAds(int L1_Category, string L2_Category, string Mid)
    {
        try
        {
            string sQry = " SELECT  SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE , MERCHANT_PRODUCT_ID, MERCHANT_IMAGE_URL, VISIBILITY_STATUS  ";
            sQry = sQry + " FROM TBL_ADS_SMSPRODUCTS WHERE 1=1 ";

            if (L1_Category != 0) { sQry = sQry + " AND CATEGORY IN (SELECT L2_CATEGORY_ID FROM TBL_INTEREST_LEVEL_2 WHERE L1_CATEGORY_SNO = " + L1_Category.ToString() + ") "; }
            if (L2_Category != "0") { sQry = sQry + " AND CATEGORY = '" + L2_Category + "'"; }
            if (Mid != "0") { sQry = sQry + " AND Mid = '" + Mid + "'"; }

            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    //** Added by Naidu To Get Email Campign Archived Data

    public DataTable getCampaignArchiveData(string date)
    {
        try
        {
            //string sQry = " select USERID,EMAILID, AD_SNO,AD_WEBSITE, AD_URL_LINK from TBL_EMAIL_CAMPAIGN_STAGING_DATA_ARCHIVE where datediff(day, PREPARED_DT, '" + date + "') = 0";
            string sQry = " select e.USERID,e.EMAILID, e.AD_SNO,e.AD_WEBSITE, e.AD_URL_LINK,a.AD_SNO,a.Host,a.Clicked_Date,e.PREPARED_DT from TBL_EMAIL_CAMPAIGN_STAGING_DATA_ARCHIVE e LEFT OUTER join TBL_EMAILCAMPAIGN_USER_AUDIT a on e.USERID=a.USERID  where datediff(day, e.PREPARED_DT, '" + date + "') = 0";

            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable getCampaignArchiveData_category(string category, string start_date, string end_date)
    {
        try
        {
            string sQry = "select SNO,USERID,EMAILID,AD_SNO,MID,AD_TITLE,AD_URL_LINK,AD_CATEGORY,PREPARED_DT from TBL_EMAIL_CAMPAIGN_STAGING_DATA_ARCHIVE where AD_CATEGORY in (SELECT L2_CATEGORY_ID FROM dbo.TBL_INTEREST_LEVEL_2 where L1_CATEGORY_SNO = " + category + ") and (PREPARED_DT BETWEEN '" + start_date + "' AND '" + end_date + "')";

            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable getCampaignArchiveData_subcategory(string category, string start_date, string end_date)
    {
        try
        {

            string sQry = "select SNO,USERID,EMAILID,AD_SNO,MID,AD_TITLE,AD_URL_LINK,AD_CATEGORY,PREPARED_DT from TBL_EMAIL_CAMPAIGN_STAGING_DATA_ARCHIVE where AD_CATEGORY = '" + category + "'  and (PREPARED_DT BETWEEN '" + start_date + "' AND '" + end_date + "')";

            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    // End
    /************** Added by naidu to update isSent field When Email sent     */
    public void updateIsSent(string sUid)
    {
        try
        {
            string strDateTime = DateTime.Now.ToString();
            string sqlquery = "UPDATE dbo.TBL_EMAIL_CAMPAIGN_STAGING_DATA SET IS_MAIL_SENT = 1,PREPARED_DT = '" + strDateTime + "' WHERE USERID='" + sUid + "'";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }

    }

    // To get all merchants

    public DataTable getAllMerchants()
    {
        try
        {

            string sQry = "select Distinct MID,website from TBL_ADS_SMSPRODUCTS";

            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    // End

    public DataTable getCampaignArchiveData_Merchant(string merchant, string start_date, string end_date)
    {
        try
        {
            string sQry = "select SNO,USERID,EMAILID,AD_SNO,MID,AD_TITLE,AD_URL_LINK,AD_CATEGORY,PREPARED_DT from TBL_EMAIL_CAMPAIGN_STAGING_DATA_ARCHIVE where MID = '" + merchant + "'  and (PREPARED_DT BETWEEN '" + start_date + "' AND '" + end_date + "')";
            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable getAddetails(string Adno, string start_date, string end_date)
    {

        try
        {
            string sQry = "select SNO,USERID,EMAILID,AD_SNO,MID,AD_TITLE,AD_URL_LINK,AD_CATEGORY,PREPARED_DT from TBL_EMAIL_CAMPAIGN_STAGING_DATA_ARCHIVE where AD_SNO = '" + Adno + "'  and (PREPARED_DT BETWEEN '" + start_date + "' AND '" + end_date + "')";
            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable getUserdetails(string UserId, string start_date, string end_date)
    {
        try
        {
            string sQry = "select SNO,USERID,EMAILID,AD_SNO,MID,AD_TITLE,AD_URL_LINK,AD_CATEGORY,PREPARED_DT from TBL_EMAIL_CAMPAIGN_STAGING_DATA_ARCHIVE where USERID = '" + UserId + "'  and (PREPARED_DT BETWEEN '" + start_date + "' AND '" + end_date + "')";
            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public DataTable GetGames(int count)
    {
        try
        {
            string SQLQuery = "select top " + count + " SNO,GAME_NAME,GAME_PANEL,IMAGE_NAME,Game_description from tbl_games_master order by newid()";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetGameByID(int GameID)
    {
        try
        {
            string SQLQuery = "select SNO,GAME_NAME,GAME_PANEL,IMAGE_NAME,Game_description from tbl_games_master where SNO='" + GameID + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Get_Game_Clicks_By_UserID(string sUID, string sGameID)
    {
        try
        {
            string SQLQuery = "select * from TBL_GAMES_USER_LIKES where USERID='" + sUID + "' and GAME_ID='" + sGameID + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void Save_Game_Clicks(string sUID, string sGameID)
    {
        try
        {
            string SQry = "insert into TBL_GAMES_USER_LIKES(USERID,GAME_ID) values('" + sUID + "','" + sGameID + "')";
            int RowAffect = fnExecuteNonQuery(SQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable selectnews(string USERID)
    {
        try
        {
            //string sqlquery = "select top 10 sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename from table_sportsandnews  where link not like '%youtube%' and category != 'beauty' order by pubdate desc,NEWID()";
            // string sqlquery = "SELECT TOP 10 SNO, TITLE, LINK, DESCRIPTION, STATUS, DISPLAYINGTIME, IMAGE, PUBDATE, PUBLISHER, REPLACE(REPLACE(IMAGE, 'HTTP://',''), '/','') IMAGENAME FROM TABLE_SPORTSANDNEWS  WHERE LINK NOT LIKE '%YOUTUBE%' AND CATEGORY != 'BEAUTY' AND IS_ACTIVE = 1 ORDER BY CONVERT(VARCHAR(30), CAST(PUBDATE AS DATETIME) , 102)DESC, NEWID()";
            string sqlquery = "SELECT TOP 10 SNO, TITLE, LINK, DESCRIPTION, STATUS, DISPLAYINGTIME, ";
            sqlquery = sqlquery + "IMAGE, PUBDATE, PUBLISHER, REPLACE(REPLACE(IMAGE, 'HTTP://',''), '/','') IMAGENAME , isnull(z.ZoomStatus, 0) ZoomStatus";
            sqlquery = sqlquery + " FROM TABLE_SPORTSANDNEWS  N	left outer join TBL_ZOOM_COLLECTIONS z on z.ColumnID = n.sno ";
            sqlquery = sqlquery + " and z.UserID = '" + USERID + "' and z.TableName = 'TABLE_SPORTSANDNEWS'";
            sqlquery = sqlquery + " WHERE LINK NOT LIKE '%YOUTUBE%' AND CATEGORY != 'BEAUTY' AND IS_ACTIVE = 1 ";
            sqlquery = sqlquery + " ORDER BY CONVERT(VARCHAR(30), CAST(PUBDATE AS DATETIME) , 102)DESC, NEWID()";
            return GetDataTable(sqlquery, true);
        }

        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public DataTable selectnewsports(string category, string USERID)
    {
        try
        {
            //string sqlquery = "select top 10 sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(  replace(image , 'https://' , '') , 'http://',''), '/','') imagename,category from table_sportsandnews  where link not like '%youtube%' and category='" + category + "' and  is_active = 1 order by newid() desc";

            string sqlquery = " SELECT TOP 10 SNO, TITLE, LINK, DESCRIPTION, STATUS, DISPLAYINGTIME, IMAGE, PUBDATE,  ";
            sqlquery = sqlquery + "PUBLISHER, REPLACE(REPLACE(  replace(image , 'https://' , '') , 'http://',''), '/','')  ";
            sqlquery = sqlquery + "IMAGENAME ,CATEGORY, isnull(z.ZoomStatus, 0) ZoomStatus  FROM TABLE_SPORTSANDNEWS N	 ";
            sqlquery = sqlquery + "left outer join TBL_ZOOM_COLLECTIONS z on z.ColumnID = n.sno  and z.UserID = '" + USERID + "'   ";
            sqlquery = sqlquery + "and z.TableName = 'TABLE_SPORTSANDNEWS'  WHERE LINK  NOT LIKE '%YOUTUBE%' AND  ";
            sqlquery = sqlquery + "CATEGORY = 'BEAUTY' AND IS_ACTIVE = 1  ORDER BY CONVERT(VARCHAR(30), CAST(PUBDATE AS DATETIME) , 102)DESC, NEWID() ";

            return GetDataTable(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable GetDailyHoroscopeDetails(DateTime dtHoroDate)
    {
        try
        {
            string sQry = "SELECT ZODIAC_SIGN , PREDICTION , LINK FROM TBL_DAILY_HOROSCOPE WHERE HORO_DATE = '" + dtHoroDate.ToString("yyyy-MM-dd") + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable GetDailyHoroscopeDetails(DateTime dtHoroDate, string sUserID)
    {
        try
        {
            //string sQry = "SELECT ZODIAC_SIGN , PREDICTION , LINK FROM TBL_DAILY_HOROSCOPE WHERE HORO_DATE = '" + dtHoroDate.ToString("yyyy-MM-dd") + "'";
            string sQry = " SELECT ZODIAC_SIGN , PREDICTION , LINK , isnull(z.ZoomStatus, 0) ZoomStatus, HOROSCOPE_ID ";
            sQry = sQry + "FROM TBL_DAILY_HOROSCOPE N	 left outer join TBL_ZOOM_COLLECTIONS z on z.ColumnID = N.HOROSCOPE_ID  ";
            sQry = sQry + "and z.UserID = '" + sUserID + "'   and z.TableName = 'TBL_DAILY_HOROSCOPE' WHERE HORO_DATE = '" + dtHoroDate.ToString("yyyy-MM-dd") + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable GetAllDailyHoroscopeDetailsByUserID(string sUserID)
    {
        try
        {
            string sQry = "SELECT PRIORITY, ORDER_PRIORITY, HORO_DATE, ZODIAC_SIGN, PREDICTION, LINK ";
            sQry = sQry + " FROM ( ";
            sQry = sQry + " SELECT 1 PRIORITY, 0 ORDER_PRIORITY, HORO_DATE, ZODIAC_SIGN, PREDICTION, LINK FROM TBL_DAILY_HOROSCOPE WHERE CONVERT(VARCHAR(100), HORO_DATE, 112) = CONVERT(VARCHAR(100), GETDATE(), 112) ";
            sQry = sQry + " AND ZODIAC_SIGN = (SELECT DEFAULT_ZODIAC_SIGN FROM TBL_USER_ADDITIONAL_INFO WHERE USERID = '" + sUserID + "') ";
            sQry = sQry + " UNION ";
            sQry = sQry + " SELECT 2 PRIORITY, CASE WHEN ZODIAC_SIGN = 'Aries'THEN 1 WHEN ZODIAC_SIGN = 'Taurus' THEN 2 WHEN ZODIAC_SIGN = 'Gemini' THEN 3 WHEN ZODIAC_SIGN = 'Cancer' THEN 4 WHEN ZODIAC_SIGN = 'Leo' THEN 5 ";
            sQry = sQry + " WHEN ZODIAC_SIGN = 'Virgo' THEN  6 WHEN ZODIAC_SIGN = 'Libra' THEN 7 WHEN ZODIAC_SIGN = 'Scorpio' THEN 8 WHEN ZODIAC_SIGN = 'Sagittarius' THEN 9 WHEN ZODIAC_SIGN = 'Capricorn' THEN 10 WHEN ZODIAC_SIGN = 'Aquarius' THEN 11 WHEN ZODIAC_SIGN = 'Pisces' THEN 12 END, HORO_DATE, ZODIAC_SIGN, PREDICTION, LINK FROM TBL_DAILY_HOROSCOPE WHERE CONVERT(VARCHAR(100), HORO_DATE, 112) = CONVERT(VARCHAR(100), GETDATE(), 112) ";
            sQry = sQry + " AND ZODIAC_SIGN != (SELECT DEFAULT_ZODIAC_SIGN FROM TBL_USER_ADDITIONAL_INFO WHERE USERID = '" + sUserID + "') ";
            sQry = sQry + " ) AS DFL  WHERE DFL.ORDER_PRIORITY IS NOT NULL ";
            sQry = sQry + " ORDER BY DFL.PRIORITY DESC, DFL.ORDER_PRIORITY DESC ";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetLikedAdsByClick()
    {
        try
        {
            /*
            string sQry = "SELECT TOP "+ iCount  +" SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE, CATEGORY ";
            sQry = String.Concat(sQry, " , PROCESSED_IMAGE_NAME, MERCHANT_PRODUCT_ID, MERCHANT_IMAGE_URL ");
            sQry = String.Concat(sQry, " , (SELECT TOP 1 USER_ID FROM TBL_ADS_USER_LIKES L WHERE A.SNO = L.AD_SRL_NO ORDER BY NEWID()) USERID ");
            sQry = String.Concat(sQry, " FROM TBL_ADS_SMSPRODUCTS A WHERE VISIBILITY_STATUS = 1 ");
            sQry = String.Concat(sQry, " AND SNO IN (SELECT AD_SRL_NO FROM  TBL_ADS_USER_LIKES) ");
            sQry = String.Concat(sQry, " ORDER BY NEWID()");

            */
            string sQry = " SELECT TOP 1  DFL.PRIORITY, DFL.SNO, DFL.MID, DFL.TITLE, DFL.WEBSITE, DFL.DESCRIPTION, DFL.IMAGE, DFL.URLLINK, DFL.ACTUAL_PRICE, DFL.OFFER, DFL.OFFER_PRICE, DFL.CATEGORY  , DFL.PROCESSED_IMAGE_NAME, DFL.MERCHANT_PRODUCT_ID, DFL.MERCHANT_IMAGE_URL  , (SELECT TOP 1 USER_ID FROM TBL_ADS_USER_LIKES L WHERE DFL.SNO = L.AD_SRL_NO ORDER BY NEWID()) USERID  ";
            sQry = String.Concat(sQry, " FROM (SELECT DISTINCT CASE WHEN DATEDIFF(DAY, L.LIKED_DT, GETDATE())  < 1 THEN 0 ELSE 1 END PRIORITY, SNO, MID, TITLE, WEBSITE, DESCRIPTION, IMAGE, URLLINK, ACTUAL_PRICE, OFFER, OFFER_PRICE, CATEGORY  , PROCESSED_IMAGE_NAME, MERCHANT_PRODUCT_ID, MERCHANT_IMAGE_URL  ");
            sQry = String.Concat(sQry, " FROM TBL_ADS_SMSPRODUCTS A INNER JOIN TBL_ADS_USER_LIKES L ON A.SNO = L.AD_SRL_NO  ");
            sQry = String.Concat(sQry, " WHERE VISIBILITY_STATUS = 1  ) AS DFL ");
            sQry = String.Concat(sQry, " ORDER BY DFL.PRIORITY, NEWID() ");

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataSet GetLikedAdsByClick(string pid, string uid)
    {
        try
        {
            string sQry = " select SNO,MERCHANT_IMAGE_URL,TITLE,DESCRIPTION,WEBSITE,OFFER_PRICE from TBL_ADS_SMSPRODUCTS where sno='" + pid + "';";

            // sQry = String.Concat(sQry, "select USERID,MOBILENO,USERPWD,NAME,EMAILID,IMAGE_NAME,OCCUPATION,JOINDATE from TBL_ACTIVE_USERS where USERID='" + uid + "'");

            return GetDataSet(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getproByUserCategory(string pid, string uid)
    {
        try
        {

            string sQry = "EXEC DBO.USP_SHOW_ADS_BY_USERID_SHRAES '" + uid + "' , '" + pid + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetLikedList(string pid, string uid)
    {
        try
        {
            string sQry = " select USER_ID,LIKED_DT from TBL_ADS_USER_LIKES where AD_SRL_NO='" + pid + "' AND USER_ID !='" + uid + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }



    public DataTable GetLikedUsers(System.Text.StringBuilder strList)
    {
        try
        {
            string sQry = "select USERID,MOBILENO,USERPWD,NAME,EMAILID,IMAGE_NAME,OCCUPATION,JOINDATE from TBL_ACTIVE_USERS where USERID IN (" + strList + ")";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataSet GetNewsPageWise(int pageIndex, int p, string isno, string uid)
    {
        try
        {
            string sQry = "EXEC DBO.USP_Get_PageWiseNews  " + pageIndex + " , " + p + ", " + uid + ", " + isno  + "";

            return GetDataSet(sQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataSet SelectNewsFromUsp(string isno, string userid, string criteria)
    {
        try
        {
            string sQry = "EXEC  dbo.USP_GetNews_PageWise   '" + criteria + "', '" + isno + "' ";

            return GetDataSet(sQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    

    public DataSet selectmorenews(string nid)
    {
        try
        {
            //string sqlquery = "select top 10 sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename from table_sportsandnews  where link not like '%youtube%' and category != 'beauty' order by pubdate desc,NEWID()";
            string sqlquery = "SELECT TOP 10 SNO, TITLE, LINK, DESCRIPTION, STATUS, DISPLAYINGTIME, IMAGE, PUBDATE, PUBLISHER, REPLACE(REPLACE(IMAGE, 'HTTP://',''), '/','') IMAGENAME FROM TABLE_SPORTSANDNEWS  WHERE LINK NOT LIKE '%YOUTUBE%' AND CATEGORY != 'BEAUTY' AND IS_ACTIVE = 1 ANd SNO NOT IN ('" + nid + "') ORDER BY CONVERT(VARCHAR(30), CAST(PUBDATE AS DATETIME) , 102)DESC, NEWID();";
           
            return GetDataSet(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public DataSet selectmorenews(string nid, string eid)
    {
        try
        {
            //string sqlquery = "select top 10 sno, title, link, description, status, displayingtime, image, pubdate, publisher, REPLACE(REPLACE(image, 'http://',''), '/','') imagename from table_sportsandnews  where link not like '%youtube%' and category != 'beauty' order by pubdate desc,NEWID()";
            string sqlquery = "SELECT TOP 10 SNO, TITLE, LINK, DESCRIPTION, STATUS, DISPLAYINGTIME, IMAGE, PUBDATE, PUBLISHER, REPLACE(REPLACE(IMAGE, 'HTTP://',''), '/','') IMAGENAME FROM TABLE_SPORTSANDNEWS  WHERE LINK NOT LIKE '%YOUTUBE%' AND CATEGORY != 'BEAUTY' AND IS_ACTIVE = 1 ANd SNO NOT IN ('" + nid + "') ORDER BY CONVERT(VARCHAR(30), CAST(PUBDATE AS DATETIME) , 102)DESC, NEWID();";
            sqlquery = sqlquery + "select * from tbl_rssmovies where sno not in ('" + eid + "') order by sno desc";
            return GetDataSet(sqlquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    
    //public DataSet selectmoremovies(string eid)
    //{
    //    try
    //    {
    //        string SQLQuery = "select * from tbl_rssmovies where sno not in ('" + eid + "') order by sno desc";

    //        return GetDataSet(SQLQuery, true);
    //    }
    //    catch (Exception Ex)
    //    {
    //        throw Ex;
    //    }
    //}


    //bellow code added by bhushan

    public DataTable viewMultipleOffers()
    {

        try
        {

            string sqlquery = "select  * FROM TBL_OFFERS WHERE DOTD_OR_OFFFER='Offer' and IS_ACTIVE = '1' order by OFFER_DESCRIPTION";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {

            throw Ex;

        }

    }

    public int inActivatingOffer(int inactiveSno)
    {
        try
        {
            string sqlquery = "update  tbl_offers set  IS_ACTIVE = '0' where sno = '" + inactiveSno + "'";
            int rows = fnExecuteNonQuery(sqlquery, true);
            return rows;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public int updateOffer(int sno, object Offertitle)
    {
        //Offertitle
        try
        {
            string sqlquery = "update  tbl_offers set  offer_title = '" + Offertitle + "' where sno = '" + sno + "'";
            int rows = fnExecuteNonQuery(sqlquery, true);
            return rows;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}