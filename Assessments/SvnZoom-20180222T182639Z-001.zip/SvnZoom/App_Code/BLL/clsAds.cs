﻿using System;
using System.Data;

/// <summary>
/// Summary description for clsAds
/// </summary>
public class clsAds : BaseClass
{
    public clsAds()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable getMerchant_Products()
    {
        try
        {
            string sqlQuery = "SELECT SNO,MID,IMAGE,CATEGORY,MERCHANT_PRODUCT_ID,MERCHANT_IMAGE_URL FROM TBL_ADS_SMSPRODUCTS WHERE IS_IMAGE_PROCESSED='1' AND VISIBILITY_STATUS='1'";
            return GetDataTable(sqlQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    public void updateIsImageProcessed(string sMerchant, string sCategory, string sProduct_ID)
    {
        string sqlQuery = "UPDATE TBL_ADS_SMSPRODUCTS SET IS_IMAGE_PROCESSED ='0' WHERE MID = '" + sMerchant + "' AND CATEGORY='" + sCategory + "' AND MERCHANT_PRODUCT_ID ='" + sProduct_ID + "'";
        int rowaffect = fnExecuteNonQuery(sqlQuery, true);
    }


    public DataTable getMerchant_Deals()
    {
        try
        {
            string sqlQuery = "select * from MERCHANT_WISE_DEALS where PROCESSED_YN='False'";
            return GetDataTable(sqlQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void insertTBL_COUPONS(string sMerchantId, string sMerchant, string sTitle, string sProd_Desc, string imagename, string sProduct_Url, string sMrp, string sDiscountPer, string sPrice, string Coupon_cost, string City, string ads_by, string Location, string IMG_LARGE, string EXPIRY_DATE)
    {
        // string sqlQuery = "insert into S_TBL_COUPON(Mid,title,description,image,urllink,actual_price,Offer,Offer_price,category,merchant_product_id) values('" + sMerchant + "','" + sTitle + "','" + sProd_Desc + "','" + imagename + "','" + sProduct_Url + "','" + sMrp + "','" + sDiscountPer + "','" + sPrice + "','" + sCategory + "','" + sProduct_ID + "')";
        string city_id = "", state_id = "";

        sMerchant = sMerchant.Replace(@"'", @"`");
        sTitle = sTitle.Replace(@"'", @"`");
        sProd_Desc = sProd_Desc.Replace(@"'", @"`");
        imagename = imagename.Replace(@"'", @"`");
        sProduct_Url = sProduct_Url.Replace(@"'", @"`");
        Location = Location.Replace(@"'", @"`");
        City = City.Replace(@"'", @"`");
        ads_by = ads_by.Replace(@"'", @"`");

        
        
       switch(City.ToUpper().Trim().Replace("-","")){
            case "PUNE": 
                   city_id = "66208";
                   state_id = "15"; 
                   break;
            case "DELHINCR": 
                city_id = "131988";
                state_id = "29"; 
                break;
            case "HYDERABAD":
                city_id = "3105";
                state_id = "36"; 
                break;

            case "GOA":
                city_id = "134548";
                state_id = "6"; 
                break;
            case "CHANDIGARH":
                city_id = "132446";
                state_id = "21"; 
                break;
            case "BANGALORE":
                city_id = "140201";
                state_id = "12"; 
                break;
            case "MUMBAI":
                city_id = "69577";
                state_id = "15"; 
                break;
            case "GURGAON":
                city_id = "36483";
                state_id = "8"; 
                break;
            case "CHENNAI":
                city_id = "95558";
                state_id = "24"; 
                break;
            case "JAIPUR":
                city_id = "86462";
                state_id = "22"; 
                break;
           default:
               city_id = getcityid(City);
               state_id = getstateid(city_id);
               break;
        }

        
        //string sqlQuery = "insert into S_TBL_COUPON(Merchant,IMAGENAME,Product,URL,Actual_Price,Discount,Final_Price,Coupon_cost,CITY,ads_by,Location,Order_type,city_id) values('" + sMerchant + "','" + imagename + "','" + sTitle + "','" + sProduct_Url + "','" + sMrp + "','" + sDiscountPer + "','" + sPrice + "','" + Coupon_cost + "','" + City + "','" + ads_by + "','" + Location + "',' ', select top 1 city_id from dbo.Cities where city_name like '%" + City + "%'')";
        string sqlQuery = "insert into TBL_COUPONS(Merchant,IMAGENAME,Product,URL,Actual_Price,Discount,Final_Price,Coupon_cost,CITY,ads_by,Location,Order_type,city_id,STATE_ID,IMG_LARGE,EXPIRY_DATE,IS_ACTIVE) values('" + sMerchant + "','" + imagename + "','" + sTitle + "','" + sProduct_Url + "','" + sMrp + "','" + sDiscountPer + "','" + sPrice + "','" + Coupon_cost + "','" + City + "','" + ads_by + "','" + Location + "',' ', '" + city_id + "','" + state_id + "','" + IMG_LARGE + "', '" + EXPIRY_DATE + "','1');";
        sqlQuery = sqlQuery + "UPDATE MERCHANT_WISE_DEALS SET PROCESSED_YN='True' WHERE MERCHANT_ID = '" + sMerchantId + "'";

        //string sqlQuery = "insert into S_TBL_COUPON(Merchant,IMAGENAME,Product,URL,Actual_Price,Discount,Final_Price,Coupon_cost,CITY,ads_by,Location,Order_type,city_id,STATE_ID) values('" + sMerchant + "','" + imagename + "','" + sTitle + "','" + sProduct_Url + "','" + sMrp + "','" + sDiscountPer + "','" + sPrice + "','" + Coupon_cost + "','" + City + "','" + ads_by + "','" + Location + "',' ', '" + city_id + "','"+state_id+"')";
        //(sMerchant, sTitle, sProd_Desc, imagename, sProduct_Url, sMrp, sDiscountPer, sPrice,Coupon_cost, sCity);
        int rowaffect = fnExecuteNonQuery(sqlQuery, true);
    }

    public string getcityid(string City)
    {
        try
        {
            string SQLQuery = "select top 1 city_id from Cities where city_name like '%" + City + "%'";
            return GetSingleValue(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public string getstateid(string city_id)
    {

        try
        {
            string SQLQuery = "select top 1 state_id from Cities where city_id ='" + city_id + "'";
            return GetSingleValue(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertTBL_OFFERSS(string sMerchantId, string sMerchant, string sTitle, string sProd_Desc, string imagename, string sProduct_Url, string sMrp, string sDiscountPer, string sPrice, string Coupon_cost, string City, string ads_by, string Location, string IMG_LARGE, string EXPIRY_DATE)
    {
        // string sqlQuery = "insert into S_TBL_COUPON(Mid,title,description,image,urllink,actual_price,Offer,Offer_price,category,merchant_product_id) values('" + sMerchant + "','" + sTitle + "','" + sProd_Desc + "','" + imagename + "','" + sProduct_Url + "','" + sMrp + "','" + sDiscountPer + "','" + sPrice + "','" + sCategory + "','" + sProduct_ID + "')";

        sMerchant = sMerchant.Replace(@"'", @"`");
        sTitle = sTitle.Replace(@"'", @"`");
        sProd_Desc = sProd_Desc.Replace(@"'", @"`");
        imagename = imagename.Replace(@"'", @"`");
        sProduct_Url = sProduct_Url.Replace(@"'", @"`");
        Location = Location.Replace(@"'", @"`");
        City = City.Replace(@"'", @"`");
        ads_by = ads_by.Replace(@"'", @"`");
        string city_id = "";


        //  city = 131988(pahar gunj)
        //state = 29 (delhi)

        if (City == "delhi-ncr")
        {
            city_id = "131988";
        }
        else
        {
            city_id = getcityid(City);
        }
        string state_id = getstateid(city_id);
        //string sqlQuery = "insert into S_TBL_COUPON(Merchant,IMAGENAME,Product,URL,Actual_Price,Discount,Final_Price,Coupon_cost,CITY,ads_by,Location,Order_type,city_id) values('" + sMerchant + "','" + imagename + "','" + sTitle + "','" + sProduct_Url + "','" + sMrp + "','" + sDiscountPer + "','" + sPrice + "','" + Coupon_cost + "','" + City + "','" + ads_by + "','" + Location + "',' ', select top 1 city_id from dbo.Cities where city_name like '%" + City + "%'')";
        string sqlQuery = "insert into TBL_COUPONS(Merchant,IMAGENAME,Product,URL,Actual_Price,Discount,Final_Price,Coupon_cost,CITY,ads_by,Location,Order_type,city_id,STATE_ID,IMG_LARGE,EXPIRY_DATE,IS_ACTIVE) values('" + sMerchant + "','" + imagename + "','" + sTitle + "','" + sProduct_Url + "','" + sMrp + "','" + sDiscountPer + "','" + sPrice + "','" + Coupon_cost + "','" + City + "','" + ads_by + "','" + Location + "',' ', '" + city_id + "','" + state_id + "','" + IMG_LARGE + "', '" + EXPIRY_DATE + "','1');";
        sqlQuery = sqlQuery + "UPDATE MERCHANT_WISE_DEALS SET PROCESSED_YN='True' WHERE MERCHANT_ID = '" + sMerchantId + "'";

        //string sqlQuery = "insert into S_TBL_COUPON(Merchant,IMAGENAME,Product,URL,Actual_Price,Discount,Final_Price,Coupon_cost,CITY,ads_by,Location,Order_type,city_id,STATE_ID) values('" + sMerchant + "','" + imagename + "','" + sTitle + "','" + sProduct_Url + "','" + sMrp + "','" + sDiscountPer + "','" + sPrice + "','" + Coupon_cost + "','" + City + "','" + ads_by + "','" + Location + "',' ', '" + city_id + "','"+state_id+"')";
        //(sMerchant, sTitle, sProd_Desc, imagename, sProduct_Url, sMrp, sDiscountPer, sPrice,Coupon_cost, sCity);
        int rowaffect = fnExecuteNonQuery(sqlQuery, true);
    }

    public void ExecMerchant_Offers()
    {
        try
        {
            string sqlQuery = "EXEC USP_IMPORT_OFFERS_FROM_API";
            int rowaffect = fnExecuteNonQuery(sqlQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public DataTable getMerchant_Offers()
    {

        try
        {
            //string sqlQuery = "select * from MERCHANT_WISE_OFFERS where PROCESSED_YN='False'";
            // string sqlQuery = "select * from TBL_OFFERS where PROCESSED_YN='False'";
            string sqlQuery = "EXEC USP_IMPORT_OFFERS_FROM_API";
            return GetDataTable(sqlQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void insertTBL_OFFERSS(string sMerchant, string sTitle, string sProd_Desc, string imagename, string sProduct_Url, string sourcepath, string sads_type, string sAvailability)
    {
        sMerchant = sMerchant.Replace(@"'", @"`");
        sTitle = sTitle.Replace(@"'", @"`");
        sProd_Desc = sProd_Desc.Replace(@"'", @"`");
        imagename = imagename.Replace(@"'", @"`");
        sProduct_Url = sProduct_Url.Replace(@"'", @"`");
        sads_type = sads_type.Replace(@"'", @"`");
        //        MERCHANT
        //DOTD_OR_OFFFER
        //OFFER_TITLE
        //OFFER_DESCRIPTION
        //URL
        //IMG_URL
        //AVAILABILITY
        string sqlQuery = "insert into TBL_OFFERS(MERCHANT,IMG_URL,OFFER_TITLE,URL,OFFER_DESCRIPTION,DOTD_OR_OFFFER,AVAILABILITY) values('" + sMerchant + "','" + imagename + "','" + sTitle + "','" + sProduct_Url + "','" + sProd_Desc + "','" + sads_type + "','" + sAvailability + "');";
        sqlQuery = sqlQuery + "UPDATE MERCHANT_WISE_OFFERS SET PROCESSED_YN='True' WHERE URL = '" + sProduct_Url + "'";
        int rowaffect = fnExecuteNonQuery(sqlQuery, true);
    }

    public void UpdatetblOffers(System.Collections.Generic.List<string> lUrl)
    {
        string sqlQuery = "UPDATE TBL_OFFERS SET PROCESSED_YN= 0 WHERE URL IN " + lUrl ;
        int rowaffect = fnExecuteNonQuery(sqlQuery, true);
    }

    public void UpdatetblOffers(System.Text.StringBuilder sUrl)
    {
        string sqlQuery = "UPDATE TBL_OFFERS SET PROCESSED_YN= 0 WHERE SNO IN (" + sUrl + ")"; ;
        int rowaffect = fnExecuteNonQuery(sqlQuery, true);
    }
}