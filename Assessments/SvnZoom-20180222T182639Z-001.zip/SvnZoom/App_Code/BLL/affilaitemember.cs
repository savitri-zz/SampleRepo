﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for affilaitemember
/// </summary>
public class affilaitemember:BaseClass
{
	public affilaitemember()
	{
		//
		// TODO: Add constructor logic here
		//
	}



    public DataTable Zgetdetailnon(string userid)
    {
        try
        {
            string sqlquery = "Select * from tbl_nonmemreg where userid='" + userid + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Zselectmember(string userid)
    {
        try
        {
            string sqlquery = "Select * from  tbl_registration where userid='" + userid + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable selectmember1(string userid)
    {
        try
        {
            string sqlquery = "Select * from  tbl_freememreg where userid='" + userid + "'";
           // string sqlquery = "USP_Bite2Byte_Selectmember1 '" + userid + "'";

            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }  

    //public void Zupdatstatus(string tablename,string columanname, string userid)
    //{
    //    try
    //    {
    //        string sqlquery = "update " + tablename + " set " + columanname + " ='A' where userid='" + userid + "'";
    //      //  string sqlquery = "USP_Bite2Byte_updatstatus '" + tablename + "', '" + columanname +"','" + userid + "'";
    //        int intRowAffect = fnExecuteNonQuery(sqlquery, true);

    //    }
    //    catch (Exception Ex)
    //    {
    //        throw Ex;
    //    }
    //}

    public void ActivateNewUser(string sUserID, string sCriteria)
    {
        try
        {
            //string sQry = "EXEC USP_ACTIVATE_NEW_USER '" + sUserID + "'";
            //int intRowAffect = fnExecuteNonQuery(sQry, true);

            string[] strArrList = { "@USERID", "@CRITERIA" };
            string[] strArrValues = { sUserID, sCriteria };

            int intRowAffect = fnRunProcedure("USP_ACTIVATE_NEW_USER", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    //  Added By Ganga Purpose: Update user active status='na' if the user invited_through='f'
    public int ChangeUserStatus(string sUserid)
    {   
        string sqlquery = "UPDATE TBL_FREEMEMREG SET ACTIVEUSER='NA' WHERE USERID='" + sUserid + "'";
        int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        return intRowAffect;
    }
    //  Added By Ganga Purpose: Update user active status='a' if the user invited_through='f'
    public int ChangeUserStatus_A(string sUserid)
    {   
        string sqlquery = "UPDATE TBL_FREEMEMREG SET ACTIVEUSER='A' WHERE USERID='" + sUserid + "' AND INVALID_DATA_STATUS = 0";
        int intRowAffect = fnExecuteNonQuery(sqlquery, true);

        this.UpdateCountersForSocialUserActivation(sUserid);

        return intRowAffect;
    }
    
    public void ActivateQuickInvitee(string sUserID, string sCriteria)
    {
        try
        {
            //string sQry = "EXEC USP_ACTIVATE_QUICK_INVITEE '" + sUserID + "' , '"+ sCriteria +"'";
            //int intRowAffect = fnExecuteNonQuery(sQry, true);


            string[] strArrList = { "@USERID", "@CRITERIA"};
            string[] strArrValues = { sUserID, sCriteria };

            int intRowAffect = fnRunProcedure("USP_ACTIVATE_QUICK_INVITEE", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

    public void UpdateCountersForSocialUserActivation(string sUserID)
    {
        try
        {

            string[] strArrList = { "@USERID" };
            string[] strArrValues = { sUserID };

            int intRowAffect = fnRunProcedure("USP_UPDATE_USER_INVITATIONS_DATA_SOCIAL_USER", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    // Added by Sudhindra on 23-July-2014. Purpose : store activation date and time also , at the time of activation.
    public void ZUpdateActivationStatus(string sUserID)
    {
        try
        {
            string sQry = "UPDATE TBL_FREEMEMREG SET ACTIVEUSER = 'A' , ACTIVATION_DATE = GETDATE() WHERE USERID = '"+ sUserID +"'";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

    //------added by sudhindar on 7th july for giving the invitation bonus points to the refered member

    public void ZInviteFriendsBonusPoints(string ActivatedUserID)
    {
        
        try
        {
            string sQry = "EXEC USP_INVITATION_BONUS_POINTS_CALCULATE '" + ActivatedUserID + "'";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }




    public DataTable Zcheckemailid(string emailid)
    {
        try
        {
            string sqlquery = "SELECT * FROM tbl_freememreg as f,tbl_registration as p, tbl_invitefriends as i where f.emailid='" + emailid + "' or p.emailid='" + emailid + "' or i.emailid='" + emailid + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    //public void Zupdatemail(string tablename, string columnname, string uid,string userid, string email)
    //{
    //    try
    //    {
    //        string SQLQuery = "update " + tablename + "  set " + columnname + " = '" + email + "' where " + uid + " = '" + userid + "'";
    //        //string SQLQuery = "USP_BIT2BYTE4_updatemail '" + tablename + "','" + columnname + "', '" + email + "' ,'" + uid + "','" + userid + "'";
    //        int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
    //    }
    //    catch (Exception Ex)
    //    {
    //        throw Ex;
    //    }
    //}
    public DataTable ZfunEmailAlreadyExists(string tablename, string columnname, string email)
    {
        try
        {
            string sqlquery = "Select * from  " + tablename + " where " + columnname + " = '" + email + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getAffliateCount(string referalID)
    {
        try
        {
            //string sqlquery = "SELECT  COUNT(*) CTR FROM ALL_MEMBERS_VIEW WHERE REFERALID = '" + referalID + "'  AND ACTIVEUSER = 'A'";
            string sqlquery = "SELECT DBO.FN_GET_USER_DATA_GIVEN('" + referalID + "') CTR";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable getAffliateCountOptin(string referalID)
    {
        try
        {
            //string sqlquery = "SELECT  COUNT(*) CTR FROM ALL_MEMBERS_VIEW WHERE REFERALID = '" + referalID + "'  AND ACTIVEUSER = 'A'";
            string sqlquery = "SELECT DBO.FN_GET_USER_DATA_GIVEN_OPTIN('" + referalID + "') CTR";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void UpdateActivate_status(string userid, string activatedThrough)
    {
        try
        {
            //string sqlquery = "SELECT  COUNT(*) CTR FROM ALL_MEMBERS_VIEW WHERE REFERALID = '" + referalID + "'  AND ACTIVEUSER = 'A'";
            string sqlquery = "update tbl_freememreg  set ACTIVATED_THROUGH = '" + activatedThrough + "' where userid = '" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);
           
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    

    public int UpdateOptinData(string sMobileNo, string sMessage)
    {
        try
        {
            string sQry = "INSERT INTO TBL_OPTIN_INBOX(MOBILENO,MSG) VALUES ('" + sMobileNo + "','" + sMessage + "')";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
            return intRowAffect;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }

    public void ActivateNewUserFromOptin(string sMobileNo)
    {
        try
        {
            //string sQry = "EXEC USP_ACTIVATE_NEW_USER '" + sUserID + "'";
            //int intRowAffect = fnExecuteNonQuery(sQry, true);

            string[] strArrList = { "@MOBILENO" };
            string[] strArrValues = { sMobileNo};

            int intRowAffect = fnRunProcedure("USP_ACTIVATE_NEW_USER_FROM_OPTIN", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}