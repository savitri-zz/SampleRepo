﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for clsSP_FreeMem
/// </summary>
public class clsSP_FreeMem : BaseClass
{
	public clsSP_FreeMem()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public DataTable getfuFreemem(string mobileno)
    {
        try
        {
            string[] strArrList = { "@mobileno" };
            string[] strArrValues = { mobileno.ToString() };
            string SQLQuery = "sp_freememreg";
            return fnRunProcedureDatatable(SQLQuery, strArrList, strArrValues, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getfuUsermem(string mobileno)
    {
        try
        {
            string[] strArrList = { "@mobileno" };
            string[] strArrValues = { mobileno.ToString() };
            string SQLQuery = "sp_nonmemreg";
            return fnRunProcedureDatatable(SQLQuery, strArrList, strArrValues, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
}