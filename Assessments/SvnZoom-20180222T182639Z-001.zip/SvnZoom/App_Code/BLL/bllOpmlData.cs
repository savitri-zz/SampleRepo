﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for bllOpmlData
/// </summary>
public class bllOpmlData : BaseClass
{
    public bllOpmlData()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable getUserPersonalData(string sUserID)
    {
        try
        {
            EncryptDecryptQueryString objDecrypt = new EncryptDecryptQueryString();
            sUserID = objDecrypt.Decrypt(sUserID, "r0b1nr0y").ToString();
            string SQLQuery = "EXEC USP_GET_USER_PERSONAL_DATA '" + sUserID + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    //  Purpose:  Retreiving Recently Liked Ads
    public DataTable get_Recently_LikedAds(string sUid)
    {
        try
        {
            EncryptDecryptQueryString objDecrypt = new EncryptDecryptQueryString();
            sUid = objDecrypt.Decrypt(sUid, "r0b1nr0y").ToString();
            // string SQLQuery = "SELECT * FROM TBL_ADS_SMSPRODUCTS ADS ";
            // SQLQuery += "JOIN TBL_ADS_USER_LIKES LIKES ON ADS.SNO= LIKES.AD_SRL_NO WHERE LIKES.USER_ID='" + sUid + "' AND ADS.VISIBILITY_STATUS='TRUE' ORDER BY LIKES.LIKED_DT DESC";
            System.Text.StringBuilder SQLQuery = new System.Text.StringBuilder();
            SQLQuery.Append("SELECT DFL.CTR AD_LIKES_CTR , CONVERT(VARCHAR(100), DFL.LIKED_MAX_DT , 106) LIKED_MAX_DT_106,DFL.AD_SRL_NO,S.IMAGE,S.SNO,S.WEBSITE,S.DESCRIPTION,S.TITLE , S.OFFER_PRICE,S.MERCHANT_IMAGE_URL,S.urllink  FROM TBL_ADS_SMSPRODUCTS S ");
            SQLQuery.Append(" INNER  JOIN (SELECT ROW_NUMBER() OVER (ORDER BY MAX(LIKED_DT) DESC) AS A, AD_SRL_NO , MAX(LIKED_DT) LIKED_MAX_DT, COUNT(AD_SRL_NO) CTR");
            SQLQuery.Append(" FROM  TBL_ADS_USER_LIKES WHERE USER_ID = '" + sUid + "' ");
            SQLQuery.Append(" GROUP BY AD_SRL_NO) AS DFL ON S.SNO = DFL.AD_SRL_NO");
            SQLQuery.Append(" WHERE S.VISIBILITY_STATUS = 1 ORDER BY DFL.A");
            return GetDataTable(SQLQuery.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

  
    public DataSet bindZoom(string sUserId, string fLoad, string subStringIds)
    {
        try
        {
            //8206341977133737
            EncryptDecryptQueryString objDecrypt = new EncryptDecryptQueryString();
            sUserId = objDecrypt.Decrypt(sUserId, "r0b1nr0y").ToString();
            string sQry = "EXEC  dbo.USP_GetZoomUpdates_PageWise  '" + sUserId + "', '" + fLoad + "', '" + subStringIds + "' ";

            return GetDataSet(sQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}