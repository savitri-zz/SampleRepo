﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ClsPromotion_Pingen
/// </summary>
public class ClsPromotion_Pingen :BaseClass
{
	public ClsPromotion_Pingen()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public DataTable Bussinessuserexists(string mobileno, string emailid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Promotional_pinGen where MobileNo ='" + mobileno + "' and Emailid = '" + emailid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertPromotionalpin_generate(string mobileno, string name, string emailid, string Amount, string Generated_date, string status, string GenerationPIN)
    {
        try
        {

            //string SQLQuery = "insert into tbl_Promotional_pinGen(mobileno,name,emailid, Amount, Generated_date,status,GenerationPIN) values ('" + mobileno + "','" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "','" + status + "','" + GenerationPIN + "')";
            string SQLQuery = "USP_insertPromotionalpin_generate '" + mobileno + "','" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "','" + status + "','" + GenerationPIN + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}