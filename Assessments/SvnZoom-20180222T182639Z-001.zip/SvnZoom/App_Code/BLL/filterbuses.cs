﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for filterbuses
/// </summary>
public class filterbuses:BaseClass
{
	public filterbuses()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable getfilterbuses(string values)
    {
        try
        {
            string SQLQuery ="select * from tbl_businfo where buscondition='" + values + "'" ;
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getfilterbusesbytravels(string values)
    {
        try
        {
            string SQLQuery = "select * from tbl_businfo where Travelsname ='" + values + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getfilterbusesbybrod(string values)
    {
        try
        {
            string SQLQuery = "select * from tbl_businfo where Bordingpoints='" + values + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getfilterbusesbydrop(string values)
    {
        try
        {
            string SQLQuery = "select * from tbl_businfo where Dropingpoints='" + values + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getbusinfo3()
    {
        try
        {
            string SQLQuery = "select * from tbl_businfo ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void inserttempbusinfo(string busname, string deptim, string seatavail, string sellfair, string servicename, string arrivaltime, string bustype, string routeid, string userid)
    {
        try
        {

            string SQLQuery = "insert tempbusinfo(Travelsname,Departuretime,seatavailabl,sellfair,servicename,arrivaltime,bustype,routeid,userid) values ('" + busname + "','" + deptim + "','" + seatavail + "','" + sellfair + "','" + servicename + "','" + arrivaltime + "','" + bustype + "','" + routeid + "','" + userid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable bindbustable(string userid)
    {
        try
        {
            string SQLQuery = "select * from tempbusinfo where userid='"+userid+"' order by sno desc ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable filtertempdetails(string values, string userid,string routeid)
    {
        try
        {
            string SQLQuery = "select * from tempbusinfo where Travelsname='" + values + "' and userid='" + userid + "' and routeid='"+routeid+"'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void deleteuseridvalues(string values, string userid)
    {
        try
        {

            string SQLQuery = "delete from  tempbusinfo where Travelsname='" + values + "' and userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable bindbussess()
    {
        try
        {
            string SQLQuery = "select * from tbl_businfo ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getbusinfo3454(string depar, string arri)
    {
        try
        {
            string SQLQuery = "select * from tbl_businfo where Bordingpoints='" + depar + "' and DropingPoints='" + arri + "' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void deleteuserid2()
    {
        try
        {

            string SQLQuery = "delete from   tbl_businfo";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void DeleteBusTypes333()
    {
        try
        {
            string SQLQuery = "delete from tbl_busTypeCondition ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable busselected()
    {
        try
        {
            string SQLQuery = "select * from tbl_busTypeCondition ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable allbindbustable()
    {
        try
        {
            string SQLQuery = "select * from tempbusinfo";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void Deletetempbus()
    {
        try
        {
            string SQLQuery = "delete from tempbusinfo";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

}