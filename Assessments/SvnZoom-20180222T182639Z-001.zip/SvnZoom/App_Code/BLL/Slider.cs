﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Slider
/// </summary>
public class Slider
{
    private int sID;
    private string sTitle;
    private string sDescription;
    private string sImageName;
    private bool sIsActive;

    public int ID
    {
        get
        {
            return sID;

        }
        set
        {
            sID = value;
        }
    }

    //To get or set the Title of Image
    public string Title
    {
        get
        {
            return sTitle;
        }
        set
        {
            sTitle = value;
        }
    }

    public bool IsActive
    {
        get
        {
            return sIsActive;
        }
        set
        {
            sIsActive = value;
        }
    }

    public string Description
    {
        get
        {
            return sDescription;
        }
        set
        {
            sDescription = value;
        }
    }

    public string ImageName
    {
        get
        {
            return sImageName;
        }
        set
        {
            sImageName = value;
        }
    }
}