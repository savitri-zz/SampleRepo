﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for clsMails
/// </summary>
public class clsMails : BaseClass
{
	public clsMails()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetBinaryDatewisePayout_Mem()
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.emailid as emailid,tbl_registration.sno as  ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_Userwalletstatus.walletstatus = '0' order by CAST(tbl_registration.joindate as DATE) ASC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetreferalDatewisePayout(string strUserid)
    {
        try
        {
            string SQLQuery = "select SUM(cast(Totamt as int)) as Totamt from tbl_ReferalInfo where  userid = '" + strUserid.ToString() + "'";           
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetBinaryDatewisePayout(string strUserid)
    {
        try
        {
            string SQLQuery = " select SUM(cast(BeforeDeductionNetAmt as int)) as Totamt from tbl_Binarypayoutdetails_New where  userid = '" + strUserid.ToString() + "'";           
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetDataDatewisePayout(string strUserid)
    {
        try
        {
            string SQLQuery = "select SUM(cast(totalamt as int)) as Totamt from tbl_Datapayoutdetails where  userid = '" + strUserid.ToString() + "'";          
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

}