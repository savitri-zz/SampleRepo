﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for smspack
/// </summary>
public class smspack:BaseClass
{
	public smspack()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public DataTable getimages()
    {

        try
        {
            string sqlquery = "select * from tbl_Products  where sno in (2,3,4 )";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable findsummrp(string sno)
    {

        try
        {
            string sqlquery = "select (cast(mrp as float)  + cast(proccingfee as float)) as pmCost  from tbl_Products where sno='"+sno+"'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public DataTable getimages1()
    {

        try
        {
            string sqlquery = "select * from tbl_Products  where sno in (5,6)";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public DataTable getimages2()
    {

        try
        {
            string sqlquery = "select * from tbl_Products  where sno='2'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable getimages5()
    {

        try
        {
            string sqlquery = "select * from tbl_Products  where sno=5";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }



    public DataTable getimages4()    //narendra
    {

        try
        {
            string sqlquery = "select * from tbl_Products  where sno in (4 )";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable getimages3()
    {

        try
        {
            string sqlquery = "select * from tbl_Products  where sno='3'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    public DataTable getimages6()
    {

        try
        {
            string sqlquery = "select * from tbl_Products  where sno='6'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void insertamountdetails(string name,string mobile,string email,string amount,string uid,string productno,string productcode,string productremarkname,string Activateuser,string codename,string joindate)
    {
        try
        {
            string sqlquery = "insert into tbl_bankdepositusers (name,mobileno,email,amount,userid,productno,productcode,productremarkname,Activateuser,codename,upgradedate)values('" + name + "','" + mobile + "','" + email + "','" + amount + "','" + uid + "','" + productno + "','" + productcode + "','" + productremarkname + "','" + Activateuser + "','" + codename + "','" + joindate + "') ";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable getMethodExists(string mobileno, string sno, string productcode)
    {

        try
        {
            string sqlquery = "select * from tbl_bankdepositusers where  mobileno = '" + mobileno + "' and productno = '" + sno + "' and productcode='" + productcode + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable GetEmailTemplateDetails(string Mobileno)
    {
        try
        {
            string SQLquery = "select P.PRODUCT_NAME,B.AMOUNT,B.PRODUCTCODE,B.UPGRADEDATE, B.CODENAME  from  tbl_products P ";
                   SQLquery=SQLquery+" inner join tbl_bankdepositusers B ON P.CODE=B.PRODUCTCODE WHERE B.MOBILENO='" + Mobileno + "'";
                   return GetDataTable(SQLquery, true);
        }
        catch(Exception ex)
        {
            throw ex;
        }

    }



    public DataTable getproductamount(string sno)
    {

        try
        {
            string sqlquery = "select * from tbl_Products where sno='"+sno+"'" ;
            return GetDataTable(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable getfreedetails(string uid)
    {
        try{
            string sqlquery="select * from tbl_freememreg where userid='"+uid+"'";
            return GetDataTable(sqlquery, true);
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    public DataTable getpaiddetails(string uid)
    {
        try
        {
            string sqlquery = "select * from tbl_registration where userid='" + uid + "'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable finduserid(string refmobile)
    {
        try
        {
            string sqlquery = "select * from tbl_registration where mobileno='" + refmobile + "'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public DataTable findfreeuserid(string refmobile)
    {
        try
        {
            string sqlquery = "select * from tbl_freememreg where mobileno='" + refmobile + "'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable findproducrno(string no)
    {
        try
        {
            string sqlquery = "select * from tbl_bankdepositusers where userid='" + no + "'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public void insertdetails(string productno, string mobile, string password, string name, string email, string state, string city, string placement, string placementid, string SponsorUserID, string levelno, string referid, string usertype, string joindate, string status, string verificationcode, string userid, string TransactionId, string upgrade, string initpakg, string activestatus, string PaidStatus)
    {
        try
        {
            string sqlquery = "insert into tbl_registration (producttype,mobileno,password,fullname,emailid,state,city,placement,placementid,SponsorUserID,levelno,referid,usertype,joindate,status,verificationcode,userid,TransactionId,upgrade,initpakg,activestatus,PaidStatus)values('" + productno + "','" + mobile + "','" + password + "','" + name + "','" + email + "','" + state + "','" + city + "','" + placement + "','" + placementid + "','" + SponsorUserID + "','" + levelno + "','" + referid + "','" + usertype + "','" + joindate + "','" + status + "','" + verificationcode + "','" + userid + "','" + TransactionId + "','" + upgrade + "','" + initpakg + "','" + activestatus + "','" + PaidStatus + "') ";
            int intRowAffect = fnExecuteNonQuery(sqlquery, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void deletedetails(string no)
    {
        try
        {
          //  string sqlquery = "delete from tbl_freememreg where mobileno='" + no + "'";
          //  int intRowAffect = fnExecuteNonQuery(sqlquery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    private readonly Random _rng = new Random();
    private const string _chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    public string RandomString()
    {
        char[] buffer = new char[8];

        for (int i = 0; i < 8; i++)
        {
            buffer[i] = _chars[_rng.Next(_chars.Length)];
        }
        return new string(buffer);
    }
    
}