﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for clsBinaryPayouts
/// </summary>
public class clsReferalPayouts : BaseClass
{
    protected string strNodevalue = "";
    protected string strSubnodevalue = "";
    protected string strUserIDS = "";
    protected string strTotalBVSum = "";
    protected int strBVTotal = 0;
    protected DateTime strjoindate;
    public clsReferalPayouts()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetBinaryDatewisePayout_Mem(string date)
    {
        try
        {
            //string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
            //SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            //SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            //SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_Userwalletstatus.walletstatus = '0' and  CAST(tbl_registration.joindate as DATE) <=  '" + date + "' order by CAST(tbl_registration.joindate as DATE) DESC ";
            string SQLQuery = " USP_GetBinaryDatewisePayout_Mem  '" + date + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

   

    public DataTable GetBinaryReferids_WithDates(string refid, string placement, string JoinDate)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.referid=tbl_Userwalletstatus.useid and tbl_registration.referid='" + refid + "' and tbl_registration.placement='" + placement + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) <=  '" + JoinDate + "' order by CAST(tbl_registration.joindate as DATE) asc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable getreferalidBetweenDates(string referid, string date, string date1)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_registration.referid='" + referid + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) between  '" + date + "' and '" + date1 + "' order by CAST(tbl_registration.joindate as DATE) asc ";
            return GetDataTable(SQLQuery, true);           
          
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getProductsname(string sno)
    {
        try
        {
            string SQLQuery = "select * from tbl_Products where sno = '" + sno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetReferalInfo(string Payoutdate)
    {
        try
        {
            string SQLQuery = "select * from tbl_ReferalInfo where Payoutdate = '" + Payoutdate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertReferalInfo(string Payoutdate, string userid, string name, string mobileno, string BV, string Refmem, string BonusBV, string TotalBV, string Totamt)
    {
        try
        {
           // string SQLQuery = "insert into tbl_ReferalInfo(Payoutdate, userid, name, mobileno,BV, Refmem, BonusBV,TotalBV, Totamt) values ('" + Payoutdate + "','" + userid + "', '" + name + "', '" + mobileno + "','" + BV + "', '" + Refmem + "', '" + BonusBV + "','" + TotalBV + "', '" + Totamt + "')";
            string SQLQuery = "USP_insertReferalInfo '" + Payoutdate + "','" + userid + "', '" + name + "', '" + mobileno + "','" + BV + "', '" + Refmem + "', '" + BonusBV + "','" + TotalBV + "', '" + Totamt + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

}