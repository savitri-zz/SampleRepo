﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for clsBinary_cum_referal
/// </summary>
public class clsBinary_cum_referal : BaseClass
{
	public clsBinary_cum_referal()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataTable GetBinaryDatewisePayout_Mem(string StartDate, string EndDate)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.referid as referid,tbl_registration.joindate as joindate,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_Userwalletstatus.walletstatus = '0' and CAST(tbl_registration.joindate as DATE) between '" + StartDate.ToString() + "' and '" + EndDate.ToString() + "'  order by CAST(tbl_registration.joindate as DATE) DESC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable ZGetUserid(string payoutDate)
    {
        try
        {
            string SQLQuery = " select * from tbl_Binarypayoutdetails_New where  cast(PayoutDate as date)  ='" + payoutDate + "' order by sno asc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable ZGetmemWithDate(string refid, string date)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where placementid = '" + refid + "' and CAST(joindate as DATE) <= '" + date.ToString() + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getproductBVsum(string productid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Products where sno = '" + productid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable ZgetreferalidBetweenDates(string referid, string date)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration where ";
            SQLQuery = SQLQuery + "  tbl_registration.referid='" + referid + "'";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) =  '" + date + "' order by CAST(tbl_registration.joindate as DATE) asc ";
            return GetDataTable(SQLQuery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void InsertBinaryCVCalc(string PayoutDate, string Userid, string PersonnelCV, string SponsorID, string ReferralAmt, string BalanceCV)
    {
        try
        {
           // string SQLQuery = "insert into tbl_BinaryCVCalc(PayoutDate,Userid, PersonnelCV, SponsorID, ReferralAmt, BalanceCV) values ('" + PayoutDate + "','" + Userid + "', '" + PersonnelCV + "', '" + SponsorID + "', '" + ReferralAmt + "', '" + BalanceCV + "')";

            string SQLQuery = "USP_InsertBinaryCVCalc  '" + PayoutDate + "','" + Userid + "', '" + PersonnelCV + "', '" + SponsorID + "', '" + ReferralAmt + "', '" + BalanceCV + "'";




            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable ZGetBinaryDatewisePayout_Mem(string userid)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_registration.userid='" + userid + "' and tbl_Userwalletstatus.walletstatus = '0' order by CAST(tbl_registration.joindate as DATETIME) ASC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryPayoutDetails(string PayoutDate)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Binarypayoutdetails_New where PayoutDate = '" + PayoutDate + "' and BeforeDeductionNetAmt <> '0' order by sno ASC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryPayoutCVDetails(string userid, string PayoutDate)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_BinaryCV_Calc1 where userid='" + userid + "' and PayoutDate='" + PayoutDate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}