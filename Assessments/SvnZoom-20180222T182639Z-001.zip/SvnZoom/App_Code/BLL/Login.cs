﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for BllLogin
/// </summary>
public class Login : BaseClass
{



    public string CheckLogin(string userid, string password)
    {
        try
        {
            string SQLQuery = "select RoleID from tbl_Users where UserID ='" + userid + "' and  Password='" + password + "' and  StatusID= 1";
            return GetSingleValue(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public Login()
    {
        //
        // TODO: Add constructor logic here
        //
    }


    public DataSet GetUserInfo()
    {
        try
        {
            string SQLQuery = " SELECT tUREG.UserID as UserID, tUREG.UserName,tUREG.Password, tUREG.EmailId, tUREG.MobileNo, tUR.RoleID,tUREG.GenderID,tUREG.StatusID,tUREG.CreatedDate,tUREG.CreatedBy,tUREG.UpdatedDate,tUREG.UpdatedBy FROM tbl_Users as tUREG INNER JOIN tbl_UserRoles as tUR ON tUREG.RoleID = tUR.RoleID  where tUR.RoleID != 'Admin'";
            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataSet GetUserInfo(string roleid)
    {
        try
        {
            string SQLQuery = " SELECT tUREG.UserID as UserID, tUREG.UserName,tUREG.Password, tUREG.EmailId, tUREG.MobileNo, tUR.RoleID,tUREG.GenderID,tUREG.StatusID,tUREG.CreatedDate,tUREG.CreatedBy,tUREG.UpdatedDate,tUREG.UpdatedBy FROM tbl_Users as tUREG INNER JOIN tbl_UserRoles as tUR ON tUREG.RoleID = tUR.RoleID  where tUR.RoleID = '"+ roleid +"'";
            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataSet GetUserRoles()
    {
        try
        {
            string SQLQuery = "SELECT RoleId,StatusID,CreatedDate,UpdatedDate FROm tbl_UserRoles WHERE RoleID !='Admin'";
            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataSet GetRoles()
    {
        try
        {
            string SQLQuery = "SELECT RoleId FROM tbl_UserRoles WHERE RoleID !=1";
            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertUser(string LoginUser, EntLogin entR)
    {
        try
        {
            string SQLQuery = "INSERT INTO tbl_Users(UserID,UserName,Password,EmailId,MobileNo,GenderID,RoleID,StatusID,CreatedDate,CreatedBy,valid_ip_addresses)VALUES('" + entR.UserID + "','" + entR.UserName + "','" + entR.Password + "','" + entR.EmailId + "','" + entR.MobileNo + "','" + entR.GenderID + "','" + entR.RoleID + "',0,getdate(),'" + LoginUser + "','202.65.155.22;49.205.64.170')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void UpdatetUser(string LoginUser, EntLogin entR)
    {
        try
        {
            string SQLQuery = "UPDATE tbl_Users SET UserID ='" + entR.UserID + "',UserName = '" + entR.UserName + "',Password = '" + entR.Password + "',EmailId = '" + entR.EmailId + "',MobileNo = '" + entR.MobileNo + "',GenderID = '" + entR.GenderID + "',RoleID = '" + entR.RoleID + "',StatusID = '" + entR.StatusID + "',UpdatedDate = getdate(),UpdatedBy = '" + entR.UserID + "' WHERE UserId= '" + entR.UserID + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void InsertRole(string LoginUser, EntLogin entR)
    {
        try
        {
            string SQLQuery = "INSERT INTO tbl_UserRoles(RoleID,StatusID,CreatedDate)VALUES('" + entR.RoleID + "','" + entR.StatusID + "',getdate())";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void UpdateRole(EntLogin entR)
    {
        try
        {
            string SQLQuery = "UPDATE tbl_UserRoles SET RoleID ='" + entR.RoleID + "',StatusID = '" + entR.StatusID + "',UpdatedDate = getdate() WHERE RoleID= '" + entR.RoleID + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public bool Existingusercheck(string id)
    {
        throw new NotImplementedException();
    }

    public DataSet SendMailToUser(string mailId)
    {
        throw new NotImplementedException();
    }

    public DataSet GetUserDetails(string usrid)
    {
        try
        {
            string SQLQuery = " SELECT UserID , UserName,EmailId, MobileNo FROM tbl_Users where StatusID != 0 and  UserID = '" + usrid + "'";
            return GetDataSet(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public bool GetUserDetails(string userid, string mailid,string password)
    {
        try
        {
              SqlDataReader dr ;//= new SqlDataReader();
                dr =CheckExisting(userid,mailid);
                if (dr.Read())
                {
                    try
                    {
                        string SQLQuery = "UPDATE tbl_Users SET Password = '" + password + "' , UpdatedDate=getdate() , UpdatedBy='" + userid + "' where StatusID != 0 and UserId= '" + userid + "'";

                        int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
                        if (intRowAffect>0)
                        {
                            return true;
                        }
                        else
                            return false;
                    }
                    catch (Exception Ex)
                    {
                        throw Ex;
                    }
                    return true;
                }
                else
                    return false;
           
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    private SqlDataReader CheckExisting(string userid, string mailid)
    {
        string SQLQuery = " SELECT UserID , EmailId FROM tbl_Users where StatusID != 0 and  UserID = '" + userid + "' and  EmailId = '" + mailid + "'";
        return fnExecuteReader(SQLQuery, true);


    }
}