﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


/// <summary>
/// Summary description for clseventlogin
/// </summary>
public class clseventlogin : BaseClass
{
    public clseventlogin()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable selectguest()
    {
        try
        {
            string SQLQuery = "select * from tbl_eventmember where passno is not null order by sno Desc";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable sampleDeactive()
    {
        try
        {
            string SQLQuery = "select * from tbl_emailTemplates where template_ID= 6";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable selectpartner()
    {
        try
        {
            string SQLQuery = "select * from tbl_eventpaid where passno is not null order by sno Desc";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetEventMasterData()
    {
        try
        {
            string SQLQuery = "SELECT EVENT_ID, EVENT_NAME, EVENT_DESCRIPTION, CONDUCTING_DATE, CAMPAIGNING_DATE,";
            SQLQuery = SQLQuery + " PASSES_START_DATE, PASSES_END_DATE, EVENT_HIGHLIGHTS, PASS_SRL_NO_SUFFFIX ";
            SQLQuery = SQLQuery + " MIN_NO_OF_DATA_REQUIRED, EVENT_DATE_IN_MAIL, EVENT_BEGINS_IN_MAIL, EVENT_CHECKIN_IN_MAIL, EVENT_WITH_REGARDS_IN_MAIL, EVENT_VENUE_DETAILS_IN_MAIL";
            SQLQuery = SQLQuery + " FROM TBL_EVENTS_MASTER where Is_Visible = 1 order by EVENT_ID DESC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetOnGoingEvents()
    {
        try
        {
            string SQLQuery = "SELECT EVENT_ID, EVENT_NAME, EVENT_DESCRIPTION, CONDUCTING_DATE, CAMPAIGNING_DATE,";
            SQLQuery = SQLQuery + " PASSES_START_DATE, PASSES_END_DATE, EVENT_HIGHLIGHTS, PASS_SRL_NO_SUFFFIX ";
            SQLQuery = SQLQuery + " MIN_NO_OF_DATA_REQUIRED, EVENT_DATE_IN_MAIL, EVENT_BEGINS_IN_MAIL, EVENT_CHECKIN_IN_MAIL, EVENT_WITH_REGARDS_IN_MAIL, EVENT_VENUE_DETAILS_IN_MAIL";
            SQLQuery = SQLQuery + " FROM TBL_EVENTS_MASTER WHERE PASSES_END_DATE >= GETDATE()";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetOnGoingEvents(string AffiliateID)
    {
        try
        {
            string SQLQuery = "     SELECT EVENT_ID, EVENT_NAME, EVENT_DESCRIPTION, CONDUCTING_DATE, CAMPAIGNING_DATE,";
            SQLQuery = SQLQuery + " PASSES_START_DATE, PASSES_END_DATE, EVENT_HIGHLIGHTS, PASS_SRL_NO_SUFFFIX ";
            SQLQuery = SQLQuery + " MIN_NO_OF_DATA_REQUIRED, EVENT_DATE_IN_MAIL, EVENT_BEGINS_IN_MAIL, EVENT_CHECKIN_IN_MAIL, EVENT_WITH_REGARDS_IN_MAIL, EVENT_VENUE_DETAILS_IN_MAIL";
            SQLQuery = SQLQuery + " FROM TBL_EVENTS_MASTER WHERE PASSES_END_DATE >= GETDATE()";
            SQLQuery = SQLQuery + "  and EVENT_ID in (select EVENT_ID from TBL_EVENT_USER_DETAILS where USER_ID = '" + AffiliateID + "' and Can_issue_pass = 1)";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable CheckCanIssuePasses(string sUserID)
    {
        try
        {
            string sQry = " SELECT EM.EVENT_ID, EM.EVENT_NAME, EM.EVENT_DESCRIPTION, EM.CONDUCTING_DATE, EM.CAMPAIGNING_DATE, EM.PASSES_START_DATE, EM.PASSES_END_DATE,";
            sQry = sQry + " EM.EVENT_HIGHLIGHTS, EM.PASS_SRL_NO_SUFFFIX, EM.MIN_NO_OF_DATA_REQUIRED, EM.EVENT_DATE_IN_MAIL, EM.EVENT_BEGINS_IN_MAIL,";
            sQry = sQry + " EM.EVENT_CHECKIN_IN_MAIL, EM.EVENT_WITH_REGARDS_IN_MAIL, EM.EVENT_VENUE_DETAILS_IN_MAIL, EM.EVENT_SMS_TEMPLATE, ";
            sQry = sQry + " EM.EVENT_PASS_MAX_LIMIT, EM.EVENT_PASS_AFFILIATES_MAX_LIMIT, EM.EVENT_LOCATION_SMS, ";
            sQry = sQry + " UD.* ";
            sQry = sQry + " FROM TBL_EVENTS_MASTER EM INNER JOIN TBL_EVENT_USER_DETAILS UD ON EM.EVENT_ID = UD.EVENT_ID ";
            sQry = sQry + " WHERE PASSES_END_DATE >= GETDATE() AND UD.CAN_ISSUE_PASS = 1  AND UD.USER_ID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable CheckForActiveEvents(string userid)
    {
        try
        {
            string sQry = " SELECT TOP 1 EM.EVENT_ID, EM.EVENT_NAME, EM.EVENT_DESCRIPTION, EM.CONDUCTING_DATE, EM.CAMPAIGNING_DATE, EM.PASSES_START_DATE, EM.PASSES_END_DATE, ";
            sQry = sQry + " EM.EVENT_HIGHLIGHTS, EM.PASS_SRL_NO_SUFFFIX, EM.MIN_NO_OF_DATA_REQUIRED, EM.EVENT_DATE_IN_MAIL, EM.EVENT_BEGINS_IN_MAIL, ";
            sQry = sQry + " EM.EVENT_CHECKIN_IN_MAIL, EM.EVENT_WITH_REGARDS_IN_MAIL, EM.EVENT_VENUE_DETAILS_IN_MAIL, EM.EVENT_SMS_TEMPLATE, ";
            sQry = sQry + " EM.EVENT_PASS_MAX_LIMIT, EM.EVENT_PASS_AFFILIATES_MAX_LIMIT, EM.EVENT_LOCATION_SMS,  ";
            sQry = sQry + " UD.*  ";
            sQry = sQry + " FROM TBL_EVENTS_MASTER EM  ";
            sQry = sQry + "     INNER JOIN TBL_EVENT_USER_DETAILS UD ON EM.EVENT_ID = UD.EVENT_ID  ";
            sQry = sQry + " WHERE EM.PASSES_END_DATE >= GETDATE() AND UD.USER_ID = '"+ userid +"' AND ISNULL(IS_PASS_ISSUED, 0) = 0 ";
            sQry = sQry + " ORDER BY CONDUCTING_DATE ";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }





    public DataTable GetEventMasterData(string sEventID)
    {
        try
        {
            string SQLQuery = "SELECT EVENT_ID, EVENT_NAME, EVENT_DESCRIPTION, CONDUCTING_DATE, CAMPAIGNING_DATE, Event_Location_SMS,";
            SQLQuery = SQLQuery + " PASSES_START_DATE, PASSES_END_DATE, EVENT_HIGHLIGHTS, PASS_SRL_NO_SUFFFIX ";
            SQLQuery = SQLQuery + " , ISNULL(MIN_NO_OF_DATA_REQUIRED , 0) MIN_NO_OF_DATA_REQUIRED, EVENT_DATE_IN_MAIL, EVENT_BEGINS_IN_MAIL, EVENT_CHECKIN_IN_MAIL, EVENT_WITH_REGARDS_IN_MAIL, EVENT_VENUE_DETAILS_IN_MAIL , EVENT_SMS_TEMPLATE , ISNULL(EVENT_PASS_MAX_LIMIT , 0) EVENT_PASS_MAX_LIMIT";
            SQLQuery = SQLQuery + " , ISNULL(EVENT_PASS_AFFILIATES_MAX_LIMIT , 0) EVENT_PASS_AFFILIATES_MAX_LIMIT,typeofevent FROM TBL_EVENTS_MASTER WHERE EVENT_ID = '" + sEventID + "' AND PASSES_END_DATE >= GETDATE()";// AND PASSES_END_DATE >= GETDATE()


            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetPassMaxID(string sEventID)
    {
        try
        {
            string sQry = "SELECT ISNULL(MAX(RIGHT(PASS_ID, 3)) , 0) PASS_MAX_ID FROM TBL_EVENT_USER_DETAILS WHERE EVENT_ID = '" + sEventID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }

    }

    public DataTable getEventUserDetails()
    {
        try
        {
            string sQry = "SELECT EVENT_ID, USER_ID, MAIL_SENT_DATE, IS_PASS_REQUESTED, PASS_REQUESTED_DATE, IS_ELIGIBLE,";
            sQry = sQry + " IS_PASS_ISSUED, PASS_ID, PASS_ISSUED_DATE, IS_ATTENDED FROM TBL_EVENT_USER_DETAILS ";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }

    public DataTable getEventUserDetails(string sPassID)
    {
        try
        {
            string sQry = "SELECT EVENT_ID, USER_ID, MAIL_SENT_DATE, IS_PASS_REQUESTED, PASS_REQUESTED_DATE, IS_ELIGIBLE,";
            sQry = sQry + " IS_PASS_ISSUED, PASS_ID, PASS_ISSUED_DATE, IS_ATTENDED FROM TBL_EVENT_USER_DETAILS ";
            sQry = sQry + " WHERE PASS_ID = '" + sPassID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }

    public DataTable GetEventUserDetailsByUserID(string sEventID, string sUserID)
    {
        try
        {
            string sQry = "SELECT EVENT_ID, USER_ID, MAIL_SENT_DATE, IS_PASS_REQUESTED, PASS_REQUESTED_DATE, IS_ELIGIBLE,";
            sQry = sQry + " IS_PASS_ISSUED, PASS_ID, PASS_ISSUED_DATE, IS_ATTENDED, EVENT_USER_NAME, EVENT_USER_EMAIL FROM TBL_EVENT_USER_DETAILS ";
            sQry = sQry + " WHERE EVENT_ID = '" + sEventID + "' AND USER_ID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }

    public DataTable CheckPassByUserID(string sUserID, string sEventID)
    {
        try
        {
            string sQry = "SELECT EVENT_ID, USER_ID, MAIL_SENT_DATE, IS_PASS_REQUESTED, PASS_REQUESTED_DATE, IS_ELIGIBLE,";
            sQry = sQry + " IS_PASS_ISSUED, PASS_ID, PASS_ISSUED_DATE, IS_ATTENDED FROM TBL_EVENT_USER_DETAILS ";
            sQry = sQry + " WHERE EVENT_ID = '" + sEventID + "' AND USER_ID = '" + sUserID + "' AND ISNULL(IS_PASS_ISSUED,0) = 1 ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }

    public void updatePassRequest(string sEventID, string sUserID)
    {
        try
        {
            string SQLQuery = "UPDATE TBL_EVENT_USER_DETAILS SET IS_PASS_REQUESTED = 1 , PASS_REQUESTED_DATE = GETDATE() WHERE  EVENT_ID = '" + sEventID + "' AND USER_ID='" + sUserID + "' AND ISNULL(IS_PASS_REQUESTED ,0) = 0  ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public void insertMasterEventDetails(string userid, string status, string imagename)
    {
        try
        {
            string SQLQuery = "insert into tbl_imagedetail (userid,status, imagename) values ('" + userid + "','" + status + "', '" + imagename + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetEventInvitationsData()
    {
        try
        {
            string sQry = "SELECT USERID , EMAILID FROM ALL_MEMBERS_VIEW WHERE ACTIVEUSER = 'A' and userid not in (SELECT USERID FROM TBL_EMAIL_SENT_LOG WHERE PURPOSE = 'EVENT INVITATION MAIL' AND DATEDIFF(DAY, SENT_TIME , GETDATE()) > 1)";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetIssuedPassesCount(string sEventID)
    {
        try
        {
            string sQry = "SELECT COUNT(*) CTR FROM TBL_EVENT_USER_DETAILS WHERE EVENT_ID = '" + sEventID + "' AND IS_PASS_ISSUED = 1";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetIssuedPassesCount(string sEventID, bool sThroughCampaign)
    {
        try
        {
            string sQry = "SELECT COUNT(*) CTR FROM TBL_EVENT_USER_DETAILS WHERE EVENT_ID = '" + sEventID + "' AND IS_PASS_ISSUED = 1 AND IS_INVITED_BY_AFFILIATE = 0";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    //Reinvitation Mail To Eligible Users


    //public DataTable GetEvent_ReInvitationsData()
    //{
    //    try
    //    {
    //        string sQry = "select USERID,FULLNAME,EMAILID from REGISTRION_DETAILS_VIEW  where userid in (select user_id from tbl_event_user_details where is_pass_ISSUED IS NULL) and no_of_invites >=5";

    //        return GetDataTable(sQry, true);
    //    }
    //    catch (Exception ex)
    //    {

    //        throw;
    //    }
    //}



    public DataTable GetEvent_ReInvitationsData()
    {
        try
        {
            string sQry = "select * from dbo.REGISTRION_DETAILS_VIEW where userid in (select user_id from tbl_event_user_details where is_pass_requested = 1 and is_pass_issued = 1)";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public void InsertEventInvitation(string sEventID, string sUserID)
    {
        try
        {
            string sQry = "IF NOT EXISTS(SELECT * FROM TBL_EVENT_USER_DETAILS WHERE EVENT_ID = '" + sEventID + "' AND USER_ID = '" + sUserID + "') INSERT INTO TBL_EVENT_USER_DETAILS(EVENT_ID, USER_ID, MAIL_SENT_DATE) VALUES ('" + sEventID + "','" + sUserID + "',getdate())";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public void InsertEventInvitation(string sEventID, string sUserID, string canissuepass)
    {
        try
        {
            string sQry = "IF NOT EXISTS(SELECT * FROM TBL_EVENT_USER_DETAILS WHERE EVENT_ID = '" + sEventID + "' AND USER_ID = '" + sUserID + "') INSERT INTO TBL_EVENT_USER_DETAILS(EVENT_ID, USER_ID, MAIL_SENT_DATE,CAN_ISSUE_PASS) VALUES ('" + sEventID + "','" + sUserID + "',getdate(),'" + canissuepass + "')";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateEventInvitationByAffiliate(string sEventID, string sUserID)
    {
        try
        {
            string sQry = "UPDATE TBL_EVENT_USER_DETAILS SET IS_INVITED_BY_AFFILIATE = 1 WHERE EVENT_ID = '" + sEventID + "' AND USER_ID = '" + sUserID + "'";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void InsertEventInvitationByAffiliate(string sEventID, string sUserID, string invitedBy)
    {
        try
        {
            string sQry = "IF NOT EXISTS(SELECT * FROM TBL_EVENT_USER_DETAILS WHERE EVENT_ID = '" + sEventID + "' AND USER_ID = '" + sUserID + "') INSERT INTO TBL_EVENT_USER_DETAILS(EVENT_ID, USER_ID, MAIL_SENT_DATE,Invited_by) VALUES ('" + sEventID + "','" + sUserID + "',getdate(),'"+invitedBy+"')";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetEventUsersInvitedByAffiliate(string sEventID)
    {
        try
        {
            string sQry = "SELECT EVENT_ID, USER_ID, MAIL_SENT_DATE, IS_PASS_REQUESTED, PASS_REQUESTED_DATE, IS_ELIGIBLE, IS_PASS_ISSUED, PASS_ID, PASS_ISSUED_DATE, IS_ATTENDED, EVENT_USER_NAME, EVENT_USER_EMAIL, IS_INVITED_BY_AFFILIATE ";
            sQry = sQry + " FROM TBL_EVENT_USER_DETAILS WHERE EVENT_ID = '" + sEventID + "' AND IS_PASS_ISSUED = 1 AND IS_INVITED_BY_AFFILIATE = 1";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void InsertEventInvitation(string sEventID, string sUserID, string sUserName, string sEmailID, string invitedBy)
    {
        try
        {
            string sQry = "IF NOT EXISTS(SELECT * FROM TBL_EVENT_USER_DETAILS WHERE EVENT_ID = '" + sEventID + "' AND USER_ID = '" + sUserID + "') INSERT INTO TBL_EVENT_USER_DETAILS(EVENT_ID, USER_ID, MAIL_SENT_DATE, EVENT_USER_NAME, EVENT_USER_EMAIL,Invited_by) VALUES ('" + sEventID + "','" + sUserID + "',getdate() , '" + sUserName + "' , '" + sEmailID + "','" + invitedBy + "')";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdatePassIssuedDetails(string sEventID, string sUserID, string sPassID)
    {
        try
        {
            string sQry = "UPDATE TBL_EVENT_USER_DETAILS  SET IS_ELIGIBLE = 1, IS_PASS_ISSUED = 1, PASS_ID ='" + sPassID + "', PASS_ISSUED_DATE = GETDATE() WHERE EVENT_ID = '" + sEventID + "' AND USER_ID = '" + sUserID + "' AND ISNULL(IS_PASS_ISSUED, 0) = 0";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }

    public DataTable getUsersForLiveLink()
    {
        try
        {
            string sQry = "SELECT USERID, FULLNAME, EMAILID, MOBILENO, REF_NAME, (SELECT IMAGENAME FROM TBL_IMAGEDETAIL I WHERE I.USERID = V.REFERID ) REF_PHOTO, ";
            sQry = sQry + " DBO.FN_GET_DETAILS_BY_USERID( REFERID , 'OCCUPATION') OCCUPATION, DBO.FN_GET_DETAILS_BY_USERID( REFERID , 'CITY')CITY ";
            sQry = sQry + " FROM DBO.REGISTRION_DETAILS_VIEW V WHERE USERID NOT IN (SELECT USERID FROM TBL_EMAIL_SENT_LOG WHERE PURPOSE = 'LIVE LINK') ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }

    public DataTable getEventDetails()
    {
        string sSQry = "select * from TBL_EVENTS_MASTER";
        return GetDataTable(sSQry, true);
    }

    public DataTable getEventReports(string sEventID, string sCriteria)
    {
        //string Sqry = "USP_EVENT_REPORTS'" + sEventID + "','" + sCriteria + "'";
        //return GetDataTable(Sqry, true);


        string[] strArrList = { "@EVENT_ID", "@CRITERIA" };
        string[] strArrValues = { sEventID, sCriteria };
        DataTable dt = fnRunProcedureDatatable("USP_EVENT_REPORTS", strArrList, strArrValues, true);

        return dt;
    }

    public DataTable GetAdMasterData()
    {
        // string sSQry = "select * from TBL_ADS_USER_LIKES order by LIKED_DT desc";
        string sSQry = "select sms.Mid,sms.merchant_product_id productid,sum(CASE WHEN (likes.PURPOSE='CPM') THEN  1 ELSE 0 END) Totalcpm,";
        sSQry += "sum(CASE WHEN (likes.PURPOSE='CPS') THEN  1 ELSE 0 END) Totalcps,";
        sSQry += "sum(CASE WHEN (likes.PURPOSE='CPC') THEN  1 ELSE 0 END) Totalcpc,";
        sSQry += "sum(CASE WHEN (likes.REACH='CPM') THEN  1 ELSE 0 END) Reachcpm,";
        sSQry += "sum(CASE WHEN (likes.REACH='CPS') THEN  1 ELSE 0 END) Reachcps,";
        sSQry += "sum(CASE WHEN (likes.REACH='CPC') THEN  1 ELSE 0 END) Reachcpc ";
        sSQry += " from TBL_ADS_USER_LIKES likes ";
        sSQry += " join tbl_ads_smsproducts sms on sms.sno=likes.AD_SRL_NO ";
        sSQry += " group by sms.Mid,sms.merchant_product_id;";
        return GetDataTable(sSQry, true);
    }
    public DataTable GetRelatedDataInMail(string Selecteduserid)
    {
        try
        {
            string sQry = " select v.userid refid,v.name refname,v2.emailid emailid,v2.name name, v2.mobileno mobileno, ";
            sQry = sQry + " DBO.FN_GET_DETAILS_BY_USERID(v.userid, 'CITY') refcity,img.imagename refimage, DBO.FN_GET_DETAILS_BY_USERID(v.userid, 'OCCUPATION') refoccupation from ALL_MEMBERS_VIEW v ";
            sQry = sQry + " inner join  tbl_imagedetail img on v.userid = img.userid ";
            sQry = sQry + " inner join ALL_MEMBERS_VIEW v2 on v2.userid = '" + Selecteduserid + "'";
            sQry = sQry + " where v.userid in (select referalID from ALL_MEMBERS_VIEW where userid = '" + Selecteduserid + "') ";
            sQry += " AND v.USERID NOT IN (Select userid from TBL_USER_ADDITIONAL_INFO where IS_UNSUBSCRIBED = 1 )";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateApprovedDetailsForEvent(string eventid, string userid)
    {
        try
        {
            string sQry = "update TBL_EVENT_USER_DETAILS set Can_issue_pass = '1' where event_id = '" + eventid + "' and user_id = '" + userid + " '";
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public void UpdateSmsDetailsInMail(string Location, string eventid)
    {
        try
        {
            string sQry = "update TBL_EVENTS_MASTER set Event_Location_SMS = '" + Location + "' where event_id =" + eventid;
            int intRowAffect = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable GetPersonalDetails(string sUserID)
    {
        try
        {
            string sQry = " select DBO.FN_GET_DETAILS_BY_USERID( USERID , 'OCCUPATION') refoccupation, ";
                   sQry = sQry + " DBO.FN_GET_DETAILS_BY_USERID( USERID , 'CITY') ref_City, ";
                   sQry = sQry + " * from TBL_ACTIVE_USERS where USERID = '" + sUserID + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
 



}