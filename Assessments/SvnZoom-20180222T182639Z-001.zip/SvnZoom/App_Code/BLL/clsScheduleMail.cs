﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net.Mime;
using System.Net.Mail;
using System.IO;

/// <summary>
/// Summary description for clsScheduleMail
/// </summary>
public class clsScheduleMail 
{
    //static void clsScheduleMail1()
    //{
    //    // Write your send mail code here.
       

    //}
    public static int SendScheduleMail()
    {
        // Write your send mail code here.

        try
        {

            // Check if any mails to send
            clsbit2byte clsB2b = new clsbit2byte();
            DataTable dtToSendInvMailsCounter = clsB2b.GetCounterToSendInvitationMails();
            if (dtToSendInvMailsCounter.Rows.Count <= 0)
            {
                return 0;
            }
        

            // Getting the list mails to send
            DataTable dtMailsToSend = new DataTable();
            dtMailsToSend = clsB2b.GetUsersToSendInvitationMails();
            int iInvCtr = dtMailsToSend.Rows.Count;

            while (iInvCtr > 0)
            {
                // Send each mail one after another....
                mailsend(dtMailsToSend.Rows[iInvCtr - 1]["USERID"].ToString());
                iInvCtr--;
            }

            int retVal = 0;
            DataTable dtLatestCount = new DataTable();
            dtLatestCount = clsB2b.GetCounterToSendInvitationMails();
            if (dtLatestCount.Rows.Count > 0)
            {
                if(Convert.ToInt32(dtLatestCount.Rows[0]["CTR"])>0)
                retVal = 1;
            }

            return retVal;
        }
        catch (Exception)
        {
            home clsHome = new home();
            clsHome.UpdateSqlTrace("", "Schedule Sending Mails", "Error happend");
            return 1;
        }
    }
    //public static void SendScheduleMail()
    //{
    //    // Write your send mail code here.

    //    clsbit2byte clsB2b = new clsbit2byte();
    //    DataTable dtUsersToSendInvMails = clsB2b.GetUsersToSendInvitationMails();
    //    if (dtUsersToSendInvMails.Rows.Count <= 0)
    //    {
    //        //Added By SAVITRI
    //        //return;
    //        StopScheduler();
    //        //Added By SAVITRI
    //    }

    //    int iInvCtr = dtUsersToSendInvMails.Rows.Count;

    //    while (iInvCtr > 0)
    //    {
    //        mailsend(dtUsersToSendInvMails.Rows[iInvCtr-1]["USERID"].ToString());
    //        iInvCtr--;

    //    }

    //}

    //Added By SAVITRI
    private static void StopScheduler()
    {
        //throw new NotImplementedException();
    }
    //Added By SAVITRI

    private static void mailsend(string sUserid)
    {

        try
        {

            string sEmailSentLogTrace = "";

            clsbit2byte clsB2b = new clsbit2byte();

            DataTable dtUserDtls = new DataTable();
            dtUserDtls = clsB2b.GetUserDetalsForInvitationMail(sUserid);

            if (dtUserDtls.Rows.Count <= 0)
            {
                return;
            }


            EncryptDecryptQueryString objEncrypt = new EncryptDecryptQueryString();
            string sEncryptedUserID = objEncrypt.Encrypt(sUserid, "r0b1nr0y");
            sEncryptedUserID = sEncryptedUserID.Replace("+", "%2B");
            string ReferalID = dtUserDtls.Rows[0]["REFERALID"].ToString();
            string Refname = dtUserDtls.Rows[0]["REF_NAME"].ToString();
            string name = dtUserDtls.Rows[0]["NAME"].ToString();
            string userid = dtUserDtls.Rows[0]["USERID"].ToString();
            string email = dtUserDtls.Rows[0]["EMAILID"].ToString();

            DataTable dtemailtemp = new DataTable();
            string Template_id = "2";

            dtemailtemp = clsB2b.EmailTemplateDetails(ReferalID, Template_id);

            string occupation = dtemailtemp.Rows[0]["OCCUPATION"].ToString();
            string city = dtemailtemp.Rows[0]["CITYNAME"].ToString();
            string activatelink = dtemailtemp.Rows[0]["LINK"].ToString();
            string EmailBody = dtemailtemp.Rows[0]["BODY"].ToString();
            string title = dtemailtemp.Rows[0]["EMAIL_SUBJECT"].ToString();
            string RefImage = System.Web.Hosting.HostingEnvironment.MapPath("~/inner/Crop_Images/Usernetwork_pic/" + dtemailtemp.Rows[0]["IMAGENAME"].ToString());

            activatelink = activatelink + userid + "&refid=" + ReferalID;

            if (File.Exists(RefImage) == false)
            {
                RefImage = System.Web.Hosting.HostingEnvironment.MapPath("~/inner/images/Profile_Image/pplimg_samp.gif");
            }

            MailMessage mailMessage = new MailMessage();

            string plainBody = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>";//modified by vasu for mobile compatibility.
            plainBody = plainBody + "<html xmlns='http://www.w3.org/1999/xhtml'>";
            plainBody = plainBody + "<head lang='en'><meta charset='UTF-8'><title></title><link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600|Droid+Serif' type='text/css'></head>";
            plainBody = plainBody + "<body style='font-size:12px; background-color:#ececec;font-family: 'Open Sans', sans-serif; width: 620px;'>";
            plainBody = plainBody + "<div style='border: 1px solid rgba(194, 188, 210, 1);border-radius: 6px;width: 620px;'>";
            plainBody = plainBody + "<table width='600' border='0' cellspacing='0' cellpadding='0' class='full-width' bgcolor='#ffffff' style='background-color:#ffffff;padding:0 10px;border-bottom: 2px solid #c7c7c7;border-radius: 5px 5px 0px 0px;'>";
            plainBody = plainBody + "<tbody><tr><td valign='top' width='100%'><table width='600' align='center' border='0' cellspacing='0' cellpadding='0' class='container' style='background-color:#ffffff;'></table>";
            plainBody = plainBody + "</td></tr><tr><td height='5'></td></tr><tr><td>";
            plainBody = plainBody + "<table width='405' border='0' cellspacing='0' cellpadding='0' align='left' style='margin-top: 10px;margin-left: 19px;'><tbody>";
            plainBody = plainBody + "<tr><td valign='top'><table border='0' cellspacing='0' cellpadding='0' align='left'><tbody><tr><td style='font-size: 18px; line-height: 22px; font-family: 'Open Sans' ,sans-serif; color:#555555; font-weight:bold; text-align:left;'>";
            plainBody = plainBody + "<span style='color: #555555; font-weight: bold;'><a href='#' style='text-decoration: none; color: #555555; font-weight: bold;'>" + title + "</a></span>";
            plainBody = plainBody + "</td></tr></tbody></table></td></tr></tbody></table>";
            plainBody = plainBody + "<table width='120' border='0' cellspacing='0' cellpadding='0' align='right' style='margin-top: 10px;'><tbody><tr><td valign='bottom'>";
            plainBody = plainBody + "<table width='100%' border='0' cellspacing='0' cellpadding='0' align='left'><tbody><tr><td valign='bottom' align='right'><a href='#'>";
            plainBody = plainBody + "<img src='https://ci5.googleusercontent.com/proxy/j2n1ZeL3Aog8pB2lPgmdyYiuuqG2n7ke1n0E_PE35POEMEfiLeI4R92Ngik4ggA2y5Zbr_IScmFtDNEL=s0-d-e1-ft#http://www.mfloat.in/images/mflogo.png' width='80' height='23'>";
            plainBody = plainBody + "</a></td></tr></tbody></table></td></tr><tr><td height='20'></td></tr></tbody></table></td></tr></tbody></table>";
            plainBody = plainBody + "<table width='600' border='0' cellspacing='0' cellpadding='0' class='full-width' style='padding:0 10px;'><tbody><tr><td height='10'></td>";
            plainBody = plainBody + "</tr></tbody></table><table width='600' border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff' style='background-color:#ffffff;padding:0 10px;'>";
            plainBody = plainBody + "<tbody><tr><td height='20'></td></tr><tr><td valign='top; width='100%'><table width='600' border='0' cellspacing='0' cellpadding='0' align='left'>";
            plainBody = plainBody + "<tbody><tr><td valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' align='left'><tbody><tr><td>";
            plainBody = plainBody + "<table width='85' border='0' cellspacing='0' cellpadding='0' align='left'><tbody><tr><td valign='top'>";
            plainBody = plainBody + "<table width='100%' border='0' cellspacing='0' cellpadding='0' align='left'><tbody><tr><td valign='top' align='center'>";


            string imagebody = "<a href='#'><img id='img_Refimg' src=cid:Refimg alt='Referal Image' style='display:block; max-width:65px; max-height:65px; border-radius: 100%;' border='0' hspace='0' vspace='0'>";
            imagebody = imagebody + "</a></td></tr></tbody></table></td></tr><tr><td height='10'></td></tr></tbody></table><table width='3' border='0' cellspacing='0' cellpadding='0' align='left'>";
            imagebody = imagebody + "<tbody><tr><td valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' align='left'><tbody><tr></tr></tbody></table>";
            imagebody = imagebody + "</td></tr><tr><td height='10'></td></tr></tbody></table><table width='300' border='0' cellspacing='0' cellpadding='0' align='left'>";
            imagebody = imagebody + "<tbody><tr><td valign='middle'><table border='0' cellspacing='0' cellpadding='0' align='left'><tbody><tr>";
            imagebody = imagebody + "<td style='font-size: 14px; line-height: 22px; font-family: 'Open Sans' ,sans-serif; color:#555555; font-weight:bold; text-align:left;'>";
            imagebody = imagebody + "<p style='color: #555555; font-weight: bold;line-height: 20px;margin-top: 6px;margin-bottom: 0;'>" + Refname + "</p>";
            imagebody = imagebody + "<p style='color: #555555; font-weight: bold;margin-top:0;margin-bottom: 0;font-size: 11px;line-height: 11px;margin-left: 5px;'>" + occupation;
            imagebody = imagebody + "</p><p style='color: #555555; font-weight: bold;margin-top:0;margin-bottom: 0;font-size: 11px;margin-left: 5px;line-height: 11px;'><span>" + city + "</span>";
            imagebody = imagebody + "</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>";
            imagebody = imagebody + "<table width='500' border='0' cellspacing='0' cellpadding='0' style='margin-left: 84px;'><tbody>";
            imagebody = imagebody + "<tr><td style='font-size: 15px; line-height: 22px; font-family: 'Open Sans' ,sans-serif; color:#555555; font-weight:bold; text-align:left;'>";
            imagebody = imagebody + "<span style='color: #555555; font-weight: bold;'><span style='text-decoration: none; color: #555555; font-weight: bold;'>Dear &nbsp;" + name + ",</span></span>";
            imagebody = imagebody + "</td></tr><tr><td valign='top'>";
            imagebody = imagebody + "<table border='0' cellspacing='0' cellpadding='0' align='left' style='background-position: 100% 65%;background-repeat: no-repeat; margin-right: 12px;'>";
            imagebody = imagebody + "<tbody><tr><td style='font-size: 18px; line-height: 22px; font-family: 'Open Sans' ,sans-serif; color:#555555; font-weight:bold; text-align: justify;text-justify: inter-word;'>";
            imagebody = imagebody + "<span style='color: #555555; font-weight: bold;'></span></td></tr><tr><td height='15'></td></tr><tr>";
            imagebody = imagebody + "<td style='font-size: 13px; line-height: 19px; font-family:Arial,Tahoma, Helvetica, sans-serif; color: #000000; font-weight:normal; text-align: justify; '>" + EmailBody;
            imagebody = imagebody + "<p style='text-align: center;'>For more details please activate</p></td></tr><tr><td height='15'></td></tr>";
            imagebody = imagebody + "<tr><td><table border='0' cellspacing='0' cellpadding='0' style='width:111px; margin:0 auto;'><tbody><tr>";
            imagebody = imagebody + "<td width='auto' align='center' valign='middle' height='32' style=' background-color:#ff6305;  border-radius:3px; background-clip: padding-box;font-size:13px; font-family: Arial,Tahoma, Helvetica, sans-serif; text-align:center;  color:#ffffff; font-weight: normal; padding-left:18px; padding-right:18px; '>";
            imagebody = imagebody + "<span style='color: #ffffff; font-weight: normal;'><a href='" + activatelink + "' style='text-decoration: none; color: #ffffff; font-weight: normal;'>Activate now</a></span>";
            imagebody = imagebody + "</td></tr></tbody></table></td></tr><tr><td height='20'></td></tr></tbody></table></td></tr></tbody></table>";
            imagebody = imagebody + "</td></tr><tr><td> <table width='600' align='center' border='0' cellspacing='0' cellpadding='0'style='background-color:#ffffff;'> <tbody><tr> <td valign='top' align='center' style='background-color:#ffffff;'> <a href='#'> <img id='img_shadow' src=cid:shadow class='image-100-percent' height='9' alt='Divider' style='display:block; max-height:6px; ' border='0' hspace='0' vspace='0'> </a> </td> </tr> </tbody></table> </td></tr>";
            imagebody = imagebody + "</tbody></table><table width='600' border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff' style='background-color:#ffffff;padding:0 10px;border-radius: 0 0 5px 5px;margin-top: 10px;text-align: center;font-size: 11px;border-top: 2px solid rgba(199, 199, 199, 0.47);'>";
            imagebody = imagebody + "<tbody><tr><td valign='top' width='100%'><table width='600' align='center' border='0' cellspacing='0' cellpadding='0' class='container' style='background-color:#ffffff;'>";
            imagebody = imagebody + "</table></td></tr><tr><td height='5'></td></tr><tr><td><table width='600' border='0' cellspacing='0' cellpadding='0' align='left' class='full-width' style='margin-top: 10px;'>";
            imagebody = imagebody + "<tbody><tr><td valign='top'><table border='0' cellspacing='0' cellpadding='0' align='center'><tbody style='width: 100%;'><tr>";
            imagebody = imagebody + "<td style='font-size: 10px; line-height: 14px; font-family: 'Open Sans' ,sans-serif; color:#555555; font-weight:bold; text-align: center;width: 100%;'>";
            imagebody = imagebody + "<span style='color: #555555; font-weight: 400;'><p style='text-decoration: none; color: #555555; font-weight: bold;margin-bottom: 0px;'>This message was sent to <span><a href='#' target='_blank'>" + email + "</a></span> because " + Refname + " added you as close friend in <a href='http://mfloat.in' target='_blank'>mfloat.in</a></p>";
            imagebody = imagebody + "<p style='margin-bottom:0px;margin-top:0px'>If you don't want to receive these emails from <a href='http://www.mfloat.in' target='_blank'>mfloat.in</a> in future, please <a href='http://www.mfloat.in/Default.aspx?act=unsubscribe&status=" + sEncryptedUserID + "' style='text-decoration:blink;font-weight:bold;font-size:11px' target='_blank'>unsubscribe</a>.</p>";
            imagebody = imagebody + "</span></td></tr></tbody></table></td></tr></tbody></table></td></tr><tr style=''><td style='padding-bottom: 10px;'><div style='margin-top: 10px;'>";
            imagebody = imagebody + "<span style='float:right;font-size: 12px;font-family:'Open Sans', sans-serif; margin-top:2px;margin-right:0px;color:Black'>Float Technologies Pvt. Ltd., Hyderabad</span>";
            imagebody = imagebody + "</div></td></tr></tbody></table></div></body></html>";

            System.Net.Mail.AlternateView htmlView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(plainBody + imagebody, null, "text/html");
            System.Net.Mail.AlternateView plainView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(plainBody, null, "text/plain");
            System.Net.Mail.LinkedResource AddpostImage = new System.Net.Mail.LinkedResource(RefImage, "image/jpg");
            AddpostImage.ContentId = "Refimg";
            System.Net.Mail.LinkedResource AddshadowImage = new System.Net.Mail.LinkedResource(System.Web.Hosting.HostingEnvironment.MapPath("~/inner/images/icons/shadow.png"), "image/png");
            AddshadowImage.ContentId = "shadow";
            AddpostImage.TransferEncoding = TransferEncoding.Base64;
            AddshadowImage.TransferEncoding = TransferEncoding.Base64;
            htmlView.LinkedResources.Add(AddpostImage);
            htmlView.LinkedResources.Add(AddshadowImage);
            mailMessage.AlternateViews.Add(plainView);
            mailMessage.AlternateViews.Add(htmlView);

            SendMailFile objMail = new SendMailFile();
            objMail.SendMailHTMLOutput("info@mfloat.in", email.ToString().Trim(), "Message From " + Refname, mailMessage);
            mailMessage.Dispose();

            // this block of code modified by Sudhindra on 13-Feb-2015. Purpose : updating the email sent log for resending mails
            home clsHome = new home();
            string sPurpose = "Invitation Mail";
            //DataTable dtCheckMailSentLog = clsHome.CheckMailSentLog(userid, "Invitation Mail");
            //if (dtCheckMailSentLog.Rows.Count > 0)
            //{
            //    sPurpose = "Invitation Mail - Resend";
            //}

            sEmailSentLogTrace = "Referal ID : " + ReferalID + ";Referal Name : " + Refname + ";Referal Occupation : " + occupation + ";Referal City : " + city;
            sEmailSentLogTrace = sEmailSentLogTrace + ";User Name : " + name + ";Activation Link : " + activatelink;


            //clsHome.UpdateEmailSentLog(sPurpose, userid, email, plainBody + imagebody);
            clsHome.UpdateEmailSentLog(sPurpose, userid, email, sEmailSentLogTrace);

            //clsHome.UpdateMailSentFlag(email.ToString(), ReferalID);
            clsHome.UpdateInvitationMailSentFlag(userid);

            //General clsGen = new General();
            //clsGen.UpdateUserInvitationLuckDraw(userid);

        }
        catch (Exception ex)
        {
            //ExceptionLogging exceptionLogObject = new ExceptionLogging();
            //exceptionLogObject.LogExceptions(HttpContext.Current.Request.Url.AbsolutePath, "Error while sending the mail from create page " + ex.Message + "--" + (ex.StackTrace != null ? ex.StackTrace.ToString() : ""), System.Reflection.MethodBase.GetCurrentMethod().Name, HttpContext.Current.User.Identity.Name);
        }

    }







}
