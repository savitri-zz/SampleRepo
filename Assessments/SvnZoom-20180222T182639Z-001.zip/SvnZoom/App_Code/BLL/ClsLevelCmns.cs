﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ClsLevelCmns
/// </summary>
public class ClsLevelCmns:BaseClass
{
	public ClsLevelCmns()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetLevelComission()
    {
        try
        {
            string SQLQuery = "select * from  tbl_LevelCommission order by CAST(Levelno as int) ASC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetInviteddatadetails2(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user = '" + userid + "' order by sno ASC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getreferedname1(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void DeleteLevelCmns1()
    {
        try
        {
            //string SQLQuery = "delete from tbl_LevelCommission";
            string SQLQuery = "USP_DeleteLevelCmns1";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable BindLevelCmns(string TableName, string ColumnName, string sponcerID)
    {
        try
        {
            string SQLQuery = "select * from  " + TableName + " where " + ColumnName + "='" + sponcerID + "' order by sno asc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable BindLevelCmnsSNO(string TableName, string ColumnName, string SNO)
    {
        try
        {
            string SQLQuery = "select * from  " + TableName + " where " + ColumnName + ">'" + SNO + "' order by sno asc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertLevelCmns(string userid, string Name, string Mobileno, string Levelno, string SId, string Percentage, string Data, string DOJ, string SearchUserid)
    {
        try
        {
            //string SQLQuery = "insert into tbl_LevelCommission (userid,Name,Mobileno,Levelno,SId,Percentage,Data,DOJ,SearchUserid) values('" + userid + "','" + Name + "','" + Mobileno + "','" + Levelno + "','" + SId + "','" + Percentage + "','" + Data + "','" + DOJ + "','" + SearchUserid + "')";
            string SQLQuery = "USP_InsertLevelCmns   '" + userid + "', '" + Name + "', '" + Mobileno + "', '" + Levelno + "','" + SId+ "'.'"+ Percentage +"','"+ Data +"','"+ DOJ +"','"+ SearchUserid +"',";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

}