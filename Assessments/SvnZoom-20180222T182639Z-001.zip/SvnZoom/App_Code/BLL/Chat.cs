﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for Chat
/// </summary>
public class Chat : BaseClass
{
    public Chat()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public void InsertChat(string ChatID, string FromUID, string ToUID, string ChatMEssage)
    {
        try
        {
            string SQLQuery = "insert into tbl_chat_log(CHATID,FROM_USERID,TO_USERID,CHAT_MESSAGE)";
            SQLQuery += " values ('" + ChatID + "','" + FromUID + "', '" + ToUID + "', '" + ChatMEssage + "')";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetFullChat(string FromUID, string ToUID)
    {
        try
        {
            string SQry = "EXEC GETFULLCHAT '" + FromUID + "' ,'" + ToUID + "'";
            return GetDataTable(SQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetUnreadMessages(string FromUID, string ToUID)
    {
        try
        {
            string SQry = "exec Get_unread_message '" + FromUID + "' ,'" + ToUID + "'";
            return GetDataTable(SQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void UpdateReadStatus(string ToUID, string FromUID)
    {
        try
        {
            string SQLQuery = "UPDATE TBL_CHAT_LOG SET IS_FETCHED=1,IS_READ=1 WHERE TO_USERID='" + ToUID + "' and FROM_USERID='" + FromUID + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }
    public DataTable GetNoOfUnreadMessages(string FromUID, string ToUID)
    {
        try
        {
            string SQry = "SELECT COUNT(*) NO_OF_UNREAD_MESSAGES FROM TBL_CHAT_LOG WHERE FROM_USERID='" + FromUID + "' AND TO_USERID='" + ToUID + "'";
            SQry += " AND IS_READ=0";
            return GetDataTable(SQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetLoggedUsers_By_ReferalID(string RefID)
    {
        try
        {

            this.UpdateChatFlag();

            string SQry = "SELECT * FROM TBL_ACTIVE_USERS WHERE REFERAL_ID = '" + RefID + "' ";
            SQry += " UNION";
            SQry += " SELECT * FROM TBL_ACTIVE_USERS WHERE USERID = (SELECT REFERAL_ID FROM TBL_ACTIVE_USERS  WHERE USERID = '" + RefID + "' ";
            SQry += " ) order by IS_AVAILABLE_FOR_CHAT desc ";



            //string SQry = "SELECT * FROM TBL_ACTIVE_USERS WHERE REFERAL_ID = '" + RefID + "' AND IS_AVAILABLE_FOR_CHAT  = 1";
            //SQry += " UNION";
            //SQry += " SELECT * FROM TBL_ACTIVE_USERS WHERE USERID = (SELECT REFERAL_ID FROM TBL_ACTIVE_USERS  WHERE USERID = '" + RefID + "' ";
            //SQry += " AND IS_AVAILABLE_FOR_CHAT  = 1) AND IS_AVAILABLE_FOR_CHAT  = 1";


            return GetDataTable(SQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateChatFlag()
    {
        try 
	    {	        
		    string sQry = "UPDATE TBL_ACTIVE_USERS SET IS_AVAILABLE_FOR_CHAT = 0 ";
            sQry = sQry + " WHERE USERID NOT IN (SELECT USERID FROM TBL_USER_LOGIN_LOGOUT_TIMES WHERE DATEDIFF(MINUTE, LOGIN_TIME , GETDATE()) < 60)";
            sQry = sQry + " AND IS_AVAILABLE_FOR_CHAT = 1";

            int intRowAffect = fnExecuteNonQuery(sQry, true);

	    }
	    catch (Exception ex)
	    {
		
		    throw ex;
	    }
    }
}