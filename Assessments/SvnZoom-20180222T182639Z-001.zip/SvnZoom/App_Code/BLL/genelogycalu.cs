﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Class1
/// </summary>
public class genelogycalu : BaseClass
{
    public genelogycalu()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable getparentnodes(string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getparentsunnodes(string parentid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where placementid = '" + parentid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getproductBVsum(string productid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Products where sno = '" + productid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getreferalid_Referalondate(string referid, string date)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where referid = '" + referid + "' and CAST(joindate as DATE) =  '" + date + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getreferalid(string referid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where referid = '" + referid + "' order by sno desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable getreferalid_binary(string referid, string date)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where referid = '" + referid + "' and CAST(joindate as DATE) =  '" + date + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable getreferalid_binary123(string referid, string date)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where referid = '" + referid + "' and CAST(joindate as DATE) <=  '" + date + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getreferalid_binary234(string referid, string date, string date1)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where referid = '" + referid + "' and CAST(joindate as DATE) between  '" + date + "' and '" + date1 + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


}