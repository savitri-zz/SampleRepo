﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for EntryForm
/// </summary>
public class EntryForm:BaseClass
{
	public EntryForm()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public void deleteid(string uid)
    {
        try
        {
            string query = "delete tbl_Entrypass where sno='" + uid + "'";
            int intRowAffect = fnExecuteNonQuery(query, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public void InsertclsEntrypass(string userid, string mobileno, string name, string emailid, string nofInvitees, string date,string rate)
    {
        try
        {
            string SQLQuery = "insert into tbl_Entrypass(userid, mobileno,name,emailid,nofInvitees,date,Rate) values ('" + userid + "','" + mobileno + "','" + name + "','" + emailid + "','" + nofInvitees + "','" + date + "','" + rate + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getdata(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Entrypass where userid ='" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable Getmemregistrationsponceruserid(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno = '" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getfreememregistrationsponceruserid(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where mobileno = '" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getMobileNumbersFree(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable getdatetimeFree(string userid)
    {
        try
        {
            string SQLQuery = "select convert( varchar(30), cast(joindate as datetime) , 106) as doj from tbl_freememreg where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getMobileNumbers(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable getdatetime(string userid)
    {
        try
        {
            string SQLQuery = "select convert( varchar(30), cast(joindate as datetime) , 106) as doj from tbl_registration where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable GetProductsDetails(string sno)
    {
        try
        {
            string SQLQuery = "select sno,Code,Product_name,QTY,cost,Round(tax,0) as tax,total,ROUND(mrp,0) as mrp from tbl_Products where sno = '" + sno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getusername(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
 

    public DataTable Getwalletstatus(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Userwalletstatus where useid = '" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable Getnoofinvities(string uid)
    {
        try
        {
            string SQLQuery = "select Sum(cast(nofInvitees as int)) as tot  from tbl_Entrypass where userid ='" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable GetTotalnoofinvities()
    {
        try
        {
            string SQLQuery = "select Sum(cast(nofInvitees as int)) as total  from tbl_Entrypass";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
}