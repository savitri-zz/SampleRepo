﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for updatebankdetail
/// </summary>
public class updatebankdetail:BaseClass 
{
	public updatebankdetail()
	{
		//
		// TODO: Add constructor logic here
		//
	}



    public DataTable checkstatus(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where  userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable checkstatusWallet(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_userwallet where  userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable statuschanged(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where  userid='" + userid + "' and status= '1'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable retrievedata(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where  userid='" + userid + "' and status= '1'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable passwordenter(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where  userid='" + userid + "' and status= '0'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable passwordcheck(string password, string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where  password='" + password + "' and userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertverifycode(string Payeename, string AccountNo, string BankName, string BranchName, string IFSCcode, string PANNo, string mobileno, string emailid, string status, string userid, string usertype, string password, string verifycode)
    {
        try
        {
            string SQLQuery = "insert into tbl_updatebankdetails (Payeename,AccountNo, BankName, BranchName, IFSCcode, PANNo,mobileno,emailid,status,userid,usertype,password,Date,verifycode) values ('" + Payeename + "','" + AccountNo + "', '" + BankName + "','" + BranchName + "','" + IFSCcode + "','" + PANNo + "','" + mobileno + "','" + emailid + "','" + status + "','" + userid + "','" + usertype + "','" + password + "','" + DateTime.Now.ToString() + "','" + verifycode + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updatepassword(string password,string userid)
    {
        try
        {

            string SQLQuery = "update tbl_updatebankdetails set password='" + password + "', status = '0' where userid = '" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatedetail(string Payeename1, string AccountNo1, string BankName1, string BranchName1, string IFSCcode1, string PANNo1, string userid1)
    {
        try
        {

            string SQLQuery = "update tbl_updatebankdetails set Payeename='" + Payeename1 + "', AccountNo='" + AccountNo1 + "', BankName='" + BankName1 + "', BranchName='" + BranchName1 + "', IFSCcode='" + IFSCcode1 + "', PANNo='" + PANNo1 + "', status = '1' where mobileno = '" + userid1 + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

     public void InsertDetails(string Payeename,string AccountNo,string BankName,string BranchName,string IFSCcode,string PANNo,string mobileno,string emailid,string status,string userid,string usertype,string password,string Date,string verifycode)
    {
        try
        {

            string SQLQuery = "INSERT INTO tbl_updatebankdetails(Payeename,AccountNo,BankName,BranchName,IFSCcode,PANNo,mobileno,emailid,status,userid,usertype,password,Date,verifycode)VALUES('" + Payeename + "','" + AccountNo + "','" + BankName + "','" + BranchName + "','" + IFSCcode + "','" + PANNo + "','" + mobileno + "','" + emailid + "','" + status + "','" + userid + "','" + usertype + "','" + password + "','" + Date + "','" + verifycode + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    

    public DataTable checkverify(string verify)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where  verifycode='" + verify + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable statuscheck(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where  userid='" + userid + "' and status= '1'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable verifysecond(string userid, string verify)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where  verifycode='" + verify + "' and userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
       
    }

    public DataTable getnamedetails(string userid)
    {
        try
        {
            string SQLQuery = "select UPPER(fullname) AS fullname from tbl_registration where  userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable getpandetails(string PANNo)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails   where PANNo='" + PANNo + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable getaccountdetails(string acno)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails   where AccountNo='" + acno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
 public DataTable getatatus(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails   where userid='" + uid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
}