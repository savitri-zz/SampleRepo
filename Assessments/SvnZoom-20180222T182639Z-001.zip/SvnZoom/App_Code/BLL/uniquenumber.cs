﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


/// <summary>
/// Summary description for uniquenumber
/// </summary>
public class uniquenumber
{
	public uniquenumber()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string digspin16()
    {
        string random = "";
        System.Random fiveRandom = new Random();
        TimeSpan tsFive = new TimeSpan();
        tsFive = DateTime.Now.Subtract(Convert.ToDateTime("01/01/1900"));
        //random = fiveRandom.Next(10000, 99999) + tsFive.Days.ToString() + System.DateTime.Now.Hour.ToString("00") + System.DateTime.Now.Minute.ToString("00") + System.DateTime.Now.Second.ToString("00");
        random = fiveRandom.Next(10000, 99999) + tsFive.Days.ToString().Substring(3,2) + System.DateTime.Now.Hour.ToString("00") + System.DateTime.Now.Minute.ToString("00") + System.DateTime.Now.Second.ToString("00") + System.DateTime.Now.Millisecond.ToString("000");
        return random;
      
    }

    public string transactionid()
    {
        string random1 = "";
        System.Random fiveRandom1 = new Random();
        TimeSpan tsFive1 = new TimeSpan();
        tsFive1 = DateTime.Now.Subtract(Convert.ToDateTime("01/01/1900"));
        random1 = fiveRandom1.Next(1000, 9999) + tsFive1.Days.ToString() + System.DateTime.Now.Hour.ToString("00") + System.DateTime.Now.Minute.ToString("00") + System.DateTime.Now.Second.ToString("00");
        return random1;
    }
}