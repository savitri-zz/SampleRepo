﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


/// <summary>
/// Summary description for bit2byteevent
/// </summary>
public class bit2byteevent : BaseClass
{
	public bit2byteevent()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable Zgetpaidcorrect(string userid)
    {
        try
        {
            string sqlquery = "Select * from tbl_registration where userid= '" + userid + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Zgetpaidcorrect1(string mobile)
    {
        try
        {
            string sqlquery = "Select * from tbl_registration where mobileno= '" + mobile + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Zexistpass()
    {
        try
        {
            string sqlquery = "Select * from tbl_eventpaid  order by sno desc";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Zexistpassmember()
    {
        try
        {
            string sqlquery = "Select * from tbl_eventmember where passno is not null   order by sno desc";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Zenterfirstpass(string passno, string name, string mobileno, string userid, string date)
    {
        try
        {

          /*  string SQLQuery = "insert into tbl_eventpaid(passno, name, mobileno,userid,date) values ('" + passno + "', '" + name + "', '" + mobileno + "', '" + userid + "','" + date + "')";*/

            string SQLQuery="USP_Bite2Byte_enterfirstpass   '" + passno + "', '" + name + "', '" + mobileno + "', '" + userid + "','" + date + "'";


            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Zpaidexist(string mobile)
    {
        try
        {
            string sqlquery = "Select * from tbl_eventpaid  where mobileno='" + mobile + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public string verifyCodeGenerator(int codeCount)
    {
        string allChar = "0,1,2,3,4,5,6,7,8,9,8,7,6,5,4,3,2,1,0";
        string[] allCharArray = allChar.Split(',');
        string randomCode = "";
        int temp = -1;

        Random rand = new Random();
        for (int i = 0; i < codeCount; i++)
        {
            if (temp != -1)
            {
                rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = rand.Next(19);
            if (temp != -1 && temp == t)
            {
                return verifyCodeGenerator(codeCount);
            }
            temp = t;
            randomCode += allCharArray[t];
        }
        return randomCode;
    }

    public void Zinsertmember( string name, string mbolieno, string invitembl, string inviteuserid,string inviteename,string date,string verifycode,string emailid)
    {
        try
        {
           /* string SQLQuery = "insert into tbl_eventmember(name, mboileno,inviteembl,inviteeuserid,inviteename,date,verifycode,emailid) values ('" + name + "', '" + mbolieno + "', '" + invitembl + "','" + inviteuserid + "','" + inviteename + "', '" + date + "','" + verifycode + "','" + emailid + "')";*/

            string SQLQuery = "USP_Bite2Byte_insertmember  '" + name + "', '" + mbolieno + "', '" + invitembl + "','" + inviteuserid + "','" + inviteename + "', '" + date + "','" + verifycode + "','" + emailid + "'";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Zcheckverifycode(string verifycode, string mbl, string datetim)
    {
        try
        {
            string sqlquery = "Select * from tbl_eventmember  where mboileno='" + mbl + "' and verifycode='" + verifycode + "' and date='" + datetim + "' ";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Zupdatepass(string passno, string mobile, string verifycode)
    {
        try
        {
           /* string SQLQuery = "update tbl_eventmember set passno = '" + passno + "' where mboileno = '" + mobile + "' and verifycode='" + verifycode + "' ";*/
            string SQLQuery = "USP_Bite2Byte_updatepass '" + passno + "','" + mobile + "','" + verifycode + "' ";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Zmembercheck(string mobile)
    {

        try
        {
            string sqlquery = "Select * from tbl_eventmember  where mboileno='" + mobile + "' and passno is not null";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}