﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for Calculations
/// </summary>
public class Calculations
{
	public Calculations()
	{
		
	}

    public DataTable GetDataTable(string strSQL, bool IsMasterDB)
    {
        try
        {
            DataSet ObjDs = new DataSet();
            ObjDs = SqlHelper.ExecuteDataset(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL);
            return ObjDs.Tables[0];
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable calculate(string userid)
    {
        try
        {
            string SQLQuery = "select sno,mobileno,(select count(*) FROM tbl_registration WHERE referid=sc.sno) childnodecount FROM tbl_registration sc where referid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}