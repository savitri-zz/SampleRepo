﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for clsadminpingenert
/// </summary>
public class clsadminpingenert :BaseClass
{
	public clsadminpingenert()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public void insertadminpin_generate(string mobileno, string name, string emailid, string Amount, string generate_date, string modeofpayment, string bankname, string chkno,string generate_userid, string ddno ,string pincode_generate, string status, string accountno, string accounttype)
    {
        try
        {

            //string SQLQuery = "insert into tbl_admingenerate_pin (mobileno,name,emailid, Amount, generate_date, Modeofpayment, bankname, checkno,userid, ddno,pincode_generate,status,accountno,accounttype) values ('" + mobileno + "','" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "', '" + modeofpayment + "','" + bankname + "','" + chkno + "', '" + generate_userid + "', '" + ddno + "','" + pincode_generate + "','" + status + "','" + accountno + "','" + accounttype + "')";
            string SQLQuery = "USP_insertadminpin_generate '" + mobileno + "','" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "', '" + modeofpayment + "','" + bankname + "','" + chkno + "', '" + generate_userid + "', '" + ddno + "','" + pincode_generate + "','" + status + "','" + accountno + "','" + accounttype + "'";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getpindlrdata()
    {
        try
        {
            string sqlquery = "select * from tbl_pindealerregistration order by id desc";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

    }

    public DataTable displaypingrouptext()
    {
        try
        {
            string SQLQuery = "select * from tbl_admingenerate_pin order by pin_generate_id desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable bussinessuserexists1(string mobileno, string emailid, string accountno)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration where MobileNo ='" + mobileno + "' and Emailid = '" + emailid + "' and account_no='" + accountno + "' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatemempin_generate(string mobileno)
    {
        try
        {

            string SQLQuery = "update tbl_pindealerregistration set status = '1' where MobileNo = '" + mobileno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getvalue(string accountno)
    {
        try
        {
            string sqlquery = "Select * from tbl_pindealerregistration where account_no='" + accountno + "'";
            return GetDataTable(sqlquery, true);

        }
        catch(Exception Ex)
        {
            throw Ex;

        }
    }

    public DataTable Zforgotuser(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration  where MobileNo = '" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }

    }
    public DataTable Zgetvaluedlrpin(string mobileno)
    {
        try
        {
            string sqlquery = "Select * from tbl_delrpintransfer where mobile='" + mobileno + "'";
            return GetDataTable(sqlquery, true);

        }
        catch (Exception Ex)
        {
            throw Ex;

        }
    }
}