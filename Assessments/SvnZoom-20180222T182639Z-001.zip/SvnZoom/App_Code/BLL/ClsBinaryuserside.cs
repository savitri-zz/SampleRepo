﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for ClsBinaryuserside
/// </summary>
public class ClsBinaryuserside:BaseClass
{
	public ClsBinaryuserside()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetBinaryPayoutCVDetails(string userid, string PayoutDate)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_BinaryCV_Calc1 where userid='" + userid + "' and PayoutDate = '" + PayoutDate + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryPayoutDetails(string strUserid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Binarypayoutdetails where userid = '" + strUserid + "' and BeforeDeductionNetAmt <> '0' order by cast(PayoutDate as date) desc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryPayoutAmount(string strUserid)
    {
        try
        {
            string SQLQuery = "select isnull(sum(CAST(BeforeDeductionNetAmt as float)),0)as BeforeDeductionNetAmt from tbl_Binarypayoutdetails where userid='" + strUserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
}