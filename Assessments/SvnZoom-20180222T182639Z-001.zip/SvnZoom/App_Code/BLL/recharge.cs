﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
/// <summary>
/// Summary description for recharge
/// </summary>
public class recharge:BaseClass
{
	public recharge()
	{
		//
		// TODO: Add constructor logic here
		//
	}




    public DataTable Getoprtor()
    {
        try
        {
            string SQLQuery = "select * from tbl_operator";
             return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getcircle()
    {
        try
        {
            string SQLQuery = "select * from tbl_circle";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getamount(string account_no)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration where account_no = '" + account_no + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable UserExists(string mobileno)
    {
        try
        {            
            string SQLQuery = "select * from tbl_registration where  userid='" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getfuserid1(string userid)
    {
        try
        {            
            string SQLQuery = "select * from tbl_freememreg where  userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getamount3(string userid)
    {
        try
        {
            string SQLQuery = "select tbl_registration.emailid as emailid, tbl_registration.mobileno as mobileno, tbl_registration.fullname as fullname, tbl_registration.userid as userid from tbl_registration, tbl_Datapayoutdetails  where tbl_registration.userid = tbl_Datapayoutdetails.userid  and tbl_registration.userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable checkpaiduserid1(string userid)
    {
        try
        {            
            string SQLQuery = "select * from tbl_Userwalletstatus where  useid='" + userid + "' and walletstatus='0' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getamountchuser(string userid)
    {
        try
        {
            string SQLQuery = "select tbl_registration.emailid as emailid, tbl_registration.mobileno as mobileno, tbl_registration.fullname as fullname, tbl_registration.userid as userid from tbl_registration, tbl_Binarypayoutdetails  where tbl_registration.userid = tbl_Binarypayoutdetails.userid  and tbl_registration.userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getamountchuser1(string userid)
    {
        try
        {
            string SQLQuery = "select tbl_registration.emailid as emailid, tbl_registration.mobileno as mobileno, tbl_registration.fullname as fullname, tbl_registration.userid as userid from tbl_registration, tbl_Referalpayoutdetails  where tbl_registration.userid = tbl_Referalpayoutdetails.userid  and tbl_registration.userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getSpotBonusAmount(string userid)
    {
        try
        {
            string SQLQuery = "select tbl_registration.emailid as emailid, tbl_registration.mobileno as mobileno, tbl_registration.fullname as fullname, tbl_registration.userid as userid from tbl_registration, tbl_Data_SpotBonusAmt  where tbl_registration.userid = tbl_Data_SpotBonusAmt.userid  and tbl_registration.userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable productwalletexpense(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(ROUND(amt,0) as int)) as amount from tbl_prduwalltused where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable delear_users(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as int)) as amount from tbl_delrpintransfer where dealerid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable delearamount(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(Amount as int)) as amount from tbl_admingenerate_pin where accountno = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public string verifyCodeGenerator(int codeCount)
    {
        string allChar = "0,1,2,3,4,5,6,7,8,9,8,7,6,5,4,3,2,1,0";
        string[] allCharArray = allChar.Split(',');
        string randomCode = "";
        int temp = -1;

        Random rand = new Random();
        for (int i = 0; i < codeCount; i++)
        {
            if (temp != -1)
            {
                rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = rand.Next(19);
            if (temp != -1 && temp == t)
            {
                return verifyCodeGenerator(codeCount);
            }
            temp = t;
            randomCode += allCharArray[t];
        }
        return randomCode;
    }

    public string Generattransactionno(int codeCount)
    {
        string allChar = "9,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9,7,8,6,5,4,3,2,1,9,3,5,6,7,9,0";
        string[] allCharArray = allChar.Split(',');
        string randomCode = "";
        int temp = -1;

        Random rand = new Random();
        for (int i = 0; i < codeCount; i++)
        {
            if (temp != -1)
            {
                rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
            }
            int t = rand.Next(19);
            if (temp != -1 && temp == t)
            {
                return Generattransactionno(codeCount);
            }
            temp = t;
            randomCode += allCharArray[t];
        }
        return randomCode;
    }


  
    public DataTable moneydeductpaid(string account)
    {
        try
        {
            string SQLQuery = "select * from tbl_pindealerregistration where account_no='" + account + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable partnrid(string auserid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid='" + auserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void quickpayTransactionDetail1(string umobile, string Uamount, string Ucircle, string Uoperator, string Daccount, string Uaccount, string Userid, string verificationcode, string generatedate)
    {
        try
        {

            string SQLQuery = "insert into tbl_rechargetransaction(umobile,uamount,ucircle,uoperator,Daccountno,Uaccountno,Userid,verificationcode,generatedate)values ('" + umobile + "','" + Uamount + "','" + Ucircle + "','" + Uoperator + "','" + Daccount + "','" + Uaccount + "','" + Userid + "','" + verificationcode + "','" + generatedate + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable user_amount(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as int)) as amount from tbl_userpin where accountno = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable delearuseramount(string accountno)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as int)) as amount from tbl_delrpintransfer where accountno = '" + accountno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable paidmemuser(string userid,string st,string st1,string st2,string st3)
    {
        try
        {
            string SQLQuery = "select password from tbl_userwallet where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable paidmemuser(string userid)
    {
        try
        {
            string SQLQuery = "select password from tbl_userwallet where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updatetickttransactiontable(string transid, string verify)
    {
        try
        {

            string SQLQuery = "update tbl_rechargetransaction set transactionid='" + transid.ToString() + "' where verificationcode='" + verify + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertusepw(string bit2byteuserid, string name, string emailid, string mobile, string amount, string transaction, string type)
    {
        try
        {

            string SQLQuery = "insert into tbl_prduwalltused (userid,name,emailid,mobile, amt,transactionid,description,date,type) values ('" + bit2byteuserid + "','" + name + "','" + emailid + "','" + mobile + "', '" + amount + "','" + transaction + "','To words Quick Pay','" + DateTime.Now.ToString() + "','" + type + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertusebw(string bit2byteuserid, string name, string mobile, string amount,string status)
    {
        try
        {

            string SQLQuery = "insert into tbl_BWTransferAmt (userid,name,mobileno,Tranferamt,date,Tranferdate,status) values ('" + bit2byteuserid + "','" + name + "','" + mobile + "', '" + amount + "','" + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertpin_delarpinuse(string mobileno, string userid, string name, string emailid, string Amount)
    {
        try
        {

            string SQLQuery = "insert into tbl_delrpintransfer (mobile,dealerid,name,emailid, amount,generatedate) values ('" + mobileno + "','" + userid + "','" + name + "','" + emailid + "', '" + Amount + "', '" + DateTime.Now.ToString() + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getamount2(string account_no)
    {
        try
        {
            string SQLQuery = "select * from tbl_delrpintransfer where accountno = '" + account_no + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable moneypaidfree(string account)
    {
        try
        {
            string SQLQuery = "select * from tbl_delrpintransfer where accountno='" + account + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable selectcircle(string circleid)
    {
        try
        {
            string SQLQuery = "select * from tbl_circle where CircleID='" + circleid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable selectoperator(string operatorid)
    {
        try
        {
            string SQLQuery = "select * from tbl_operator where OperatorID='" + operatorid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getpuserid(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where  userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getfuserid(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where  userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable checkpaiduserid(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_Userwalletstatus where  useid='" + userid + "' and walletstatus='0' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable walletdebitsamt(string auserid)
    {
        try
        {
            string SQLQuery = "  select sum( cast(debitedamt as float)) as amount from tbl_walletalltransaction where userid='" + auserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable BankDetails(string auserid)
    {
        try
        {
            string SQLQuery = "select * from tbl_updatebankdetails where userid='" + auserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable wallettransamt(string auserid)
    {
        try
        {
            string SQLQuery = "  select sum( cast(creditedamount as float)) as amount from tbl_walletalltransaction where userid='" + auserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable ProductWalletamt(string auserid)
    {
        try
        {
            string SQLQuery = "  select sum( cast(creditedamount as float))-sum( cast(debitedamt as float)) as amount from tbl_walletalltransactionproductwallet where userid='" + auserid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Insertbankwallettranscation(string userid, string mobileno, string debitedamt, string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_walletalltransaction (userid,mobileno,creditedamount,debitedamt,date,status) values ('" + userid + "','" + mobileno + "','','" + debitedamt + "','" + DateTime.Now + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Insertproductwallettranscation(string userid, string mobileno, string debitedamt, string status)
    {
        try
        {

            string SQLQuery = "insert into tbl_walletalltransactionproductwallet (userid,mobileno,creditedamount,debitedamt, date,status) values ('" + userid + "','" + mobileno + "','','" + debitedamt + "', '" + DateTime.Now.ToString() + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable CheckCurrentBalance(string sUserId)
    {
        try
        {
            string SQlQuery = "SELECT INVITATION_BONUS_AMT FROM TBL_USER_WALLET_CURRENT_BALANCES WHERE USERID=" + sUserId;
            return GetDataTable(SQlQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        
    }
    

}