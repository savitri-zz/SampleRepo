﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for clsECportal
/// </summary>
public class clsbit2byte : BaseClass
{
	public clsbit2byte()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void Addpaiduser(entpaidreg reg, string password, string codeverify)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" INSERT INTO tbl_registration_temporary(producttype,mobileno,password,fullname,emailid,state,city,placement,SponsorUserID,placementid,levelno,");
            sb.Append(" referid,usertype,status,verificationcode,joindate,activestatus,userid) VALUES ('" + reg.producttype + "', '" + reg.mobileno + "', '" + password + "',");
            sb.Append("'" + reg.fullname + "', ");
            sb.Append("'" + reg.emailid + "', ");
            sb.Append("'" + reg.state + "', ");
            sb.Append("'" + reg.city + "', ");
            sb.Append("'" + reg.placement + "', ");
            sb.Append("'" + reg.SponsorUserID + "', ");
            sb.Append("'"+ reg.placementid +"',");
            sb.Append("'" + reg.levelno + "', ");
            if (reg.referid == "")
            {
                sb.Append("0, ");
            }
            else
            {
                sb.Append("'" + reg.referid + "', ");
            }
            sb.Append("'" + reg.usertype + "', ");
            sb.Append("'" + reg.status + "', ");
            sb.Append("'" + codeverify + "',");
            sb.Append("'" +DateTime.Now.ToString()  + "', ");
            sb.Append("'NA', ");
            sb.Append("'" + reg.userid + "') ");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getuseridpaid1(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno = '" + mobileno + "' and invited_user_status='2'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Sellerinformation(string companyname, string name, string mobileno, string emailid, string aboutcompany)
    {
        try
        {
            string SQLQuery = "insert into tbl_seller (companyname, name, mobileno, emailid, aboutcompany) values ('" + companyname + "','" + name + "', '" + mobileno + "', '" + emailid + "', '" + aboutcompany + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void Advertise(string companyname, string name, string mobileno, string emailid, string aboutcompany)
    {
        try
        {
            string SQLQuery = "insert into tbl_seller (companyname, name, mobileno, emailid, aboutcompany) values ('" + companyname + "','" + name + "', '" + mobileno + "', '" + emailid + "', '" + aboutcompany + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetProducts()
    {
        try
        {
            string SQLQuery = "select * from tbl_Product";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable deducationmemebers(string mobile)
    {
        try
        {
            string SQLQuery = "select SUM(CAST (tds as float)) as tds, SUM(CAST (pw as float)) as pw from tbl_pw_deductions where userid ='" + mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetProductsDetails(string sno)
    {
        try
        {
            string SQLQuery = "select sno,Code,Product_name,QTY,cost,proccingfee,Round(tax,0) as tax,total,ROUND(mrp,0) as mrp from tbl_Products where sno = '" + sno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getnews()
    {
        try
        {
            string SQLQuery = "select * from add_news";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddlstates()
    {
        try
        {
            string SQLQuery = "select * from tbl_indianstates";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getddlcities(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_cities where stateid =" + id;

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable Getpindetails()
    {
        try
        {
            string SQLQuery = "select * from tbl_paypin";

            return GetDataTable(SQLQuery, false);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getnonmemreferedname(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetLevelno(string SponsorUserID)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where SponsorUserID = '" + SponsorUserID + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getuserid(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno = '" + mobileno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetInvitationDetailsByUserID(string sUserID)
    {
        try
        {
            string SQLQuery = "SELECT SNO, INIVTED_USER, FNAME, LNAME, GENDER, AGEGROUP, MOBILENO, EMAILID, AREA, ADDRESS, PINCODE, COUNTRY, STATE, DISTRICT, CITY, OCCUPATION, CHECKEDITEM, INVITED_DATE, STATUS, INVITED_USER_STATUS, ACTIVE_STATUS, POINTS, MSGSTATUS, PLACEMENT, PLACEMENTID, SPONSORUSERID, REFERID, INVITED_THROUGH, IS_MAIL_SENT FROM tbl_invitefriends WHERE USERID = '" + sUserID + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetuseridPaid(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno = '" + mobileno + "' and invited_user_status='2'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getuseridfree(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno = '" + mobileno + "' and invited_user_status='1'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getuseridpaidmems(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno = '" + mobileno + "' and invited_user_status='2'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getuserrefid(string tablename  , string refid)
    {
        try
        {
            string SQLQuery = "select * from " + tablename + " where mobileno = '" + refid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable senddetailfree(string varification)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where verifycode ='" + varification + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable logindetailfree(string mobile, string password)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where mobileno ='" + mobile + "' and  userpwd COLLATE Latin1_General_CS_AS ='" + password + "' COLLATE Latin1_General_CS_AS  AND INVALID_DATA_STATUS = 0";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable logindetailfree(string mobile,string EmailID, string password )
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where (mobileno ='" + mobile + "' or emailid ='" + EmailID + "') and  userpwd COLLATE Latin1_General_CS_AS ='" + password + "' COLLATE Latin1_General_CS_AS AND INVALID_DATA_STATUS = 0";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public bool CheckLoginDetailsByMobileNum(string sMobileNo, string sPassword)
    {
        try
        {
            bool bRetVal = false;
            string sQry = "SELECT * FROM TBL_ACTIVE_USERS WHERE MOBILENO = '" + sMobileNo + "' AND USERPWD COLLATE Latin1_General_CS_AS ='" + sPassword + "' COLLATE Latin1_General_CS_AS";
            DataTable dtUser = new DataTable();
            dtUser = GetDataTable(sQry, true);
            if (dtUser.Rows.Count > 0)
            {
                bRetVal = true;
            }
            return bRetVal;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    public DataTable loginfree(string mobile)
    {
        try
        {
            string SQLQuery = "SELECT *  FROM TBL_FREEMEMREG WHERE MOBILENO ='" + mobile + "' AND INVALID_DATA_STATUS=0";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable loginfreeActive(string mobile)
    {
        try
        {
            string SQLQuery = "select mobileno,name,userid from tbl_freememreg where mobileno ='" + mobile + "' and activeuser='A' AND IS_TERMS_AGREED = 1 ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable loginpaid(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where mobileno ='" + mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable freeactivation(string mobile, string email)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where mobileno ='" + mobile + "' and  emailid='" + email + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable loginfreeActivemsg(string userid)
    {
        try
        {
            string SQLQuery = "select emailid,name from tbl_freememreg where userid ='" + userid + "' and activeuser='A'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable paidactivation(string mobile, string email)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno ='" + mobile + "' and  emailid='" + email + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable paidactivationreferal(string mobile)
    {
        try
        {
            string SQLQuery = "select fullname,userid from tbl_registration where mobileno ='" + mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable FreeActivationReferal(string mobile)
    {
        try
        {
            string SQLQuery = "select name as fullname, userid from tbl_freememreg where mobileno = '" + mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
   
    public void updatefreeuser(string sno)
    {
        try
        {

            string SQLQuery = "update tbl_freememreg set activat_sms_code=1 where sno='" + sno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updatepaiduser(string sno)
    {
        try
        {

            string SQLQuery = "update tbl_registration set status=1 where sno='" + sno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable senddetailpaid(string varification)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where verificationcode ='" + varification + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable logindetailpaid(string mobile, string password)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno ='" + mobile + "' and password COLLATE Latin1_General_CS_AS  = '" + password + "' COLLATE Latin1_General_CS_AS  and status='1'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable logindetailpaid(string mobile, string EmailID, string password)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where (mobileno ='" + mobile + "' or emailid ='" + EmailID + "') and password COLLATE Latin1_General_CS_AS  = '" + password + "' COLLATE Latin1_General_CS_AS  and status='1'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable freeforgotpassword(string mobile)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where mobileno='" + mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable freeforgotpasswordemail(string email)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where emailid='" + email + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable paidforgotpassword(string mobile)
    {
        try
        {
            string SQLQuery = "SELECT * FROM TBL_REGISTRATION WHERE MOBILENO='" + mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable z_invitememreg(string mobile)
    {
        try
        {
            string SQLQuery = "SELECT tbl_invitefriends.*, tbl_freememreg.name FROM tbl_invitefriends left JOIN tbl_freememreg ON tbl_invitefriends.mobileno = tbl_freememreg.mobileno";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public DataTable paidforgotpasswordemail(string email)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where emailid='" + email + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void updatfreepassword(string password, string userid)
    {
        try
        {

            string SQLQuery = "update tbl_freememreg set userpwd='" + password + "' where userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);

            SQLQuery = "UPDATE TBL_ACTIVE_USERS SET USERPWD = '"+ password +"' WHERE USERID = '"+ userid +"'";
            intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updatInviteeLogin(string password, string userid)
    {
        try
        {

            string SQLQuery = "update tbl_freememreg set userpwd='" + password + "',firstlog=3 where userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable changefreepassword(string password, string userid)
    {
        try
        {
            string SQLQuery = "select * from  tbl_freememreg where  userpwd='" + password + "' COLLATE SQL_Latin1_General_CP1_CS_AS and userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updatpaidpassword(string password, string userid)
    {
        try
        {

            string SQLQuery = "update tbl_registration set password='" + password + "' where userid='" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable changepaidpassword(string password, string userid)
    {
        try
        {
            string SQLQuery = "select * from  tbl_registration where  password='" + password + "' COLLATE SQL_Latin1_General_CP1_CS_AS and userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void zdelete_free_user(string mobileno)
    {
        try
        {
            string SQLQuery = "delete from  tbl_freememreg where  mobileno='" + mobileno + "' ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void updateimages(string imagename, string userid)
    {
        try
        {
            string SQLQuery = "update tbl_imagedetail set imagename = '" + imagename + "' where userid = '" + userid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

//  ---------------------------------    Start By Ganga Purpose: Update Background Theme based on userid  --------------------------

    public void update_Background_Theme(string imagename, string userid, out int rowaffect)
    {
        try
        {
            string SQLQuery = "update tbl_imagedetail set THEME_IMAGE_NAME = '" + imagename + "' where userid = '" + userid + "'";
            rowaffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    //  ----------------------------------      End By Ganga   -----------------------------------

    public void insertimages(string userid,string status, string imagename)
    {
        try
        {
            string SQLQuery = "insert into tbl_imagedetail (userid,status, imagename) values ('" + userid + "','" + status + "', '" + imagename + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable findimage(string userid)
    {
        try
        {
            string SQLQuery = "SELECT SNO, IMAGENAME, USERID, STATUS, THEME_IMAGE_NAME FROM TBL_IMAGEDETAIL WHERE USERID = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable chekreference(string refered)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno = '" + refered + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable chekreferencefree(string refered)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where mobileno = '" + refered + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void Addlevel(int userid, int levelLefft)
    {
        try
        {   string query="";
        string query1 = "Insert into tbl_level(Left_Id,Right_Id) values(" + userid + ",null)";
        string query2 = "Insert into tbl_level(Left_Id,Right_Id) values(null," + userid + ")";
            if (levelLefft == 1)
            {
                query = query1;
            }
            else 
            {
                query = query2;
            }
            int intRowAffect = fnExecuteNonQuery(query, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        
    }

    public DataTable selectuser(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno = '" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void zdelete_paid_user()
    {
        try
        {
            string SQLQuery = "delete from  tbl_registration where  status='0' ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable selectreference( string mobile)
    {
        try
        {
            string SQLQuery = "select inivted_user from tbl_invitefriends where mobileno = '" + mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getMobileNumbers(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        
    }
    public DataTable GetusernamePaid12(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where mobileno = '" + mobileno + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getusername(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable Getfreeusername(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where referal_id = '" + uid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable getMobileNumbersFree(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable nonmemdetail(string memusertype)
    {
        try
        {
            string SQLQuery = "select * from tbl_nonmemreg where mobileno = '" + memusertype + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable nonmemdetail1(string memusertype)
    {
        try
        {
            string SQLQuery = "select * from tbl_nonmemreg where userid = '" + memusertype + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void updateunauthorised(string mobileno)
    {
        try
        {
            string SQLQuery = "update tbl_invitefriends set active_status = 'U' where mobileno = '" + mobileno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertunauthorised(string inviteduser, string fname, string lname, string gender, string agegroup, string mobile, string emailid, string area, string address, string pincode, string country, string state, string district,string city, string occupation, string checkeditem, string inviteddate, string status, string inviteduserstaus, string activestatus, string point,string userid)
    {
        try
        {
            string SQLQuery = "insert into tbl_unauthorised (inivted_user,fname, lname,gender,agegroup,mobileno,emailid,area,address,pincode,country,state,district,city,occupation,checkeditem,invited_date,status,invited_user_status,active_status,points,userid) values ('" + inviteduser + "','" + fname + "', '" + lname + "','" + gender + "','" + agegroup + "','" + mobile + "','" + emailid + "','" + area + "','" + address + "','" + pincode + "','" + country + "','" + state + "','" + district + "','" + city + "','" + occupation + "','" + checkeditem + "','" + inviteddate + "','" + status + "','" + inviteduserstaus + "','" + activestatus + "','" + point + "','" + userid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
 
    }

    public void zdeleteunauthorised(string mobileno)
    {
        try
        {
            string SQLQuery = "delete from  tbl_invitefriends where  mobileno='" + mobileno + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

 public DataTable findfifty(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user ='" + uid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
 public void updatefiftystatus(string uid)
    {
        try
        {

            string SQLQuery = "update tbl_freememreg set fiftystatus='M' where userid='" + uid + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

 
 public DataTable freechangepassword(string uid)
 {
     try
     {
         string SQLQuery = "select firstlog from tbl_freememreg where userid ='" + uid + "' ";
         return GetDataTable(SQLQuery, true);
     }
     catch (Exception Ex)
     {
         throw Ex;
     }
 }
 public void paidchngpswdstatus(string uid)
 {
     try
     {

         string SQLQuery = "update tbl_registration set firstlog='1' where userid='" + uid + "'";
         int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
     }
     catch (Exception Ex)
     {
         throw Ex;
     }
 }

 public void freeuploadimgstatus(string uid)
 {
     try
     {

         string SQLQuery = "update tbl_freememreg set firstlog='2' where userid='" + uid + "'";
         int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
     }
     catch (Exception Ex)
     {
         throw Ex;
     }
 }

 public void UpdateFirstLogStatus(string sUserID, string sFirstLogStaus)
 {
     try
     {
         string sQry = "Update Tbl_freememreg Set Firstlog='" + sFirstLogStaus + "' Where Userid='" + sUserID + "'";
         int intRowAffect = fnExecuteNonQuery(sQry, true);

         sQry = "UPDATE TBL_REGISTRATION SET FIRSTLOG='" + sFirstLogStaus + "' WHERE USERID = '" + sUserID + "'";
         intRowAffect = fnExecuteNonQuery(sQry, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }


 public void freechngpswdstatus(string Suserid, string Password_Change_status)
 {
     try
     {

         string SQLQuery = "UPDATE TBL_FREEMEMREG SET IS_PASSWORD_CHANGED = '" + Password_Change_status + "' WHERE USERID = '" + Suserid + "'";
         int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
     }
     catch (Exception Ex)
     {
         throw Ex;
     }
 }
 public void UpdateImageUploadstatus(string Suserid)
 {
     try
     {

         string SQLQuery = "UPDATE TBL_FREEMEMREG SET IS_PROFILE_PIC_UPLOADED = 1 WHERE USERID = '" + Suserid + "'";
         int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
     }
     catch (Exception Ex)
     {
         throw Ex;
     }
 }

 public void UpdateProfileStatus(string Suserid)
 {
     try
     {

         string SQLQuery = "UPDATE TBL_FREEMEMREG SET IS_PROFILE_UPDATED = 1 WHERE USERID = '" + Suserid + "'";
         int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
     }
     catch (Exception Ex)
     {
         throw Ex;
     }
 }

 //  Added By Ganga  Purpose: Upload the Profile Pic and change the status  date:31-12-2014
 public int insert_UpdateProfilePic(string sUid, string status, string imagename, string Original_imagename)
 {
     string sQry = "Exec SP_UPDATE_PROFILEPIC'" + sUid + "','" + status + "', '" + imagename + "','"+Original_imagename+"'";
     int intRowAffect = fnExecuteNonQuery(sQry, true);
     return intRowAffect;
 }

 //  End of Upload the Profile Pic and change the status

 public DataTable getavatar()
 {
     try
     {
         string sqlquery = "select * from tbl_avatars";
         return GetDataTable(sqlquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

 public DataTable paidmem(string uid)
 {
     try
     {
         string sqlquery = "select * from tbl_registration where userid='" + uid + "' ";
         return GetDataTable(sqlquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

 public DataTable freemem(string uid)
 {
     try
     {
         string sqlquery = "select * from tbl_freememreg where userid='" + uid + "' ";
         return GetDataTable(sqlquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }
 public DataTable getchannels()
 {
     try
     {
         string SQLquery = "SELECT * FROM tbl_TV_Channels_Master WHERE LANGUAGE_ID=3 AND CATEGORY_ID=1";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }
 public DataTable GetCategories( string CategoryId, int LanguageID)
 {
     try
     {
         string SQLquery = "select * from tbl_TV_Channels_Master where CATEGORY_ID='" + CategoryId + "' ";
         //if (LanguageID != 1)
         SQLquery = string.Concat(SQLquery, " and  language_id=",LanguageID);
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

 public DataTable GetTvchannelsByLanguage(int LanguageID)
 {
     try
     {
         string SQLquery = "select * from tbl_TV_Channels_Master where language_id=" + LanguageID + " ";
         
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }


 public DataTable GetLanguages()
 {
     try
     {
         string SQLquery = "Select * from tbl_Language_Master ";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

 public DataTable GetChannelCategories()
 {
     try
     {
         string SQLquery = "Select * from tbl_TV_Channel_Category_Master order by CATEGORY_ID desc";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

 public DataTable EmailTemplateDetails(string referalid, string Template_id)
 {
     try
     {
        string SQLquery = "SELECT T.EMAIL_SUBJECT ,   DFL.NAME, DFL.OCCUPATION, DFL.CITYNAME, DFL.IMAGENAME , T.BODY , T.LINK";
        SQLquery = SQLquery + " FROM TBL_EMAILTEMPLATES T,";
        SQLquery = SQLquery + " (SELECT P.USERID, P.NAME, OC.OCCUPATION, CI.CITY_NAME AS CITYNAME, case when charindex('.', IMAGENAME) > 0 then IMAGENAME else IMAGENAME + '.png'  end IMAGENAME FROM TBL_EDITPROFILE P";
        SQLquery = SQLquery + " LEFT OUTER JOIN TBL_OCCUPATION OC ON P.OCCUPATION = OC.ID";
        SQLquery = SQLquery + " LEFT OUTER JOIN CITIES CI ON P.[CITY/AREA] = CI.CITY_ID";
        SQLquery = SQLquery + " LEFT OUTER JOIN TBL_IMAGEDETAIL IMG ON P.USERID = IMG.USERID) AS DFL";
        SQLquery = SQLquery + " WHERE T.TEMPLATE_ID ='"+ Template_id+"' AND DFL.USERID ='" + referalid + "'";

        /*
         * This below query is written by Sudhindra on 15-09-2014. Purpose : to fine tune the above query.... Need to recheck once againd and to be incorporated.
         * SELECT T.EMAIL_SUBJECT ,   DFL.NAME, DFL.OCCUPATION, DFL.CITYNAME, DFL.IMAGENAME , T.BODY , T.LINK FROM TBL_EMAILTEMPLATES T,
                (SELECT P.USERID, P.NAME, DBO.FN_GET_DETAILS_BY_USERID(P.USERID, 'OCCUPATION') OCCUPATION , DBO.FN_GET_DETAILS_BY_USERID(P.USERID, 'CITY') AS CITYNAME
                    , case when charindex('.', IMAGENAME) > 0 then IMAGENAME else IMAGENAME + '.png'  end IMAGENAME FROM TBL_EDITPROFILE P
                LEFT OUTER JOIN TBL_IMAGEDETAIL IMG ON P.USERID = IMG.USERID) AS DFL
            WHERE T.TEMPLATE_ID ='2' AND DFL.USERID ='2591341820100433'
         * */

        return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }     
 }
 public DataTable ProductPurchase()
 {
     try
     {
         string SQLquery = "Select Email_Subject,Body from tbl_EmailTemplates where Template_ID='3'";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }    
 
  }

    //*-----------BY vasu To GEt Coupons Details-------------------

 public DataTable GetCoupons(string Userid)
 {
     try
     {
         string SQLquery = "EXEC DBO.USP_GET_COUPONS_BY_USERID '" + Userid + "'";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

    /* To insert comments for quantum master -- Added by Narendra on 30/8/14*/
 public void Comments_Quantumuser(string comments, string mobileno, string userid, string image, string profession, string city, string name, string userid_of_quantum_master)
 {
     try
     {
         string SQLQuery = "insert into tbl_comments_quant (comment, mobileno, date,userid,image,profession,city,name,userid_quantum_master) values ('" + comments + "','" + mobileno + "', GETDATE(),'" + userid + "','" + image + "','" + profession + "','" + city + "','" + name + "','" + userid_of_quantum_master + "')";
         int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
     }
     catch (Exception Ex)
     {
         throw Ex;
     }
 }
 public DataTable getcomments()
 {
     try
     {
         string SQLquery = "select sno, comment, mobileno, userid, date, image, profession, city, name, userid_quantum_master from tbl_comments_quant order by date desc";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }
 public DataTable getcomments(string userid_of_quantum_master)
 {
     try
     {
         string SQLquery = "select sno, comment, mobileno, userid, date, image, profession, city, name, userid_quantum_master from tbl_comments_quant where userid_quantum_master='" + userid_of_quantum_master + "' order by date desc";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }
 public DataTable getcomments(int month)
 {
     try
     {
         month = month - 1;
         string SQLquery = "select sno, comment, mobileno, userid, date, image, profession, city, name, userid_quantum_master from tbl_comments_quant where datepart(mm,date)='" + month + "' order by date desc";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

 public void UpdateMobileNumberForImportContact(string sUserID, string sMobileNo, string sReferID)
 {
     try
     {

         General genobj = new General();
         if (genobj.IsValidMobileNo(sMobileNo) == false)
             return;

         string sQry = "UPDATE TBL_INVITEFRIENDS SET MOBILENO = '" + sMobileNo + "' WHERE REFERID = '" + sReferID + "' AND MOBILENO = '' AND USERID = '"+ sUserID +"'";
         int intRowAffect = fnExecuteNonQuery(sQry, true);

         sQry = "UPDATE TBL_FREEMEMREG SET MOBILENO = '" + sMobileNo + "' where userid = '" + sUserID + "' AND MOBILENO = ''";
         intRowAffect = fnExecuteNonQuery(sQry, true);
     }
     catch (Exception ex)
     {

         throw ex;
     }
 }


 public DataTable GetUsersToSendInvitationMails()
 {
     try
     {
         string sQry = "SELECT TOP 100 USERID FROM TBL_INVITEFRIENDS WHERE IS_MAIL_SENT = 0 ORDER BY NEWID()"; // AND INVITED_THROUGH = 'M'
         return GetDataTable(sQry, true);
     }
     catch (Exception)
     {
         
         throw;
     }
 }

 public DataTable GetCounterToSendInvitationMails()
 {
     try
     {
         string sQry = "SELECT COUNT(*) CTR FROM TBL_INVITEFRIENDS WHERE IS_MAIL_SENT = 0";  // AND INVITED_THROUGH = 'M'
         return GetDataTable(sQry, true);
     }
     catch (Exception ex)
     {

         throw ex;
     }
 }

 public DataTable GetUserDetalsForInvitationMail(string sUserID)
 {
     try
     {
         string sQry = "SELECT V.USERID, V.NAME, V.MOBILENO, V.EMAILID, V.REFERALID, V.REF_NAME , I.IMAGENAME REF_IMAGE FROM USER_NETWORK_VIEW V LEFT OUTER JOIN TBL_IMAGEDETAIL I ON V.REFERALID = I.USERID WHERE V.USERID = '" + sUserID + "'";
         return GetDataTable(sQry, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

 public DataTable GetOffers(string sUserID)
 {
     try
     {
         //string SQLquery = "SELECT * FROM TBL_OFFERS WHERE PROCESSED_YN = 0 ORDER BY NEWID()";
         string sSQLQuery = "SELECT SNO, MERCHANT, DOTD_OR_OFFFER, OFFER_TITLE, OFFER_DESCRIPTION, REPLACE(URL , 'mfloatanonymoususer', '"+ sUserID +"') URL , IMG_URL, AVAILABILITY, PROCESSED_YN, IMG_PATH, PROCESSED_DT, IS_ACTIVE, DOTD_VALID_UPTO "; 
         sSQLQuery = sSQLQuery  + " FROM TBL_OFFERS WHERE DOTD_OR_OFFFER = 'Offer' AND IS_ACTIVE = 1 ORDER BY NEWID()";
         return GetDataTable(sSQLQuery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }



 public DataTable GetOfferOfTheDay(string value)
 {
     try
     {
         string SQLquery = "SELECT  * FROM TBL_OFFERS WHERE DOTD_OR_OFFFER='" + value + "' AND PROCESSED_YN = 0 ORDER BY NEWID()";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }
 public DataTable GetDealOfTheDay(string sCriteria, string sUserID)
 {
     try
     {
         string SQLquery = "SELECT TOP 1  SNO, MERCHANT, DOTD_OR_OFFFER, OFFER_TITLE, OFFER_DESCRIPTION, REPLACE(URL , 'mfloatanonymoususer', '" + sUserID + "') URL , IMG_URL, AVAILABILITY, PROCESSED_YN, IMG_PATH, PROCESSED_DT, IS_ACTIVE, DOTD_VALID_UPTO  FROM TBL_OFFERS WHERE DOTD_OR_OFFFER='" + sCriteria + "' AND IS_ACTIVE = 1 ORDER BY NEWID()";
         return GetDataTable(SQLquery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

 public DataTable GetOffers()
 {
     try
     {
         //string SQLquery = "SELECT * FROM TBL_OFFERS WHERE PROCESSED_YN = 0 ORDER BY NEWID()";
         string sSQLQuery = "SELECT SNO, MERCHANT, OFFER_TITLE, OFFER_DESCRIPTION, URL , IMG_URL, AVAILABILITY, PROCESSED_DT, IS_ACTIVE, DOTD_VALID_UPTO ";
         sSQLQuery = sSQLQuery + " FROM TBL_OFFERS WHERE DOTD_OR_OFFFER = 'Offer' AND IS_ACTIVE = 1 ORDER BY NEWID()";
         return GetDataTable(sSQLQuery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }

 public DataTable GetMerchants()
 {
     try
     {
         //string SQLquery = "SELECT * FROM TBL_OFFERS WHERE PROCESSED_YN = 0 ORDER BY NEWID()";
         string sSQLQuery = "SELECT ID, MNAME, MERCHANT_DESCRIPTION, MRCHANT_LOGO FROM TBL_MRCHNT WHERE MRCHANT_LOGO != '' AND IS_ACTIVE = 1 ORDER BY NEWID()";
         return GetDataTable(sSQLQuery, true);
     }
     catch (Exception ex)
     {
         throw ex;
     }
 }
}