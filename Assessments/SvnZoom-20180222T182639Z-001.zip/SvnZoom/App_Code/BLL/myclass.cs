﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for myclass
/// </summary>
public class myclass:BaseClass
{
	public myclass()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public DataTable getnonmemberdetails()
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg" ;
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


   
        

    public DataTable getnonmem(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user = '" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getdetailsnon(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where userid='"+userid+"'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void insertintotemp(string mobileno, string userpwd, string verifycode, string name, string emailid, string state, string city, string referal_mobile, string referal_id, string memtype, string joindate, string activat_sms_code, string status, string levelno, string userids, string activeuser, string fiftystatus,string referalname,string ssno)
    {
        try
        {

            string SQLQuery = "insert into tbl_freememregtemp(mobileno,userpwd,verifycode,name,emailid,state,city,referal_mobile,referal_id,memtype,joindate,activat_sms_code,status,levelno,userid,activeuser,fiftystatus,referalname,ssno) values('" + mobileno + "','" + userpwd + "','" + verifycode + "','" + name + "','" + emailid + "','" + state + "','" + city + "','" + referal_mobile + "','" + referal_id + "','" + memtype + "','" + joindate + "','" + activat_sms_code + "','" + status + "','" + levelno + "','" + userids + "','" + activeuser + "','" + fiftystatus + "','" + referalname + "','" + ssno + "') ";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable gettemdetails()
    {
        try
        {
            string SQLQuery = "select * from tbl_freememregtemp";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
     public void deletetempnonmem()
    {
        try
        {
            string SQLQuery = "delete from tbl_freememregtemp";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
     public DataTable searchbymobile(string mobileno)
     {
         try
         {
             string SQLQuery = "select * from tbl_freememreg where mobileno='" + mobileno + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable searchbyname(string name)
     {
         try
         {
             string SQLQuery = "select * from tbl_freememreg where name='" + name + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable searchbyuserid(string userid)
     {
         try
         {
             string SQLQuery = "select * from tbl_freememreg where userid='" + userid + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable searchufreedate5(string fromdate, string todate)
     {
         try
         {
             string SQLQuery = "select *  from tbl_freememreg where joindate BETWEEN '" + fromdate + "' AND  '" + todate + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }
     public DataTable getfullname(string sno)
     {
         try
         {
             string SQLQuery = "select fullname  from tbl_registration where mobileno='"+sno+"'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }
     public void insertintoapptemp(string mobileno, string userpwd, string verifycode, string name, string emailid, string state, string city, string referal_mobile, string referal_id, string memtype, string joindate, string activat_sms_code, string status, string levelno, string userids, string activeuser, string fiftystatus, string referalname, string ssno)
     {
         try
         {

             string SQLQuery = "insert into tbl_affliatememtemp(mobileno,userpwd,verifycode,name,emailid,state,city,referal_mobile,referal_id,memtype,joindate,activat_sms_code,status,levelno,userid,activeuser,fiftystatus,referalname,ssno) values('" + mobileno + "','" + userpwd + "','" + verifycode + "','" + name + "','" + emailid + "','" + state + "','" + city + "','" + referal_mobile + "','" + referal_id + "','" + memtype + "','" + joindate + "','" + activat_sms_code + "','" + status + "','" + levelno + "','" + userids + "','" + activeuser + "','" + fiftystatus + "','" + referalname + "','" + ssno + "') ";
             int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public void deletetempnonmem2()
     {
         try
         {
             string SQLQuery = "delete from tbl_affliatememtemp";
             int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }

     }
     public DataTable gettempappliate()
     {
         try
         {
             string SQLQuery = "select * from tbl_affliatememtemp";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }

     public DataTable sample(string mobile)
     {
         try
         {
             string SQLQuery = "select * from tbl_registration where mobileno='" + mobile + "'" ;
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable sample1(string mobile)
     {
         try
         {
             string SQLQuery = "select * from tbl_freememreg where mobileno='" + mobile + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }

     public void insertcourier(string doj, string userid, string fullname, string mobileno, string invitedata, string corierdetails)
     {
         try
         {

             //string SQLQuery = "insert into courierdetails(joindate,userid,fullname,mobileno,invitedata,corierdetails,changeddate) values('" + doj + "','" + userid + "','" + fullname + "','" + mobileno + "','" + invitedata + "','" + corierdetails + "','" + System.DateTime.Now + "') ";
             string SQLQuery = "USP_insertcourier '" + doj + "','" + userid + "','" + fullname + "','" + mobileno + "','" + invitedata + "','" + corierdetails + "','" + System.DateTime.Now + "'";
             int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     

     public DataTable couriermem()
     {
         try
         {
             string SQLQuery = "select * from courierdetails ";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }

     public DataTable couriermem2()
     {
         try
         {
             //string SQLQuery = "select distinct top (select COUNT(Distinct userid) from courierdetails) * from courierdetails order by changeddate desc";// and userid='" + userid + "'";
             string SQLQuery = " USP_couriermem2 ";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }

     public DataTable productstatuszero(string userid)
     {
         try
         {
             string SQLQuery = "select * from tbl_Userwalletstatus where walletstatus=0 and useid='"+userid+"'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable GetUserwalletpaidmem()
     {
         try
         {
             string SQLQuery = "select * from tbl_Userwalletstatus where walletstatus=0";

             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable GetUserwalletunpaidmem()
     {
         try
         {
             string SQLQuery = "select * from tbl_Userwalletstatus where walletstatus=1";

             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable getregtableitems()
     {
         try
         {
             string SQLQuery = "select * from tbl_registration";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable getregtableitemsbyuser(string userid)
     {
         try
         {
             string SQLQuery = "select * from tbl_registration where userid='" + userid + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable sample()
     {
         try
         {
             string SQLQuery = "select userid from tbl_registration ";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable productstatuszero1(string userid)
     {
         try
         {
             string SQLQuery = "select * from tbl_Userwalletstatus where walletstatus=0 and useid='" + userid + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
     public DataTable remainderstatus(string userid)
     {
         try
         {
             string SQLQuery = "select userid,SUM(logincount) as counts,status from tbl_assuredlogincount where userid='" + userid + "' group by userid,status";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }

     public DataTable remainderstatus1()
     {
         try
         {
             string SQLQuery = "select MAX(logindate)as logindate,userid,SUM(logincount) as counts,status from tbl_assuredlogincount group by userid,status";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
     }
      public DataTable remainderstatusdates(string userid,string status)
     {
         try
         {
             string SQLQuery = "select logindate,userid,status from tbl_assuredlogincount where userid='" + userid + "' and status='" + status + "'";
             return GetDataTable(SQLQuery, true);
         }
         catch (Exception Ex)
         {
             throw Ex;
         }
      }
      public void insertrefundamt(string userid,string mobileno,string credit,string debit,string status)
      {
          try
          {

              //string SQLQuery = "insert into tbl_refundAmount(userid,mobileno,creditamount,debitaamount,date,status) values('" + userid + "','" + mobileno + "','" + credit + "','" + debit + "','" + DateTime.Now + "','" + status + "') ";
              string SQLQuery = "USP_insertrefundamt  '" + userid + "','" + mobileno + "','" + credit + "','" + debit + "','" + DateTime.Now + "','" + status + "'";
              int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
          }
          catch (Exception Ex)
          {
              throw Ex;
          }
      }
      public DataTable getrefund()
      {
          try
          {
              string SQLQuery = "select * from tbl_refundAmount";
              return GetDataTable(SQLQuery, true);
          }
          catch (Exception Ex)
          {
              throw Ex;
          }
      }
      public DataTable transferstatus(string accno)
      {
          try
          {
              string SQLQuery = "select * from tbl_admingenerate_pin where accountno='" + accno + "'";
              return GetDataTable(SQLQuery, true);
          }
          catch (Exception Ex)
          {
              throw Ex;
          }
      }
      public DataTable Getupdateeditprofile(string userid)
      {
          try
          {
              string SQLQuery = "SELECT * FROM tbl_editprofile where userid = '" + userid + "'";
              return GetDataTable(SQLQuery, true);
          }
          catch (Exception Ex)
          {
              throw Ex;
          }
      }
      public void updateeditprofile(string fname, string mobileno, string emailid, string state, string city, string userid)
      {
          try
          {

              string SQLQuery = "update tbl_editprofile set name='" + fname + "', mobileno='" + mobileno + "', email='" + emailid + "',state='" + state + "',  city/area='" + city + "' where userid='" + userid + "'";
              int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
          }
          catch (Exception Ex)
          {
              throw Ex;
          }
      }
      public DataTable Getupdateuserwalletbyadmin(string userid)
      {
          try
          {
              string SQLQuery = "SELECT * FROM tbl_Userwallet where userid = '" + userid + "'";
              return GetDataTable(SQLQuery, true);
          }
          catch (Exception Ex)
          {
              throw Ex;
          }
      }
      public void updateuserwalletbyadmin(string name, string mobile, string email, string userid)
      {
          try
          {

              string SQLQuery = "update tbl_Userwallet set name='" + name + "',mboile='" + mobile + "',emailid='" + email + "' where userid='" + userid + "'";
              int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
          }
          catch (Exception Ex)
          {
              throw Ex;
          }
      }
      public DataTable Getupdatebankdetails(string userid)
      {
          try
          {
              string SQLQuery = "SELECT * FROM tbl_updatebankdetails where userid = '" + userid + "'";
              return GetDataTable(SQLQuery, true);
          }
          catch (Exception Ex)
          {
              throw Ex;
          }
      }
      public void updatebankdetails(string name, string mobile, string email, string password, string userid)
      {
          try
          {

              string SQLQuery = "update tbl_updatebankdetails set Payeename='" + name + "',mobileno='" + mobile + "',emailid='" + email + "',password='" + password + "' where userid='" + userid + "'";
              int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
          }
          catch (Exception Ex)
          {
              throw Ex;
          }
      }
}

