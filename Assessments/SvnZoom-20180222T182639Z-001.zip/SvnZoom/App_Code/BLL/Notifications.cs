﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for Notifications
/// </summary>
public class Notifications : BaseClass
{
    public Notifications()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public DataTable getEmailBindSubject()
    {
        string sQry = "select distinct Template_ID, Email_Subject from tbl_EmailTemplates";
        return GetDataTable(sQry, true);
    }


    public DataTable getEmailDetails(string sTemplateID)
    {
        string sQry = "select * from tbl_EmailTemplates where Template_ID=" + sTemplateID + "";
        return GetDataTable(sQry, true);
    }

    public DataTable getNotifyType()
    {
        string sQry = "select distinct TYPE_OF_EMAIL from tbl_EmailTemplates";
        return GetDataTable(sQry, true);
    }

    public void updateOrInsertEmailTemplates(string TEMPLATEID, string EMAIL_SUBJECT, string BODY, string LINK, string DESCRIPTION, string EMAILTEMPLATE_NAME, string TYPE_OF_EMAIL)
    {
        string sqlquery = "USP_UPDATEEMIAL_NOTIFICATIONS '" + TEMPLATEID + "','" + EMAIL_SUBJECT + "','" + BODY + "','" + LINK + "','" + DESCRIPTION + "','" + EMAILTEMPLATE_NAME + "','" + TYPE_OF_EMAIL + "'";
        int intRowAffect = fnExecuteNonQuery(sqlquery, true);
    }

    public DataTable getBindSMSType()
    {
        string sQry = "  select distinct TEMPLATEID, TEMPLATE_NAME from tbl_SMSTEMPLATES";
        return GetDataTable(sQry, true);
    }

    public DataTable getSMSNotifyType()
    {
        string sQry = "select distinct SMSTYPE from tbl_SMSTEMPLATES";
        return GetDataTable(sQry, true);
    }

    public DataTable getSMSDetails(string sTemplateID)
    {
        string sQry = "select * from tbl_SMSTEMPLATES where TEMPLATEID=" + sTemplateID + "";
        return GetDataTable(sQry, true);
    }

    public void updateOrInsertSMSTemplates(string TEMPLATEID, string DESCRIPTRION, string BODY, string SMSTYPE, string TEMPLATE_NAME)
    {
        string sqlquery = "USP_UPDATESMS_NOTIFICATIONS '" + TEMPLATEID + "','" + DESCRIPTRION + "','" + BODY + "','" + SMSTYPE + "','" + TEMPLATE_NAME + "'";
        int intRowAffect = fnExecuteNonQuery(sqlquery, true);
    }


    public DataTable getBindAlertType()
    {
        string sQry = "select distinct MESSAGEID, TEMPLATE_NAME from tbl_ALERTMESSAGES";
        return GetDataTable(sQry, true);
    }

    public DataTable getAlertNotifyType()
    {
        string sQry = "select distinct TYPE_OF_ALERT from tbl_ALERTMESSAGES";
        return GetDataTable(sQry, true);
    }

    public DataTable getAlertDetails(string sMESSAGEID)
    {
        string sQry = "select * from tbl_SMSTEMPLATES where TEMPLATEID=" + sMESSAGEID + "";
        return GetDataTable(sQry, true);
    }

    public void updateOrInsertAlertTemplates(string MESSAGEID, string ALERTTYPE, string TEMPLATE_NAME, string POSITION, string BODY)
    {
        string sqlquery = "USP_UPDATEALERT_NOTIFICATIONS'" + MESSAGEID + "','" + ALERTTYPE + "','" + TEMPLATE_NAME + "','" + POSITION + "','" + BODY + "'";
        int intRowAffect = fnExecuteNonQuery(sqlquery, true);
    }


    public void updateOrInsertEmailTemplates(string EVENT_NAME, string EVENT_DESCRIPTION, DateTime CONDUCTING_DATE, DateTime PASSES_END_DATE, string PASS_SRL_NO_SUFFFIX, string EVENT_PASS_MAX_LIMIT, string txtEdtinmail, string EVENT_VENUE_DETAILS_IN_MAIL, string EVENT_CHECKIN_IN_MAIL, string EVENT_BEGINS_IN_MAIL)
    {
        try
        {
            string sQry = "INSERT INTO TBL_EVENTS_MASTER(EVENT_NAME , EVENT_DESCRIPTION , CONDUCTING_DATE , PASSES_END_DATE,PASS_SRL_NO_SUFFFIX,EVENT_PASS_MAX_LIMIT,EVENT_DATE_IN_MAIL,EVENT_VENUE_DETAILS_IN_MAIL,EVENT_CHECKIN_IN_MAIL,EVENT_BEGINS_IN_MAIL) VALUES ";
            sQry += "('" + EVENT_NAME + "', '" + EVENT_DESCRIPTION + "','" + CONDUCTING_DATE + "','" + PASSES_END_DATE + "','" + PASS_SRL_NO_SUFFFIX + "','" + EVENT_PASS_MAX_LIMIT + "','" + txtEdtinmail + "','" + EVENT_VENUE_DETAILS_IN_MAIL + "','" + EVENT_CHECKIN_IN_MAIL + "','" + EVENT_BEGINS_IN_MAIL + "')";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public void updateOrInsertEmailTemplates(string EVENT_NAME, string EVENT_DESCRIPTION, DateTime CONDUCTING_DATE, DateTime PASSES_END_DATE, string PASS_SRL_NO_SUFFFIX, string EVENT_PASS_MAX_LIMIT, string txtEdtinmail, string EVENT_VENUE_DETAILS_IN_MAIL, string EVENT_CHECKIN_IN_MAIL, string EVENT_BEGINS_IN_MAIL, string visibility, string selected)
    {
        try
        {
            string sQry = "INSERT INTO TBL_EVENTS_MASTER(EVENT_NAME , EVENT_DESCRIPTION , CONDUCTING_DATE , PASSES_END_DATE,PASS_SRL_NO_SUFFFIX,EVENT_PASS_MAX_LIMIT,EVENT_DATE_IN_MAIL,EVENT_VENUE_DETAILS_IN_MAIL,EVENT_CHECKIN_IN_MAIL,EVENT_BEGINS_IN_MAIL,Is_Visible, typeofevent) VALUES ";
            sQry += "('" + EVENT_NAME + "', '" + EVENT_DESCRIPTION + "','" + CONDUCTING_DATE + "','" + PASSES_END_DATE + "','" + PASS_SRL_NO_SUFFFIX + "','" + EVENT_PASS_MAX_LIMIT + "','" + txtEdtinmail + "','" + EVENT_VENUE_DETAILS_IN_MAIL + "','" + EVENT_CHECKIN_IN_MAIL + "','" + EVENT_BEGINS_IN_MAIL + "','" + visibility + "','" + selected + "')";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
}