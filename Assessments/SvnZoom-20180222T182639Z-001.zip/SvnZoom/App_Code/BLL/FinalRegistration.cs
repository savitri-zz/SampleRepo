﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for FinalRegistration
/// </summary>
public class FinalRegistration :BaseClass 
{
	public FinalRegistration()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable getpaidregdetail(string mobileno, string userid)
    {
        try
        {
            string sqlquery = "Select * from tbl_registration_temporary where mobileno='" + mobileno + "' and userid='" + userid + "' ";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public void finalpaiduser(entpaidreg reg)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" INSERT INTO tbl_registration(producttype,mobileno,password,fullname,emailid,state,city,placement,placementid,SponsorUserID,levelno,");
            sb.Append(" referid,usertype,joindate,status,verificationcode,userid,TransactionId,upgrade,activestatus,initpakg) VALUES ('" + reg.producttype + "', '" + reg.mobileno + "', '" + reg.password + "',");
            sb.Append("'" + reg.fullname + "', ");
            sb.Append("'" + reg.emailid + "', ");
            sb.Append("'" + reg.state + "', ");
            sb.Append("'" + reg.city + "', ");
            sb.Append("'" + reg.placement + "', ");
            sb.Append("'" + reg.placementid + "',");
            sb.Append("'" + reg.SponsorUserID + "', ");
            sb.Append("'" + reg.levelno + "', ");
            sb.Append("'" + reg.referid + "', ");
            sb.Append("'" + reg.usertype + "', ");
            sb.Append("'" + reg.joindate + "', ");
            sb.Append("'" + reg.status + "', ");
            sb.Append("'" + reg.verificationcode + "', ");
            sb.Append("'" + reg.userid + "', ");
            sb.Append("'" + reg.TransactionId + "', ");
            sb.Append("'" + reg.upgrade + "', ");
            sb.Append("'NA', ");
            sb.Append("'" + reg.initpakg + "') ");
            int intRowAffect = fnExecuteNonQuery(sb.ToString(), true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable deletetemporary(string mobileno)
    {
        try
        {
            string sqlquery = "Select * from tbl_registration_temporary where mobileno='" + mobileno + "'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }

    public void deletetemporary1(string mobile)
    {
        try
        {
            string SQLQuery = "delete from tbl_registration_temporary where mobileno='" + mobile + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
 public DataTable getstatuswallet(string mobileno)
 {
     try
     {
         string sql = "Select * from tbl_Userwalletstatus  where useid='" + mobileno + "'";
         return GetDataTable(sql, true);
     }
     catch (Exception EX)
     {
         throw EX;
     }



 }
}