﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;

/// <summary>
/// Summary description for home
/// </summary>
public class home : BaseClass
{
    public home()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public void zfreeregistration(string mobileno, string userpwd, string verifycode, string name, string emailid, string state, string city, string referal_mobile, string referal_id, string memtype, string joindate, string activat_sms_code, string status, string levelno, string userid)
    {
        try
        {
            string[] strArrList = { "@mobileno", "@userpwd", "@verifycode", "@name", "@emailid", "@state", "@city", "@referal_mobile", "@referal_id", "@memtype", "@joindate", "@activat_sms_code", "@status", "@levelno", "@userid" };
            string[] strArrValues = { mobileno, userpwd, verifycode, name, emailid, state, city, referal_mobile, referal_id, memtype, joindate, activat_sms_code, status, levelno, userid };
            int intRowAffect = fnRunProcedure("sp_freeregister", strArrList, strArrValues, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public DataTable zGetddlstates()
    {
        try
        {
            string SQLQuery = "select * from tbl_indianstates";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable zSearchsentuname(string name)
    {
        try
        {
            string SQLQuery = "select *  from tbl_invitefriends where fname LIKE '" + name + "%' or city LIKE '" + name + "%'  ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void inseretfreenonmembervalues(string mobileno, string userpwd, string verifycode, string name, string emailid, string state, string city, string referal_mobile, string referal_id, string memtype, string joindate, string activat_sms_code, string status, string levelno, string userid)
    {
        try
        {

            /*  string SQLQuery = "insert into tbl_freememreg(mobileno,userpwd, verifycode, name, emailid, state, city, referal_mobile, referal_id, memtype, joindate, activat_sms_code, status, levelno, userid)values ('" + mobileno + "','" + userpwd + "', '" + verifycode + "', '" + name + "', '" + emailid + "', '" + state + "', '" + city + "','" + referal_mobile + "', '" + referal_id + "', '" + memtype + "', '" + joindate + "', '" + activat_sms_code + "', '" + status + "', '" + levelno + "', '" + userid + "')";*/

            string SQLQuery = "USP_Bite2Byte_inseretfreenonmembervalues    '" + mobileno + "','" + userpwd + "', '" + verifycode + "', '" + name + "', '" + emailid + "', '" + state + "', '" + city + "','" + referal_mobile + "', '" + referal_id + "', '" + memtype + "', '" + joindate + "', '" + activat_sms_code + "', '" + status + "', '" + levelno + "', '" + userid + "'";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable zGetreuestids(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_BWTransferAmt where userid='" + userid + "' ";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void DeleteUserMem(string userid)
    {
        try
        {
            string SQLQuery = "delete from tbl_nonmemreg where userid = '" + userid + "'";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getsentinvitmobileno(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where mobileno='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable zGetsearchname(string name, string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user='" + userid + "'and (fname LIKE '" + name + "%' or city LIKE '" + name + "%'or district LIKE '" + name + "%' or mobileno LIKE '" + name + "%' ) ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable zReferaluserid(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg where referal = '" + id + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getddlcities(string id)
    {
        try
        {
            string SQLQuery = "select * from tbl_cities where stateid =" + id;

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable zGetcountdata(string uid)
    {
        try
        {
            string SQLQuery = "select count(*) as countinvit from tbl_invitefriends where inivted_user='" + uid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable zGetexceldata(string userid)
    {
        try
        {
            string SQLQuery = "select* from test_contacts where Reference='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable zGetProducts()
    {
        try
        {
            string SQLQuery = "select * from tbl_Products where pv_status='1'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable zGetemailcontactsuser(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_mailContacts where userid = '" + userid + "' and EmailAddress <> ''";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable zGetPaiduserdetails(string mobileno, string emailid, string verificationcode)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration_temporary where mobileno='" + mobileno + "' and emailid='" + emailid + "' and verificationcode='" + verificationcode + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void zInsertdialytips(string mobileno, string name, string emailid, string city)
    {
        try
        {

            string SQLQuery = "insert into tbl_dialytips(mobileno,name,emailid,city)values ('" + mobileno + "','" + name + "','" + emailid + "','" + city + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable zFreeuserexist(string mobileno)
    {
        try
        {
            string SQLQuery = "Select * from tbl_invitefriends where mobileno='" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable zFreemembuserexist(string mobileno)
    {
        try
        {
            string SQLQuery = "Select * from tbl_freememreg where mobileno='" + mobileno + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable zFreeuserexist1(string email)
    {
        try
        {
            string SQLQuery = "Select * from tbl_freememreg where emailid='" + email + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable zPaiduserexist(string mobileno)
    {
        try
        {
            string SQLQuery = "Select * from tbl_registration where  mobileno='" + mobileno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable zpaiduserexist1(string emailid)
    {
        try
        {
            string SQLQuery = "Select * from tbl_registration where emailid='" + emailid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }


    public void insertcontact(string EnquiryOptions, string name, string mobileno, string emailid, string comments)
    {
        try
        {

            //string SQLQuery = "insert into tbl_contactinformation(EnquiryOptions,name,mobileno,emailid,comments)values ('" + EnquiryOptions + "','" + name + "','" + mobileno + "','" + emailid + "','" + comments + "')";
            string SQLQuery = "USP_Bite2Byte_insertcontact   '" + EnquiryOptions + "','" + name + "','" + mobileno + "','" + emailid + "','" + comments + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable countinvite(string inivted_user)
    {
        try
        {
            string SQLQuery = "Select count(inivted_user) as sentinvit from tbl_invitefriends where inivted_user='" + inivted_user + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable acceptinvit(string mobileno)
    {
        try
        {
            string SQLQuery = "select count(*) as accept from tbl_invitefriends inner join tbl_registration on tbl_invitefriends.mobileno= tbl_registration.mobileno where inivted_user='" + mobileno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable zTodayinvitations(string mobileno)
    {
        try
        {
            string SQLQuery = "select count(*) as todayinvit from tbl_invitefriends where invited_date='" + mobileno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public DataTable zGetsentinvit(string userid)
    {
        try
        {
            string SQLQuery = "select mobileno, fname, city, invited_date, placement from tbl_invitefriends where inivted_user='" + userid + "' ";
            //string SQLQuery = "USP_Getsentinvit '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable getcountinvetations(string uid)
    {
        try
        {
            string SQLQuery = "select * from tbl_invitefriends where inivted_user='" + uid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }
    public DataTable getActiveInvetationsByReferalID(string sReferalId)
    {
        //Created by Sudhindra on 16-Jul-2014. Purpose : to get all active invitation details
        try
        {
            string SQLQuery = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME , EMAILID , ";
            SQLQuery = SQLQuery + " REFERAL_MOBILE, REFERALID, JOINDATE, USERID, ACTIVEUSER, ";
            SQLQuery = SQLQuery + " FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, SPONSORUSERID, ";
            SQLQuery = SQLQuery + " IS_TERMS_AGREED, STATE, CITY,IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED  FROM ALL_MEMBERS_VIEW WHERE REFERALID = '" + sReferalId + "' AND ACTIVEUSER = 'A'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }



    public DataTable getAllMembersByReferralId(string sRefferalid, bool ActivatedOnly = false)
    {
        // This method written by Sudhindra on 10-Jul-2014. Purpose : to get all the members data based on the referal id.
        try
        {
            string sQry = "SELECT * FROM ALL_MEMBERS_VIEW V LEFT OUTER JOIN TBL_INVITEFRIENDS I ON V.MOBILENO = I.MOBILENO WHERE I.INIVTED_USER ='" + sRefferalid + "' ";
            if (ActivatedOnly == true)
            {
                sQry = sQry + "  AND V.ACTIVEUSER = 'A'";
            }
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable getMemberDetailsFromInvitation(string sInviteeMobileID, string sReferalID)
    {
        try
        {
            string sQry = "SELECT V.MOBILENO, V.USERPWD, V.NAME, V.EMAILID, V.REFERAL_MOBILE, V.REFERALID, V.JOINDATE , CAST(V.JOINDATE AS DATETIME) JOINDATE_DT_FORMAT, V.USERID ";
            sQry = sQry + " , V.ACTIVEUSER, V.FIRSTLOG, V.PLACEMENT, V.PLACEMENTID, V.IS_TERMS_AGREED, V.ACTIVATION_DATE, V.AFFILIATE_DATE, V.UPGRADED_PAID_DEACTIVE ";
            sQry = sQry + " , I.GENDER, I.AGEGROUP, I.AREA, I.ADDRESS, I.PINCODE, I.STATE STATE_ID, I.DISTRICT DISTRICT_ID, I.CITY CITY_ID, I.OCCUPATION, I.CHECKEDITEM, I.INVITED_THROUGH  ";
            sQry = sQry + " , V.IS_PROFILE_PIC_UPLOADED, V.IS_PASSWORD_CHANGED, V.IS_PROFILE_UPDATED, v.IS_FULLY_ACTIVATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW V ";
            sQry = sQry + " LEFT OUTER JOIN TBL_INVITEFRIENDS I ON V.MOBILENO = I.MOBILENO ";
            sQry = sQry + " WHERE I.MOBILENO ='" + sInviteeMobileID + "' AND REFERID = '" + sReferalID + "' ";

            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getMemberDetailsFromInvitation(string sUserID)
    {
        try
        {
            string sQry = "SELECT V.MOBILENO, V.USERPWD, V.NAME, V.EMAILID, V.REFERAL_MOBILE, V.REFERALID, V.JOINDATE , CAST(V.JOINDATE AS DATETIME) JOINDATE_DT_FORMAT, V.USERID ";
            sQry = sQry + " , V.ACTIVEUSER, V.FIRSTLOG, V.PLACEMENT, V.PLACEMENTID, V.IS_TERMS_AGREED, V.ACTIVATION_DATE, V.AFFILIATE_DATE, V.UPGRADED_PAID_DEACTIVE ";
            sQry = sQry + " , I.GENDER, I.AGEGROUP, I.AREA, I.ADDRESS, I.PINCODE, I.STATE STATE_ID, I.DISTRICT DISTRICT_ID, I.CITY CITY_ID, I.OCCUPATION, I.CHECKEDITEM, I.INVITED_THROUGH  ";
            sQry = sQry + " , V.IS_PROFILE_PIC_UPLOADED, V.IS_PASSWORD_CHANGED, V.IS_PROFILE_UPDATED, V.IS_FULLY_ACTIVATED ";
            sQry = sQry + " , V.INVALID_DATA_STATUS ";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW V ";
            sQry = sQry + " LEFT OUTER JOIN TBL_INVITEFRIENDS I ON V.USERID = I.USERID ";
            sQry = sQry + " WHERE V.USERID = '" + sUserID + "' ";

            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable zGetUserName(string Userid)
    {
        try
        {
            string SQLquery = "select name, referalid  from all_members_view where userid = '" + Userid + "'";
            return GetDataTable(SQLquery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }




    public DataTable GetMembersDetailsByUserID(string sUserID)
    {

        // This method written by Sudhindra on 31-Jul-2014. Purpose : to get the members details based on the user id.
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID, JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE , ISNULL(IS_FULLY_ACTIVATED , 0) IS_FULLY_ACTIVATED";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE USERID = '" + sUserID + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public DataTable GetActiveMembersDetailsByMobileNo(string sMobileNo)
    {

        try
        {
            string sQry = "SELECT SNO, USERID, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERAL_ID, JOINDATE, ACTIVE_STATUS, PLACEMENT, PLACEMENTID, ISNULL(UPGRADED_PAID_DEACTIVE, 0 )UPGRADED_PAID_DEACTIVE, ISNULL(IS_TERMS_AGREED, 0) IS_TERMS_AGREED, ACTIVATION_DATE, ISNULL(IS_PROFILE_PIC_UPLOADED , 0) IS_PROFILE_PIC_UPLOADED, ISNULL(IS_PASSWORD_CHANGED, 0) IS_PASSWORD_CHANGED, ISNULL(IS_MOBILE_VERIFIED, 0) IS_MOBILE_VERIFIED, ISNULL(IS_FULLY_ACTIVATED , 0) IS_FULLY_ACTIVATED, ISNULL(IS_PROFILE_UPDATED , 0) IS_PROFILE_UPDATED, ACTIVATED_THROUGH, GENDER, AGEGROUP";
            sQry = sQry + " , AREA, ADDRESS, PINCODE, CITY, DISTRICT, STATE, OCCUPATION, CHECKEDITEM, INVITED_USER_STATUS, INVITED_THROUGH, CREATED_DT, IMAGE_NAME";
            sQry = sQry + " FROM TBL_ACTIVE_USERS WHERE MOBILENO = '" + sMobileNo + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public DataTable GetActiveMembersDetailsByUserID(string sUserID)
    {

        try
        {
            string sQry = "SELECT SNO, USERID, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERAL_ID, JOINDATE, ACTIVE_STATUS, PLACEMENT, PLACEMENTID, ISNULL(UPGRADED_PAID_DEACTIVE, 0 )UPGRADED_PAID_DEACTIVE, ISNULL(IS_TERMS_AGREED, 0) IS_TERMS_AGREED, ACTIVATION_DATE, ISNULL(IS_PROFILE_PIC_UPLOADED , 0) IS_PROFILE_PIC_UPLOADED, ISNULL(IS_PASSWORD_CHANGED, 0) IS_PASSWORD_CHANGED, ISNULL(IS_MOBILE_VERIFIED, 0) IS_MOBILE_VERIFIED, ISNULL(IS_FULLY_ACTIVATED , 0) IS_FULLY_ACTIVATED, ISNULL(IS_PROFILE_UPDATED , 0) IS_PROFILE_UPDATED, ACTIVATED_THROUGH, GENDER, AGEGROUP";
            sQry = sQry + " , AREA, ADDRESS, PINCODE, CITY, DISTRICT, STATE, OCCUPATION, CHECKEDITEM, INVITED_USER_STATUS, INVITED_THROUGH, CREATED_DT, IMAGE_NAME";
            sQry = sQry + " FROM TBL_ACTIVE_USERS WHERE USERID = '" + sUserID + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable GetMembersDetailsByMobileNum(string sMobileNo)
    {

        // This method written by Sudhindra on 31-Jul-2014. Purpose : to get the members details based on the user id.
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID, JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE MOBILENO = '" + sMobileNo + "' AND INVALID_DATA_STATUS=0";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public DataTable GetDetailsBy_MobileNum_OR_Email(string sMobileNo)
    {

        // This method written by Sudhindra on 31-Jul-2014. Purpose : to get the members details based on the user id.
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID, JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE (MOBILENO = '" + sMobileNo + "' OR emailid='" + sMobileNo + "') AND activeuser='a' ";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable GetMembersDetailsByMobileNum(string sUserMobileNo, string sRefMobileNo)
    {

        // This method written by Sudhindra on 31-Jul-2014. Purpose : to get the members details based on the user id.
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID, JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE MOBILENO = '" + sUserMobileNo + "' AND REFERAL_MOBILE = '" + sRefMobileNo + "' AND INVALID_DATA_STATUS=0";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable GetMembersDetailsByUserRefIDs(string sUserID, string sRefID)
    {

        // This method written by Sudhindra on 04-Mar-2014. Purpose : to get the members details based on the user id and referalid.
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID, JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE USERID = '" + sUserID + "' AND REFERALID = '" + sRefID + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }



    public DataTable GetMembersDetailsByEmailID(string sEmailID)
    {

        // This method written by Sudhindra on 31-Jul-2014. Purpose : to get the members details based on the user id.
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID, JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE EMAILID = '" + sEmailID + "' AND INVALID_DATA_STATUS = 0";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    public DataTable GetEmailIDActiveStatus(string sEmailID)
    {

        // This method written by Sudhindra on 31-Jul-2014. Purpose : to get the members details based on the user id.
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID, JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE EMAILID = '" + sEmailID + "' AND ACTIVEUSER = 'A' ";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable CheckEmailDuplicacy(string sMobileno, string sEmailId)
    {
        // This method written by Sudhindra on 11-Aug-2014. Purpose : Checking if the mail id is using by any other persons
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID, JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE EMAILID = '" + sEmailId + "' AND MOBILENO <> '" + sMobileno + "'   AND MOBILENO <> '' AND INVALID_DATA_STATUS=0";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetNotActiveMembers()
    {
        // all not active members
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID,";
            sQry = sQry + " JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, ";
            sQry = sQry + " SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE ACTIVEUSER='NA' AND USERID NOT IN (select  userid from dbo.TBL_EMAIL_SENT_LOG where purpose = 'Quantum Badge Greetings') ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public DataTable GetNotActiveMembers(string sRefID)
    {
        // all not active members of the refferal ID
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID,";
            sQry = sQry + " JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, ";
            sQry = sQry + " SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE REFERALID = '" + sRefID + "' AND ACTIVEUSER='NA' and INVALID_DATA_STATUS = 0";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw;
        }
    }


    public DataTable getInvitationData(string sRefID)
    {
        // all not active members of the refferal ID
        try
        {
            string sQry = " SELECT  null image,name fullname, null activation_date , mobileno, userid ";
            sQry = sQry + " FROM tbl_freememreg ";
            sQry = sQry + " WHERE REFERALID = '" + sRefID + "' AND ACTIVEUSER='NA' and INVALID_DATA_STATUS = 0 ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw;
        }
    }


    public DataTable GetNotActiveMembers(string sRefID, string sMobileNo)
    {
        // all not active members of the refferal ID

        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID,";
            sQry = sQry + " JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, ";
            sQry = sQry + " SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE MOBILENO = '" + sMobileNo + "' AND REFERALID = '" + sRefID + "' AND ACTIVEUSER='NA'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public DataTable GetSentTime(string sUid)
    {
        try
        {
            string sQry = "SELECT SNO, PURPOSE, USERID, TO_ADDRESS, MAIL_CONTENT, SENT_TIME,  ";
            sQry = sQry + " DATEDIFF(MINUTE,SENT_TIME,GETDATE()) MINUTES_DIFF, DATEDIFF(HOUR,SENT_TIME,GETDATE()) HOURS_DIFF, DATEDIFF(DAY,SENT_TIME,GETDATE()) DAYS_DIFF,  DATEDIFF(MONTH,SENT_TIME,GETDATE())  MONTH_DIFF ";
            sQry = sQry + " FROM TBL_EMAIL_SENT_LOG WHERE PURPOSE IN ('INVITATION MAIL BULK SENDING','EVENT INVITATION MAIL') AND USERID='" + sUid + "'";
            sQry = sQry + " ORDER BY SENT_TIME DESC";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public DataTable GetSentTimeByUserAndPurpose(string sUid, string sPurpose)
    {
        try
        {
            string sQry = "SELECT SNO, USERID, TO_ADDRESS, MAIL_CONTENT, SENT_TIME,  ";
            sQry = sQry + " DATEDIFF(MINUTE,SENT_TIME,GETDATE()) MINUTES_DIFF, DATEDIFF(HOUR,SENT_TIME,GETDATE()) HOURS_DIFF, DATEDIFF(DAY,SENT_TIME,GETDATE()) DAYS_DIFF,  DATEDIFF(MONTH,SENT_TIME,GETDATE())  MONTH_DIFF ";
            sQry = sQry + " FROM TBL_EMAIL_SENT_LOG WHERE USERID='" + sUid + "' AND PURPOSE = '" + sPurpose + "'";
            sQry = sQry + " ORDER BY SENT_TIME DESC";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public void inserlogincount(string userid, string logindate, string logincount, string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_assuredlogincount(userid,logindate,logincount,status) values ('" + userid + "','" + logindate + "','" + logincount + "','" + status + "')";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable zGetsentinvitfreeuser(string userid)
    {
        try
        {
            string SQLQuery = "select mobileno, fname, city, invited_date,placement from tbl_invitefriends where inivted_user='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable zGetacceptinvit(string userid)
    {
        try
        {
            string SQLQuery = "  select tbl_registration.mobileno, fullname, tbl_registration.emailid, invited_date from tbl_invitefriends inner join tbl_registration on tbl_invitefriends.mobileno= tbl_registration.mobileno where inivted_user='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable zGetTodayinvitations(string mobileno)
    {
        try
        {
            string SQLQuery = "select mobileno, fname, emailid, invited_date as todayinvit from tbl_invitefriends where invited_date='" + mobileno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable zGetLeaderconstitution()
    {
        try
        {
            string SQLQuery = "select * from tbl_MPconstituency";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable zGetParty()
    {
        try
        {
            string SQLQuery = "select * from tbl_party";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable zGetLeader()
    {
        try
        {
            string SQLQuery = "select * from tbl_leader";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable zGetRefer()
    {
        try
        {
            string SQLQuery = "select * from tbl_refer";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void zInsertvote(string state, string leaderconstitution, string party, string leader, string refer, string rank)
    {
        try
        {

            string SQLQuery = "insert into tbl_vote(state,leaderconstitution,party,leader,refer, rank)values ('" + state + "','" + leaderconstitution + "','" + party + "','" + leader + "','" + refer + "', '" + rank + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Getddlreflevelno(string referal_id)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg  where mobileno = '" + referal_id + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable Enteridea(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration  where userid = '" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }



    public DataTable getFreeMemRegData_byUseID(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_freememreg  where userid = '" + userid + "'";

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }

    }

    public void inserideapaid(string idea, string userid, string mobileno, string name, string usertype)
    {
        try
        {
            //string SQLQuery = "insert into tbl_writeidea (idea,userid,mobileno,name,memtype,date) values ('" + idea + "','" + userid + "','" + mobileno + "','" + name + "','" + usertype + "','" + DateTime.Now.ToString() + "')";
            string SQLQuery = "USP_BIT2BYTE4_inserideapaid'" + idea + "','" + userid + "','" + mobileno + "','" + name + "','" + usertype + "','" + DateTime.Now.ToString() + "'";



            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable Enterideanon(string mobileno)
    {
        try
        {
            string sqlquery = "Select * from tbl_nonmemreg where mobileno='" + mobileno + "'";
            return GetDataTable(sqlquery, true);
        }
        catch (Exception EX)
        {
            throw EX;
        }
    }
    public void inserideanonmem(string idea, string userid, string mobileno, string name, string usertype)
    {
        try
        {
            //string SQLQuery = "insert into tbl_writeidea (idea,userid,mobileno,name,memtype,date) values ('" + idea + "','" + userid + "','" + mobileno + "','" + name + "','" + usertype + "','" + DateTime.Now.ToString() + "')";
            string SQLQuery = "USP_BIT2BYTE4_inserideanonmem '" + idea + "','" + userid + "','" + mobileno + "','" + name + "','" + usertype + "','" + DateTime.Now.ToString() + "'";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void inserideafree(string idea, string userid, string mobileno, string name, string usertype)
    {
        try
        {
            //string SQLQuery = "insert into tbl_writeidea (idea,userid,mobileno,name,memtype,date) values ('" + idea + "','" + userid + "','" + mobileno + "','" + name + "','" + usertype + "','" + DateTime.Now.ToString() + "')";
            string SQLQuery = " USP_BIT2BYTE4_inserideafree'" + idea + "','" + userid + "','" + mobileno + "','" + name + "','" + usertype + "','" + DateTime.Now.ToString() + "'";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void zUpdatePlacement(string placement, string mobileno)
    {
        try
        {
            string SQLQuery = string.Concat("update tbl_freememreg set placement='", placement, "' where mobileno='", mobileno, "'");
            SQLQuery = string.Concat(SQLQuery, " update tbl_invitefriends set placement='", placement, "' where mobileno='", mobileno, "'");

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void free_updateusersel(string userid)    ///update status for free member after accepting the terms & conditions for free affiliate
    {
        try
        {
            string SQLQuery = "update tbl_freememreg set is_terms_agreed='1' where userid='" + userid + "' ";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public void regisration_updateusersel(string userid)         ///update status for premium member after accepting the terms & conditions for free affiliate
    {
        try
        {
            string SQLQuery = "update tbl_registration set is_terms_agreed='1' where userid='" + userid + "' ";

            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable Getprofilestatus(string userid)
    {
        try
        {
            string SQLQuery = "SELECT *FROM tbl_editprofile WHERE" +
                "((ISNULL(name,'')='') or" +
                "(ISNULL(gender,'')='') or" +
                "(ISNULL(country,'')='') or" +
                "(ISNULL(state,'')='') or" +
                "(ISNULL(district,'')='') or" +
                "(ISNULL([city/area],'')='') or" +
                "(ISNULL(education,'')='') or" +
                "(ISNULL(occupation,'')='')or" +
                "  (ISNULL(industry,'')='')or" +
                "(ISNULL(incomerange,'')='')or" +
                " (ISNULL(address,'')='')or  " +
                "(ISNULL(postalcode,'')='')or" +
                "(ISNULL(checkeditem,'')=''))" +
                "and userid='" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable CheckUserValidations(string sReferID, string sMobileNo, string sEmailId)
    {
        try
        {
            string sQry = "exec dbo.USP_INVITE_FRIEND_VALIDATIONS '" + sReferID + "', '" + sMobileNo + "', '" + sEmailId + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    /*   Modified By Ganga  Purpose: Check the Email id is activated or not and current user is invited or not  */

    public DataTable CheckUserValidations(string sReferID, string sEmailId)
    {
        try
        {
            string sQry = "exec dbo.USP_INVITATION_EMAIL_VALIDATIONS '" + sReferID + "','" + sEmailId + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /*   End  */
    public DataTable GetRegionDetails(string sStateID, string sDistID, string sCityID)
    {
        try
        {
            string sQry = "SELECT STATE_ID, STATE_NAME, DIST_ID, DIST_NAME , CITY_ID , CITY_NAME, CITY_PINCODE FROM STATE_DISTRICT_CITY_VIEW ";
            sQry = sQry + " WHERE STATE_ID = '" + sStateID + "' AND DIST_ID = '" + sDistID + "' AND CITY_ID = '" + sCityID + "'";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public void updatePlacement(string MobileNO, string EmailID, string UserPSWD, string sUserID)
    {
        try
        {
            string SQLQuery = " USP_UpdateNonActiveMem '" + MobileNO + "','" + EmailID + "','" + UserPSWD + "' , '" + sUserID + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void updateUserInfo(string sUserID, string sMobileNO, string sEmailID, string sName, string sFrom = "")
    {
        try
        {
            General genobj = new General();
            home clsHome = new home();

            if (genobj.IsValidMobileNo(sMobileNO) == false || genobj.IsValidEmail(sEmailID) == false)
                return;
            /*
            string SQLQuery = " UPDATE TBL_FREEMEMREG SET MOBILENO = '" + sMobileNO + "', NAME = '" + sName + "',	EMAILID = '" + sEmailID + "' WHERE USERID = '" + sUserID + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);


            clsHome.UpdateSqlTrace(sUserID, "Updating the mobilenumber in freememreg while activation-" + sFrom, "Rows Effected :" + intRowAffect.ToString());

            SQLQuery = " UPDATE TBL_INVITEFRIENDS SET MOBILENO = '" + sMobileNO + "', FNAME ='" + sName + "' , EMAILID = '" + sEmailID + "' WHERE USERID= '" + sUserID + "'";
            intRowAffect = fnExecuteNonQuery(SQLQuery, true);
            clsHome.UpdateSqlTrace(sUserID, "Updating the mobilenumber in invitefriends while activation-" + sFrom, "Rows Effected :" + intRowAffect.ToString());
            */

            string[] strArrList = { "@MOBILENO", "@NAME", "@EMAILID", "@USERID", "@FROM" };
            string[] strArrValues = { sMobileNO, sName, sEmailID, sUserID, sFrom };
            int intRowAffect = fnRunProcedure("USP_UPDATE_USER_REGISTRATION_DETAILS", strArrList, strArrValues, true);

        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void RefreshUserCountersByUserID(string sUserID)
    {
        try
        {

            string[] strArrList = { "@USERID" };
            string[] strArrValues = { sUserID };
            int intRowAffect = fnRunProcedure("USP_REFRESH_USER_INVITATIONS_DATA_USER_WISE", strArrList, strArrValues, true);


        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public void UpdateEmailSentLog(string sPurpose, string sUserId, string sToAddress, string sMailContent)
    {
        try
        {
            string sQry = "INSERT INTO TBL_EMAIL_SENT_LOG(PURPOSE , USERID , TO_ADDRESS , MAIL_CONTENT) VALUES ('" + sPurpose + "', '" + sUserId + "','" + sToAddress + "','" + sMailContent.Replace("'", "`") + "')";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable CheckMailSentLog(string sUserID, string sPurpose)
    {
        try
        {
            string sQry = "SELECT * FROM TBL_EMAIL_SENT_LOG WHERE PURPOSE = '" + sPurpose + "' AND USERID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateLuckyDrawDetails(string sDrawID, string sUserID)
    {
        try
        {
            string sQry = "INSERT INTO TBL_LUCKY_DRAW_USER_DETAILS(DRAW_ID, USER_ID) VALUES ('" + sDrawID + "', '" + sUserID + "')";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetActiveLuckyDrawDetails()
    {

        try
        {
            string sQry = "SELECT DRAW_ID, DRAW_DESCRIPTION, DRAW_CONSIDER_FROM_DATE, DRAW_CONSIDER_TO_DATE, DRAW_TOKEN_SUFFIX, IS_ACTIVE ";
            sQry = sQry + " FROM TBL_LUCKY_DRAW_MASTER WHERE IS_ACTIVE = 1 AND DRAW_CONSIDER_FROM_DATE = (SELECT MAX(DRAW_CONSIDER_FROM_DATE) FROM TBL_LUCKY_DRAW_MASTER WHERE IS_ACTIVE = 1 AND DRAW_CONSIDER_FROM_DATE <= GETDATE() ) ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getAccounedLuckyDrawDetails()
    {
        try
        {
            string sQry = "SELECT DRAW_ID , DRAW_DESCRIPTION , DRAW_ANNOUNCED_DATE , DRAW_CONSIDER_FROM_DATE , DRAW_CONSIDER_TO_DATE , DRAW_TOKEN_SUFFIX , IS_ACTIVE FROM TBL_LUCKY_DRAW_MASTER WHERE IS_ACTIVE = 1 AND DRAW_ANNOUNCED_DATE <= GETDATE()  AND DRAW_CONSIDER_TO_DATE >= GETDATE()";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable getTokenByUserID(string sDrawID, string sUserID)
    {
        try
        {
            string sQry = "SELECT TOKEN_NO FROM TBL_LUCKY_DRAW_USER_DETAILS WHERE USER_ID = '" + sUserID + "' AND ISNULL(TOKEN_NO , '') != '' AND DRAW_ID = '" + sDrawID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GenerateLuckyDrawNewToken()
    {
        try
        {
            string sQry = "SELECT DBO.USP_GENERATE_LUCKYDRAW_NEW_TOKEN() TOKEN_NO";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable GetUserStatus(string sUserID)
    {
        try
        {
            string sQry = "Select DBO.FN_GET_USER_STATUS(" + sUserID + ") USER_STATUS";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateUserLoginTime(string sUserID)
    {
        try
        {

            string sQry = "INSERT INTO TBL_USER_LOGIN_LOGOUT_TIMES(USERID) VALUES ('" + sUserID + "')";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateUserLoginTime(string sUserID, string ipAddress)
    {
        try
        {
            WebClient wc = new WebClient();
            string res = wc.DownloadString("https://freegeoip.net/xml/" + ipAddress);
            string CountryCode = res.Substring(res.IndexOf("<CountryCode>") + 13, res.IndexOf("</CountryCode>") - res.IndexOf("<CountryCode>") - 13);
            string CountryName = res.Substring(res.IndexOf("<CountryName>") + 13, res.IndexOf("</CountryName>") - res.IndexOf("<CountryName>") - 13);
            string RegionName = res.Substring(res.IndexOf("<RegionName>") + 12, res.IndexOf("</RegionName>") - res.IndexOf("<RegionName>") - 12);
            string City = res.Substring(res.IndexOf("<City>") + 6, res.IndexOf("</City>") - res.IndexOf("<City>") - 6);
            string Latitude = res.Substring(res.IndexOf("<Latitude>") + 10, res.IndexOf("</Latitude>") - res.IndexOf("<Latitude>") - 10);
            string Longitude = res.Substring(res.IndexOf("<Longitude>") + 11, res.IndexOf("</Longitude>") - res.IndexOf("<Longitude>") - 11);
            res = "";
            res = res + "CountryCode: " + CountryCode;
            res = res + " CountryName: " + CountryName;
            res = res + " RegionName: " + RegionName;
            res = res + " City: " + City;
            res = res + " Latitude: " + Latitude;
            res = res + " Longitude: " + Longitude;

            string sQry = "INSERT INTO TBL_USER_LOGIN_LOGOUT_TIMES(USERID, IP_ADDR, GEOLOCATION) VALUES ('" + sUserID + "' , '" + ipAddress + "','" + res + "')";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void Update_LogIn_Status(string sUID)
    {
        try
        {
            string SQry = "update TBL_ACTIVE_USERS set IS_AVAILABLE_FOR_CHAT=1 where userid='" + sUID + "'";
            int RowAffect = fnExecuteNonQuery(SQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void UpdateUserLogOutTime(string logout_time, string sUserID)
    {
        try
        {
            string sQry = "update TBL_USER_LOGIN_LOGOUT_TIMES set LOGOUT_TIME='" + logout_time + "' WHERE USERID='" + sUserID + "'";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void Update_Logout_Status(string sUID)
    {
        try
        {
            string SQry = "update TBL_ACTIVE_USERS set IS_AVAILABLE_FOR_CHAT=0 where userid='" + sUID + "'";
            int RowAffect = fnExecuteNonQuery(SQry, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertRequestForDeactivation(string sUserID)
    {
        try
        {
            string sQry = "INSERT INTO TBL_DEACTIVATION_REQUEST(USER_ID) VALUES('" + sUserID + "')";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable GetDeactivationRequests()
    {
        try
        {
            string sQry = "SELECT USER_ID, REQUESTED_DATE FROM TBL_DEACTIVATION_REQUEST ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetDeactivationRequestsByUser(string sUserID)
    {
        try
        {
            string sQry = "SELECT USER_ID, REQUESTED_DATE FROM TBL_DEACTIVATION_REQUEST WHERE USER_ID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable GetActiveMembers()
    {
        // all  active members
        try
        {
            string sQry = "SELECT MEMBER_STATUS, SNO, MOBILENO, USERPWD, NAME, EMAILID, REFERAL_MOBILE, REFERALID,";
            sQry = sQry + " JOINDATE, USERID, ACTIVEUSER, FIFTYSTATUS, FIRSTLOG, PLACEMENT, PLACEMENTID, ";
            sQry = sQry + " SPONSORUSERID, IS_TERMS_AGREED, STATE, CITY, ACTIVATION_DATE ";
            sQry = sQry + " , IS_PROFILE_PIC_UPLOADED, IS_PASSWORD_CHANGED, IS_PROFILE_UPDATED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW WHERE ACTIVEUSER='A' AND USERID NOT IN (select  userid from dbo.TBL_EMAIL_SENT_LOG where purpose = 'Quantum Badge Greetings')";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public DataTable GetReferalTreeBetweenUsers(string sFromUserID, string sToUserID)
    {


        try
        {
            string sQry = "SELECT USERID, FULLNAME, MOBILENO, REFERALID FROM FN_REFERAL_TREE_BETWEEN_USERS('" + sFromUserID + "','" + sToUserID + "') ORDER BY CALCULATED_LEVEL_NO DESC";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }

    /* Added By Ganga Purpuse: Retreiving user details based on userID   */

    public DataTable eMailTemplateDetails(int iTemplateID)
    {
        try
        {
            string SQLQuery = "SELECT TEMPLATE_ID, EMAIL_SUBJECT, BODY, LINK , DESCRIPTION, EMAILTEMPLATE_NAME, TYPE_OF_EMAIL, HTML_TEMPLATENAME FROM TBL_EMAILTEMPLATES WHERE TEMPLATE_ID = " + iTemplateID.ToString();

            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertDailyHoroscopeDetails(DateTime dtHoroDate, string sZodiacSign, string sPrediction, string sLink)
    {
        try
        {
            string[] strArrList = { "@HORO_DATE", "@ZODIAC_SIGN", "@PREDICTION", "@LINK" };
            string[] strArrValues = { dtHoroDate.ToString("yyyy-MM-dd"), sZodiacSign, sPrediction, sLink };
            int intRowAffect = fnRunProcedure("USP_DAILY_HOROSCOPE_INSERT_UPDATE", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable GetDailyHoroscopeDetails(DateTime dtHoroDate)
    {
        try
        {
            string sQry = "SELECT ZODIAC_SIGN , PREDICTION , LINK FROM TBL_DAILY_HOROSCOPE WHERE HORO_DATE = '" + dtHoroDate.ToString("yyyy-MM-dd") + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void InsertAboutUser(string sUserID, string About)
    {
        try
        {
            string sQry = "INSERT INTO TBL_USER_ADDITIONAL_INFO(USERID,ABOUT_ME) VALUES('" + sUserID + "','" + About + "')";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateAboutUser(string sUserID, string About)
    {
        try
        {
            string sQry = "UPDATE TBL_USER_ADDITIONAL_INFO SET ABOUT_ME='" + About + "' WHERE USERID='" + sUserID + "'";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void InsertUserAdditionalInfo(string sUserID, string sZodiacSign)
    {
        try
        {
            string[] strArrList = { "@USERID", "@ZODIAC_SIGN" };
            string[] strArrValues = { sUserID, sZodiacSign };
            int intRowAffect = fnRunProcedure("USP_USER_ADDITIONAL_INFO_INSERT_UPDATE", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable GetUserAdditionalInfo(string sUserID)
    {
        try
        {
            string sQry = "SELECT USERID,DEFAULT_ZODIAC_SIGN,IS_VALID_AFFILIATE_IMAGE,ABOUT_ME,IS_UNSUBSCRIBED FROM TBL_USER_ADDITIONAL_INFO WHERE USERID = '" + sUserID + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetDailyHoroscopeByUserID(string sUserID)
    {
        try
        {
            string sQry = "SELECT HORO_DATE, ZODIAC_SIGN, PREDICTION, LINK FROM TBL_DAILY_HOROSCOPE WHERE CONVERT(VARCHAR(100), HORO_DATE, 112) = CONVERT(VARCHAR(100), GETDATE(), 112)";
            sQry = sQry + " AND ZODIAC_SIGN = (SELECT DEFAULT_ZODIAC_SIGN FROM TBL_USER_ADDITIONAL_INFO WHERE USERID = '" + sUserID + "')";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetApprovedAffiliates()
    {
        try
        {
            string sQry = "SELECT USERID,IS_VALID_AFFILIATE_IMAGE FROM TBL_USER_ADDITIONAL_INFO WHERE IS_VALID_AFFILIATE_IMAGE =1";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public void InsertAffiliateData(string UserID, int Status)
    {

        try
        {
            string sQry = "insert into TBL_USER_ADDITIONAL_INFO(USERID,IS_VALID_AFFILIATE_IMAGE) values('" + UserID + "'," + Status + ")";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public void UpdateAffiliateData(string UserID, int Status)
    {

        try
        {
            string sQry = "update TBL_USER_ADDITIONAL_INFO set IS_VALID_AFFILIATE_IMAGE=" + Status + " where USERID='" + UserID + "'";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable GetAllDailyHoroscopeDetailsByUserID(string sUserID)
    {
        try
        {
            string sQry = "SELECT PRIORITY, ORDER_PRIORITY, HORO_DATE, ZODIAC_SIGN, PREDICTION, LINK ";
            sQry = sQry + " FROM ( ";
            sQry = sQry + " SELECT 1 PRIORITY, 0 ORDER_PRIORITY, HORO_DATE, ZODIAC_SIGN, PREDICTION, LINK FROM TBL_DAILY_HOROSCOPE WHERE CONVERT(VARCHAR(100), HORO_DATE, 112) = CONVERT(VARCHAR(100), GETDATE(), 112) ";
            sQry = sQry + " AND ZODIAC_SIGN = (SELECT DEFAULT_ZODIAC_SIGN FROM TBL_USER_ADDITIONAL_INFO WHERE USERID = '" + sUserID + "') ";
            sQry = sQry + " UNION ";
            sQry = sQry + " SELECT 2 PRIORITY, CASE WHEN ZODIAC_SIGN = 'Aries'THEN 1 WHEN ZODIAC_SIGN = 'Taurus' THEN 2 WHEN ZODIAC_SIGN = 'Gemini' THEN 3 WHEN ZODIAC_SIGN = 'Cancer' THEN 4 WHEN ZODIAC_SIGN = 'Leo' THEN 5 ";
            sQry = sQry + " WHEN ZODIAC_SIGN = 'Virgo' THEN  6 WHEN ZODIAC_SIGN = 'Libra' THEN 7 WHEN ZODIAC_SIGN = 'Scorpio' THEN 8 WHEN ZODIAC_SIGN = 'Sagittarius' THEN 9 WHEN ZODIAC_SIGN = 'Capricorn' THEN 10 WHEN ZODIAC_SIGN = 'Aquarius' THEN 11 WHEN ZODIAC_SIGN = 'Pisces' THEN 12 END, HORO_DATE, ZODIAC_SIGN, PREDICTION, LINK FROM TBL_DAILY_HOROSCOPE WHERE CONVERT(VARCHAR(100), HORO_DATE, 112) = CONVERT(VARCHAR(100), GETDATE(), 112) ";
            sQry = sQry + " AND ZODIAC_SIGN != (SELECT DEFAULT_ZODIAC_SIGN FROM TBL_USER_ADDITIONAL_INFO WHERE USERID = '" + sUserID + "') ";
            sQry = sQry + " ) AS DFL  WHERE DFL.ORDER_PRIORITY IS NOT NULL ";
            sQry = sQry + " ORDER BY DFL.PRIORITY DESC, DFL.ORDER_PRIORITY DESC ";

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetImmediateAffiliate(string sUserID)
    {
        try
        {
            string sQry = "SELECT  top 1  USERID, FULLNAME, MOBILENO, REFERALID FROM DBO.FN_REFERAL_TREE_UPLINE_USERS_FROM_ACTIVE('" + sUserID + "') where USERID not in ('4398541153143120','" + sUserID + "')  and DBO.FN_GET_USER_STATUS(USERID) in( 'fa','pa') ";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetEventDetails(string sEventID, string sCriteria)
    {
        try
        {

            // Note : Don't ad any column names in the select statement. This query is being used in EventStattics.cs file by using AutoColumn to assign grid.

            string sQry = "SELECT V.USERID, V.MOBILENO, V.NAME, V.EMAILID,  CONVERT(VARCHAR(30), E.MAIL_SENT_DATE, 106)  MAIL_SENT_DATE";

            if (sCriteria == "ALL" || sCriteria == "REQUESTED" || sCriteria == "PASS_ISSUED")
            {
                sQry = sQry + " , E.IS_PASS_REQUESTED AS REQUESTED,  CONVERT(VARCHAR(30), E.PASS_REQUESTED_DATE, 106)  REQUESTED_DATE ";
            }

            if (sCriteria == "ALL" || sCriteria == "PASS_ISSUED")
            {
                sQry = sQry + " , E.IS_PASS_ISSUED AS ISSUED,   CONVERT(VARCHAR(30), E.PASS_ISSUED_DATE, 106)  ISSUED_DATE ,  E.PASS_ID ";
            }

            sQry = sQry + " FROM TBL_EVENT_USER_DETAILS E";
            sQry = sQry + " INNER JOIN ALL_MEMBERS_VIEW V ON E.USER_ID = V.USERID ";
            sQry = sQry + " WHERE EVENT_ID = " + sEventID + "";

            if (sCriteria == "REQUESTED")
            {
                sQry = sQry + " AND ISNULL(E.IS_PASS_REQUESTED , 0) = 1";
            }

            if (sCriteria == "PASS_ISSUED")
            {
                sQry = sQry + " AND ISNULL(E.IS_PASS_ISSUED, 0) = 1 ";
            }

            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateMailSentFlag(string sMailId, string sReferID)
    {

        try
        {
            string sQry = "UPDATE TBL_INVITEFRIENDS SET IS_MAIL_SENT = 1 WHERE EMAILID = '" + sMailId + "' and INVITED_THROUGH = 'M' and referid = '" + sReferID + "'";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }


    }


    public void UpdateInvitationMailSentFlag(string sUserID)
    {

        try
        {
            string sQry = "UPDATE TBL_INVITEFRIENDS SET IS_MAIL_SENT = 1 WHERE USERID = '" + sUserID + "'";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }


    }

    public void UpdateRegionInformation(string sUserID, string sStateID, string sDistID, string sCityID, string sPinCode)
    {
        try
        {
            string sQry = "UPDATE TBL_INVITEFRIENDS SET STATE= '" + sStateID + "', DISTRICT = '" + sDistID + "', CITY='" + sCityID + "', PINCODE='" + sPinCode + "' WHERE USERID = '" + sUserID + "'";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);

            sQry = "UPDATE TBL_FREEMEMREG SET STATE= '" + sStateID + "', CITY='" + sCityID + "' WHERE USERID = '" + sUserID + "'";
            iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void InsertAccountsManager(General.Accounts_Manager accManager, string sRequest)
    {
        try
        {
            string[] strArrList = { "@EMAIL_ID", "@MOBILE_NO", "@DESCRIPTION", "@LINK", "@COMPANYNAME_DESIGNATION", "@REQUEST" };
            string[] strArrValues = { accManager.Email_ID, accManager.Mobile_No, accManager.Description, accManager.CompanyOrOrganisation, accManager.Link, sRequest };
            int intRowAffect = fnRunProcedure("SP_ACCOUNTS_MANAGER", strArrList, strArrValues, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void InsertAffiliatesManager(General.Affiliates_Manager affManager, string sRequest)
    {
        try
        {
            string[] strArrList = { "@NAME", "@EMAIL_ID", "@MOBILE_NO", "@DESCRIPTION", "@REQUEST" };
            string[] strArrValues = { affManager.Name, affManager.Email_ID, affManager.Mobile_No, affManager.Description, sRequest };
            int intRowAffect = fnRunProcedure("SP_AFFILIATES_MANAGER", strArrList, strArrValues, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void UpdateMailNotSentStatus(string sUserID)
    {
        try
        {
            string sQry = "UPDATE TBL_INVITEFRIENDS SET IS_MAIL_SENT = 0 WHERE USERID = '" + sUserID + "'";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable CheckMailSentLogByMailID(string sEmailID, string sPurpose)
    {

        try
        {
            string sQry = "SELECT * FROM TBL_EMAIL_SENT_LOG WHERE TO_ADDRESS = '" + sEmailID + "' AND PURPOSE = '" + sPurpose + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {

            throw;
        }
    }


    public string resendInactiveMail(string userId, string userDetails)
    {
        try
        {
            string SQLQuery = "EXEC DBO.USP_UPDATE_RESEND_INVITATION   '" + userId + "', '" + userDetails + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
            string ACTIVITY = "RESEND INVITATION BULK SENDING";
            return GetResultTraceResult(userId, ACTIVITY);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public string GetResultTraceResult(string userId, string ACTIVITY)
    {
        try
        {
            return GetSingleValue("SELECT TOP 1 TRACE FROM TBL_SQL_TRACE WHERE USERID = '" + userId + "' AND ACTIVITY =  '" + ACTIVITY + "' ORDER BY TRACE_TIME DESC", true);
        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    public void UpdateSqlTrace(string sUserId, string sActivity, string sTrace)
    {
        try
        {
            string sQry = "INSERT INTO TBL_SQL_TRACE(USERID, ACTIVITY, TRACE) VALUES ('" + sUserId + "', '" + sActivity + "', '" + sTrace + "')";
            int iRowsEffected = fnExecuteNonQuery(sQry, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    //  Added By Ganga Purpose: Updating the status for removing the inactive users
    public int UpdateInvalid_data_statusInactive(string suid)
    {
        int intRowAffect = 0;
        try
        {
            //string sQry = "EXEC USP_ACTIVATE_NEW_USER '" + sUserID + "'";
            //int intRowAffect = fnExecuteNonQuery(sQry, true);

            string[] strArrList = { "@uid" };
            string[] strArrValues = { suid };
            intRowAffect = fnRunProcedure("USP_DeleteClick_InActive_User", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return intRowAffect;
    }
    //  End Of Updating the status for removing the inactive users


    public void UpdateRequestForUnsubscription(string sUserid)
    {
        try
        {

            string[] strArrList = { "@USERID", "@ACTIVITY" };
            string[] strArrValues = { sUserid, "UNSUBSCRIBE" };
            int intRowAffect = fnRunProcedure("USP_EMAIL_UNSUBSCRIBE", strArrList, strArrValues, true);


        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable GetUserAdditionInfo_ByEmailID(string sEmailID)
    {
        try
        {
            string sQry = "SELECT V.MEMBER_STATUS, V.MOBILENO, V.NAME, V.EMAILID, V.REFERAL_MOBILE, V.REFERALID, V.JOINDATE, V.USERID, V.ACTIVEUSER, V.PLACEMENT,";
            sQry = sQry + " V.PLACEMENTID, V.IS_TERMS_AGREED, V.STATE, V.CITY, V.ACTIVATION_DATE, V.AFFILIATE_DATE, V.UPGRADED_PAID_DEACTIVE,";
            sQry = sQry + " V.IS_FULLY_ACTIVATED, V.IS_PROFILE_PIC_UPLOADED, V.IS_PASSWORD_CHANGED, V.IS_PROFILE_UPDATED, V.INVALID_DATA_STATUS,";
            sQry = sQry + " I.DEFAULT_ZODIAC_SIGN, I.ABOUT_ME, I.IS_VALID_AFFILIATE_IMAGE, I.IS_UNSUBSCRIBED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW V INNER JOIN TBL_USER_ADDITIONAL_INFO I ON V.USERID = I.USERID ";
            sQry = sQry + " WHERE EMAILID = '" + sEmailID + "'";

            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable GetUserIssubscribedinfo(string sEmailID)
    {
        try
        {
            string sQry = "SELECT V.MEMBER_STATUS, V.MOBILENO, V.NAME, V.EMAILID, V.REFERAL_MOBILE, V.REFERALID, V.JOINDATE, V.USERID, V.ACTIVEUSER, V.PLACEMENT,";
            sQry = sQry + " V.PLACEMENTID, V.IS_TERMS_AGREED, V.STATE, V.CITY, V.ACTIVATION_DATE, V.AFFILIATE_DATE, V.UPGRADED_PAID_DEACTIVE,";
            sQry = sQry + " V.IS_FULLY_ACTIVATED, V.IS_PROFILE_PIC_UPLOADED, V.IS_PASSWORD_CHANGED, V.IS_PROFILE_UPDATED, V.INVALID_DATA_STATUS,";
            sQry = sQry + " I.DEFAULT_ZODIAC_SIGN, I.ABOUT_ME, I.IS_VALID_AFFILIATE_IMAGE, I.IS_UNSUBSCRIBED";
            sQry = sQry + " FROM ALL_MEMBERS_VIEW V INNER JOIN TBL_USER_ADDITIONAL_INFO I ON V.USERID = I.USERID ";
            sQry = sQry + " WHERE EMAILID = '" + sEmailID + "' and I.IS_UNSUBSCRIBED = 1";

            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void CreateNewUser(string sUserID, string sReferalID, string sName, string sGender, string sAgeGroup, string sMobileNo,
                                string sEmailID, string sArea, string sAddress, string sPinCode, string sState,
                                string sDistrict, string sCity, string sOccupation, string sCheckedItems, string sInvitedDate,
                                string sReferalStatus, string sPlacement, string sReferalMobileNo, string sInvitedThrough)
    {
        try
        {

            string[] strArrList = { "@USERID", "@REFERAL_ID" , "@NAME", "@GENDER", "@AGEGROUP", "@MOBILENO", 
                                    "@EMAILID" , "@AREA", "@ADDRESS", "@PINCODE", "@STATE", 
                                    "@DISTRICT", "@CITY" , "@OCCUPATION","@CHECKEDITEM" , "@INVITED_DATE",
                                    "@REFERAL_STATUS", "@PLACEMENT", "@REFERAL_MOBILENO" , "@INVITED_THROUGH"};


            string[] strArrValues = { sUserID, sReferalID, sName, sGender, sAgeGroup, sMobileNo, 
                                    sEmailID, sArea, sAddress, sPinCode, sState,
                                    sDistrict, sCity, sOccupation, sCheckedItems, sInvitedDate,
                                    sReferalStatus,  sPlacement, sReferalMobileNo, sInvitedThrough };

            int intRowAffect = fnRunProcedure("USP_CREATE_NEW_USER", strArrList, strArrValues, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable GetDetails_invitee(string userid)
    {
        try
        {
            string sQry = "select v.referalID refid, v2.emailid refemail,v2.name name, v.userid userid,v.name activename, DBO.FN_GET_DETAILS_BY_USERID(v.userid, 'CITY') activecity,img.imagename activeimage, DBO.FN_GET_DETAILS_BY_USERID(v.userid, 'OCCUPATION') activeoccupation from ALL_MEMBERS_VIEW v";
            sQry = sQry + " inner join  tbl_imagedetail img on v.userid = img.userid ";
            sQry = sQry + " inner join ALL_MEMBERS_VIEW v2 on v.referalID = v2.userid ";
            sQry = sQry + " where v.userid  = '" + userid + "'";
            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public DataTable GetApprovedAffiliatesforEvents(string userid)
    {
        try
        {
            string sQry = "select * from tbl_registration where ";
            sQry = sQry + " userid in( select USER_ID from TBL_EVENT_USER_DETAILS ";
            sQry = sQry + " where EVENT_ID in(select EVENT_ID from TBL_EVENTS_MASTER where PASSES_END_DATE >= GETDATE()) )";
            sQry = sQry + " and userid = '" + userid + "'";
            return GetDataTable(sQry, true);

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public DataTable AffiliateClosedNetwork(string Affiliateid, string filter1, string filter2)
    {
        try
        {
            //string sQry = "select USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, JOINDATE ,IMAGE , REFERID, REF_NAME, ";
            string sQry = "select USERID , FULLNAME ,  CASE WHEN REFERID = '" + Affiliateid + "' THEN MOBILENO ELSE '' END  MOBILENO, CASE WHEN REFERID = '" + Affiliateid + "' THEN EMAILID ELSE '' END EMAILID , PLACEMENT, JOINDATE ,IMAGE , REFERID, REF_NAME, ";
            sQry = sQry + " PRODUCTTYPE , MEMBER_STATUS , UPGRADED_PAID_DEACTIVE, ACTIVESTATUS , ACTIVATION_DATE, AFFILIATE_DATE";
            sQry = sQry + " from dbo.FN_USER_TREE_AFFILIATE_ALL_NETWORK_MEMBERS('" + Affiliateid + "') ";
            sQry = sQry + " WHERE ACTIVESTATUS = '" + filter1 + "' or ACTIVESTATUS = '" + filter2 + "'";
            return GetDataTable(sQry, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public DataTable deactivatestatus(string uid)
    {
        string sQry = "SELECT DEACTIVATION_DATE FROM TBL_DEACTIVATION_REQUEST WHERE USER_ID='" + uid + "'";
        return GetDataTable(sQry, true);
    }
    public void deactivate_Users()
    {
        string sQry = "EXEC USP_DEACTIVATE_USERS";
        fnExecuteNonQuery(sQry, true);
    }

    public string GetDetailsByUserID(string sUserID, string sCriteria)
    {
        try
        {
            string sRetVal = "";
            string sQry = "SELECT DBO.FN_GET_DETAILS_BY_USERID('" + sUserID + "', '" + sCriteria + "') VAL";
            DataTable dt = GetDataTable(sQry, true);
            if (dt.Rows.Count > 0)
            {
                sRetVal = dt.Rows[0]["VAL"].ToString();
            }
            else
            {
                sRetVal = "";
            }
            return sRetVal;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public bool isOptinVerified(string sMobileNo)
    {
        bool sRetVal = false;
        string sQry = "SELECT MOBILENO, MSG, RECEIVED_ON FROM TBL_OPTIN_INBOX WHERE RIGHT(RTRIM(MOBILENO),10) = '" + sMobileNo + "'";
        DataTable dt = GetDataTable(sQry, true);
        if (dt.Rows.Count > 0)
        {
            sRetVal = true;
        }

        return sRetVal;
    }
    public DataTable isOld_Images_Updated_Click(string userid)
    {
        string Qry = "SELECT Old_Images_Updated FROM TBL_IMAGEDETAIL WHERE USERID='" + userid + "'";
        return GetDataTable(Qry, true);
    }
    public void isOld_Images_Updated(string userid)
    {
        string Qry = "UPDATE TBL_IMAGEDETAIL SET Old_Images_Updated=1 WHERE userid='" + userid + "'";
        fnExecuteNonQuery(Qry, true);
    }

    public bool bCheckRecentActivation(string sMobileNo)
    {
        try
        {
            bool retVal = false;

            string sQry = "SELECT * FROM TBL_FREEMEMREG WHERE ACTIVEUSER = 'A' AND MOBILENO = RIGHT('" + sMobileNo + "', 10) AND ACTIVATION_DATE >= '2015-04-02'";
            sQry = sQry + " AND MOBILENO IN (SELECT RIGHT(MOBILENO,10) FROM TBL_OPTIN_INBOX WHERE RIGHT(MOBILENO,10) = RIGHT('" + sMobileNo + "',10))";
            DataTable dt = new DataTable();
            dt = GetDataTable(sQry, true);
            if (dt.Rows.Count > 0)
            {
                retVal = true;
            }
            return retVal;
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }
    public void InsertLinkTrace(string userid, string purpose, string UserAgent, string url)
    {
        try
        {
            string SQLQuery = "INSERT INTO TBL_LINK_TRACE(USERID, PURPOSE, IPADDRESS, DEVICEUSED, URL) VALUES ('" + userid + "','" + purpose + "','" + GetUser_IP() + "','" + UserAgent + "','" + url + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public string GetUser_IP()
    {
        string VisitorsIPAddr = string.Empty;
        if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
        {
            VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
        }
        else if (HttpContext.Current.Request.UserHostAddress.Length != 0)
        {
            VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
        }
        return VisitorsIPAddr;
    }
}
