﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for dlrreceipt
/// </summary>
public class dlrreceipt : BaseClass
{
	public dlrreceipt()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable checkaccount(string macount)
    {
        try
        {
            string query = "Select * from tbl_pindealerregistration where MobileNo='" + macount + "' or account_no='" + macount + "'";
            return GetDataTable(query, true);
                

        }
        catch (Exception EX)
        {
            throw EX;

        }
    }

     public DataTable GetDelearInfo()
    {
        try
        {
            string query = "Select * from tbl_reciptdlramount";
            return GetDataTable(query, true);
                

        }
        catch (Exception EX)
        {
            throw EX;

        }
    }
    

    public void insertdlramt(string dlrmblno,string dlraccount, string sno,string amt, string receiptno, string checqno, string bankname,string remarks, string pincancel,string checkcancl,string paidtime)
    {
        try
        {
            //string query = "insert into tbl_reciptdlramount (dlrmblno,dlraccountno,dlrsno,amount,receiptno,cheqno,bankname,remarks,pincancel,checkcancel,insertime,amountpaidtime) values('" + dlrmblno + "','" + dlraccount + "','" + sno + "','" + amt + "','" + receiptno + "','" + checqno + "','" + bankname + "','" + remarks + "','" + pincancel + "','" + checkcancl + "','" + DateTime.Now.ToString() + "','" + paidtime + "')";
            string query = " USP_insertdlramt '" + dlrmblno + "','" + dlraccount + "','" + sno + "','" + amt + "','" + receiptno + "','" + checqno + "','" + bankname + "','" + remarks + "','" + pincancel + "','" + checkcancl + "','" + DateTime.Now.ToString() + "','" + paidtime + "'";
            int rowaffect = fnExecuteNonQuery(query, true);


        }
        catch (Exception EX)
        {
            throw EX;

        }
    }

    public DataTable getdlrdetail(string accountno)
    {
        try
        {
            string query = "Select * from tbl_pindealerregistration where account_no='" + accountno + "'";
            return GetDataTable(query, true);


        }
        catch (Exception EX)
        {
            throw EX;

        }
    }

    public DataTable delear_users(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as int)) as amount from tbl_delrpintransfer where dealerid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable delearamount(string userid)
    {
        try
        {
            string SQLQuery = "select sum(cast(Amount as int)) as amount from tbl_admingenerate_pin where accountno = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable delearpaidamount(string dlraccountno)
    {
        try
        {
            string SQLQuery = "select sum(cast(amount as int)) as amount from tbl_reciptdlramount where dlraccountno = '" + dlraccountno + "' or dlrmblno='" + dlraccountno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public void dlrpindeduct(string dealrid, string dlrname, string dlremailid, string dlrmbl, string amount,  string accountno, string transactionid, string Description, string Remainingamt, string amountdeduct)
    {
        try
        {
            string query = "insert into tbl_delrpintransfer(dealerid,name,emailid,mobile,amount,generatedate,accountno,transactionid,Description,Remainingamt,amountdeduct) values('" + dealrid + "','" + dlrname + "','" + dlremailid + "','" + dlrmbl + "','" + amount + "','" + DateTime.Now.ToString() + "','" + accountno + "','" + transactionid + "','" + Description + "','" + Remainingamt + "','" + amountdeduct + "')";
            int rowaffect = fnExecuteNonQuery(query, true);


        }
        catch (Exception EX)
        {
            throw EX;

        }
    }

}