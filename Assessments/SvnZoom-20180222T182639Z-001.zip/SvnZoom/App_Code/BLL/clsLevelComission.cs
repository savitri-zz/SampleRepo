﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;


/// <summary>
/// Summary description for clsLevelComission
/// </summary>
public class clsLevelComission : BaseClass
{
	public clsLevelComission()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable BindLevelCmns(string TableName,string ColumnName, string sponcerID)
    {
        try
        {
            string SQLQuery = "select * from  " + TableName + " where " + ColumnName + "='" + sponcerID + "' order by sno asc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable BindLevelCmns1(string referal_id)
    {
        try
        {
            string SQLQuery = "select * from  tbl_freememreg where userid='" + referal_id + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable BindLevelCmns2(string referal_mobile)
    {
        try
        {
            string SQLQuery = "select * from  tbl_freememreg where referal_mobile='" + referal_mobile + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable BindLevelCmns3(string mobileno)
    {
        try
        {
            string SQLQuery = "select * from  tbl_registration where SponsorUserID='" + mobileno + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable BindLevelCmnsSNO(string TableName, string ColumnName, string SNO)
    {
        try
        {
            string SQLQuery = "select * from  " + TableName + " where " + ColumnName + ">'" + SNO + "' order by sno asc";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void zDeleteLevelCmns(string TableName, string ColumnName, string sponcerID)
    {
        try
        {
            string SQLQuery = "delete from " + TableName + " where " + ColumnName + "='" + sponcerID + "'";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void DeleteLevelCmns1()
    {
        try
        {
            string SQLQuery = "delete from tbl_LevelCommission";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertLevelCmns(string userid, string Name, string Mobileno, string Levelno, string SId, string Percentage, string Data, string DOJ, string SearchUserid)
    {
        try
        {
            string SQLQuery = "insert into tbl_LevelCommission (userid,Name,Mobileno,Levelno,SId,Percentage,Data,DOJ,SearchUserid) values('" + userid + "','" + Name + "','" + Mobileno + "','" + Levelno + "','" + SId + "','" + Percentage + "','" + Data + "','" + DOJ + "','" + SearchUserid + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetLevelComission()
    {
        try
        {
            string SQLQuery = "select * from  tbl_LevelCommission order by CAST(Levelno as int) ASC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetInviteFrds(string inivted_user)
    {
        try
        {
            string SQLQuery = "select * from  tbl_invitefriends where inivted_user='" + inivted_user + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetReferralId(string userid)
    {
        try
        {
            string SQLQuery = "select * from  tbl_registration where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public DataTable GetNonReferralId(string userid)
    {
        try
        {
            string SQLQuery = "select * from  tbl_nonmemreg where userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    
   }