﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for clsGeneologyPlacement
/// </summary>
public class clsGeneologyPlacement : BaseClass
{
    protected string strNodevalue = "";
    protected string strSubnodevalue = "";
    protected string strUserIDS = "";
    protected int strUserIDSCount = 0;
    protected string strTotalBVSum = "";
    protected int strBVTotal = 0;
    protected DateTime strjoindate;
	public clsGeneologyPlacement()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetplacementrefInactiveMem(string refid)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_Userwalletstatus.walletstatus = '0' and tbl_registration.userid='" + refid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryDatewisePayout_Mem(string date)
    {       
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_Userwalletstatus.walletstatus = '0' and CAST(tbl_registration.joindate as DATE) <=  '" + date + "' order by CAST(tbl_registration.joindate as DATE) DESC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }



    public DataTable GetBinaryReferids(string refid, string placement)
    {
        try
        {
           string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  where";
            SQLQuery = SQLQuery + "  tbl_registration.placementid ='" + refid + "' and  tbl_registration.placement = '" + placement + "'   order by CAST(tbl_registration.joindate as DATETIME) ASC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryPlacementids(string refid, string placement)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where placementid='" + refid + "' and placement='" + placement + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryReferids_WithDates(string refid, string placement, string JoinDate)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.referid=tbl_Userwalletstatus.useid and tbl_registration.placementid='" + refid + "' and tbl_registration.placement='" + placement + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) =  '" + JoinDate + "' order by CAST(tbl_registration.joindate as DATE) asc ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryReferids_WithEqualDates(string refid, string JoinDate)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.referid=tbl_Userwalletstatus.useid and tbl_registration.referid='" + refid + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) =  '" + JoinDate + "' order by CAST(tbl_registration.joindate as DATE) asc   ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryReferids_EqualDates(string refid, string JoinDate)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_registration.userid='" + refid + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) =  '" + JoinDate + "' order by CAST(tbl_registration.joindate as DATE) asc   ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable fnDTParentNodes(string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where userid = '" + userid + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryDatewisePayout_Active(string userid, string date)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  where ";
            SQLQuery = SQLQuery + "  tbl_registration.userid='" + userid + "' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) <=  '" + date + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetBinaryDatewisePayout(string userid, string date)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  INNER JOIN tbl_Userwalletstatus ON ";
            SQLQuery = SQLQuery + " tbl_registration.userid=tbl_Userwalletstatus.useid and tbl_registration.userid='" + userid + "' and tbl_Userwalletstatus.walletstatus = '0' ";
            SQLQuery = SQLQuery + " and CAST(tbl_registration.joindate as DATE) <=  '" + date + "' ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable fnDTSubNodes(string placementid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_registration where placementid = '" + placementid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }
    public string fnMainNode(string sno, string strJoinDate)
    {
        strUserIDS = "";
        DataTable dt = new DataTable();
        dt = fnDTParentNodes(sno);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                strNodevalue = row["userid"].ToString();

                fnSubNode(strNodevalue, strJoinDate);
            }
        }

        return strUserIDS.ToString();
    }

    public void fnSubNode(string strNodevalues, string strJoinDate)
    {
        DataTable dt1 = new DataTable();
        dt1 = fnDTSubNodes(strNodevalues.ToString());
        if (dt1.Rows.Count > 0)
        {
            foreach (DataRow dr in dt1.Rows)
            {
                strSubnodevalue = dr["userid"].ToString();

                // strjoindate = Convert.ToDateTime(dr["joindate"].ToString());
                DataTable memActivatedStatus = GetBinaryDatewisePayout(strSubnodevalue.ToString(), strJoinDate.ToString());
                if (memActivatedStatus.Rows.Count > 0)
                {
                    strUserIDS = strUserIDS + strSubnodevalue + ",";
                }
                fnSubNode(strSubnodevalue.ToString(), strJoinDate);
            }
        }
    }




    public string fnTotalBVCalc(string strTotalBV, string strJoinDate)
    {
        strBVTotal = 0;
        if (strTotalBV.Length != 0)
        {
            strTotalBVSum = strTotalBV.Substring(0, strTotalBV.Length - 1);
            string[] strInputArray = strTotalBVSum.Split(',');
            for (int i = 0; i < strInputArray.Length; i++)
            {
                DataTable dtUserDate = GetBinaryDatewisePayout(strInputArray[i], strJoinDate.ToString());
                if (dtUserDate.Rows.Count > 0)
                {
                    DataTable dtbvleft = new DataTable();
                    dtbvleft = getproductBVsum(dtUserDate.Rows[0]["producttype"].ToString());
                    if (dtbvleft.Rows.Count > 0)
                    {
                        strBVTotal = strBVTotal + Convert.ToInt32(dtbvleft.Rows[0]["BV"].ToString());
                    }
                }
            }
        }

        return strBVTotal.ToString();
    }

    public string fnTotalMemCalc(string strTotalBV, string strJoinDate)
    {
        strUserIDSCount = 0;
        if (strTotalBV.Length != 0)
        {
            strTotalBVSum = strTotalBV.Substring(0, strTotalBV.Length - 1);
            string[] strInputArray = strTotalBVSum.Split(',');
            for (int i = 0; i < strInputArray.Length; i++)
            {
                DataTable dtUserDate = GetBinaryDatewisePayout(strInputArray[i], strJoinDate.ToString());
                if (dtUserDate.Rows.Count > 0)
                {
                    strUserIDSCount = strUserIDSCount + 1;
                }
            }
        }
        return strUserIDSCount.ToString();
    }


    public string fnTotalBVCalc_EqualsBV(string strTotalBV, string strJoinDate)
    {
        strBVTotal = 0;
        if (strTotalBV.Length != 0)
        {
            strTotalBVSum = strTotalBV.Substring(0, strTotalBV.Length - 1);
            string[] strInputArray = strTotalBVSum.Split(',');
            for (int i = 0; i < strInputArray.Length; i++)
            {
                DataTable dtUserDate = GetBinaryReferids_EqualDates(strInputArray[i], strJoinDate.ToString());
                if (dtUserDate.Rows.Count > 0)
                {
                    DataTable dtbvleft = new DataTable();
                    dtbvleft = getproductBVsum(dtUserDate.Rows[0]["producttype"].ToString());
                    if (dtbvleft.Rows.Count > 0)
                    {
                        strBVTotal = strBVTotal + Convert.ToInt32(dtbvleft.Rows[0]["BV"].ToString());
                    }
                }
            }
        }

        return strBVTotal.ToString();
    }


    public DataTable getproductBVsum(string productid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Products where sno = '" + productid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetPayoutdeatils(string PayoutDate, string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Binarypayout_Bystep where PayoutDate = '" + PayoutDate + "' and userid='" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetCarryforwardValue(string PayoutDate, string userid)
    {
        try
        {
            string SQLQuery = "SELECT * FROM tbl_Binarypayout_Bystep where PayoutDate = '" + PayoutDate + "' and userid='" + userid + "' order by cast(PayoutDate as date) DESC";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void InsertPayputDetails(string PayoutDate, string userid, string Name, string Mobileno, string TLBV, string TRBV, string CLBV, string CRBV, string CFL, string CFR, string NetBV, string EBV, string CV, string BeforeDeductionNetAmt, string DeductionAmt, string PW, string PayabeAmt, string UpdatePayout, string status)
    {
        try
        {
            string SQLQuery = "insert into tbl_Binarypayout_Bystep(PayoutDate, userid, Name, Mobileno,TLBV,TRBV,CLBV,CRBV,CFL,CFR,NetBV,EBV,CV,BeforeDeductionNetAmt,DeductionAmt,PW, PayabeAmt,UpdatePayout,status) values ('" + PayoutDate + "','" + userid + "','" + Name + "','" + Mobileno + "','" + TLBV + "','" + TRBV + "','" + CLBV + "','" + CRBV + "','" + CFL + "','" + CFR + "','" + NetBV + "','" + EBV + "','" + CV + "','" + BeforeDeductionNetAmt + "','" + DeductionAmt + "','" + PW + "','" + PayabeAmt + "','" + UpdatePayout + "','" + status + "')";
            int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    //public void UpadatePayputDetails(string Name, string Mobileno, string TLBV, string TRBV, string CLBV, string CRBV, string CFL, string CFR, string NetBV, string EBV, string CV, string BeforeDeductionNetAmt, string DeductionAmt, string PW, string PayabeAmt, string UpdatePayout, string status,string PayoutDate, string userid)
    //{
    //    try
    //    {
    //        string SQLQuery = "update tbl_Binarypayout_Bystep set Name='" + Name + "', Mobileno='" + Mobileno + "',TLBV='" + TLBV + "',TRBV='" + TRBV + "',CLBV='" + CLBV + "',CRBV='" + CRBV + "',CFL='" + CFL + "',CFR='" + CFR + "',NetBV='" + NetBV + "',EBV='" + EBV + "',CV='" + CV + "',BeforeDeductionNetAmt='" + BeforeDeductionNetAmt + "',DeductionAmt='" + DeductionAmt + "',PW='" + PW + "',PayabeAmt='" + PayabeAmt + "',,UpdatePayout='" + UpdatePayout + "', status='" + status + "' where PayoutDate='" + PayoutDate + "' and  userid='" + userid + "')";
    //        int intRowAffect = fnExecuteNonQuery(SQLQuery, true);
    //    }
    //    catch (Exception Ex)
    //    {
    //        throw Ex;
    //    }
    //}



    public DataTable getreferedname1(string userid)
    {
        try
        {
            string SQLQuery = "select * from tbl_registration where userid = '" + userid + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public List<DateTime> GetDateRange(DateTime StartingDate, DateTime EndingDate)
    {
        if (StartingDate > EndingDate)
        {
            return null;
        }
        List<DateTime> rv = new List<DateTime>();
        DateTime tmpDate = StartingDate;
        do
        {
            rv.Add(tmpDate);
            tmpDate = tmpDate.AddDays(5);
        } while (tmpDate <= EndingDate);
        rv.Sort(delegate(DateTime x, DateTime y) { return y.CompareTo(x); });
        return rv;
    }


    public List<DateTime> GetPayoutDates_ASC(DateTime StartingDate, DateTime EndingDate)
    {
        if (StartingDate > EndingDate)
        {
            return null;
        }
        List<DateTime> rv = new List<DateTime>();
        DateTime tmpDate = StartingDate;
        do
        {
            rv.Add(tmpDate);
            tmpDate = tmpDate.AddDays(1);
        } while (tmpDate <= EndingDate);
        rv.Sort(delegate(DateTime x, DateTime y) { return y.CompareTo(x); });
        rv.Reverse();
        return rv;
    }

    public string fnMainNode_FirstLevel(string sno, string strJoinDate)
    {
        strUserIDS = "";
        DataTable dt = new DataTable();
        dt = fnDTParentNodes(sno);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                strNodevalue = row["userid"].ToString();
                fnSubNode_firstLevel(strNodevalue, strJoinDate);
            }
        }

        return strUserIDS.ToString();
    }

    public void fnSubNode_firstLevel(string strNodevalues, string strJoinDate)
    {
        DataTable dt1 = new DataTable();
        dt1 = fnDTSubNodes(strNodevalues.ToString());
        if (dt1.Rows.Count > 0)
        {
            foreach (DataRow dr in dt1.Rows)
            {
                strSubnodevalue = dr["userid"].ToString();
                // strjoindate = Convert.ToDateTime(dr["joindate"].ToString());
                DataTable memActivatedStatus = GetBinaryReferids_EqualDates(strSubnodevalue.ToString(), strJoinDate.ToString());
                if (memActivatedStatus.Rows.Count > 0)
                {
                    strUserIDS = strUserIDS + strSubnodevalue + ",";
                }
                fnSubNode_firstLevel(strSubnodevalue.ToString(), strJoinDate);
            }
        }
    }


    ///////////////////////added//////////////////////////////////////////////////////////////////////////

    public DataTable GetBinaryReferids_all(string refid)
    {
        try
        {
            string SQLQuery = " SELECT tbl_registration.userid as userid, tbl_registration.joindate as joindate,tbl_registration.placement as placement,tbl_registration.sno as ";
            SQLQuery = SQLQuery + " sno,tbl_registration.producttype as producttype,tbl_registration.fullname as fullname, ";
            SQLQuery = SQLQuery + " tbl_registration.mobileno as mobileno FROM tbl_registration  where";
            SQLQuery = SQLQuery + "  tbl_registration.placementid ='" + refid + "' order by CAST(tbl_registration.joindate as DATETIME) ASC ";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }


    public DataTable GetBinaryDatewisePayout_Active_all(string uid, string date)
    {      
        // Query modified by Sudhindra on 24-Jun-2014. Purpose : Used alias names for more readability 
        try
        {
            string SQLQuery = " SELECT r.userid , r.joindate , r.sno , r.producttype , r.fullname , r.mobileno , i.imagename as image  ";
            SQLQuery = SQLQuery + " FROM tbl_registration r INNER JOIN tbl_imagedetail i ON  r.userid = i.userid ";
            SQLQuery = SQLQuery + " where r.referid = '" + uid + "' and CAST(r.joindate as DATE) <=  '" + date + "'";
            return GetDataTable(SQLQuery, true);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public DataTable GetRegistrationDetails_By_RefID(string refID)
    {
        try
        {

            /*

            string sQuery = "SELECT USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, LEVELNO, CONVERT(VARCHAR(11), JOINDATE , 113) JOINDATE, REFERID,  REF_NAME , IMAGENAME AS IMAGE  ";
            sQuery += " , TLBV, TRBV, CFL, CFR, NETBV, CAST(ISNULL(TLBV ,0) AS INT) + CAST(ISNULL(TRBV, 0) AS INT) TOT_TBV, CAST(ISNULL(CFL ,0 ) AS INT) + CAST(ISNULL(CFR , 0 ) AS INT) TOT_CBV , NO_OF_INVITES";
            sQuery += " , USER_STATUS  , ISNULL(PRODUCTTYPE , '0') PRODUCTTYPE , MEMBER_STATUS , UPGRADED_PAID_DEACTIVE";
            sQuery += " FROM mfloatdb.REGISTRION_DETAILS_VIEW ";
            sQuery += " WHERE REFERID = '" + refID + "'   AND ACTIVESTATUS ='A' AND MEMBER_STATUS = 'PAID_MEMBER' ";
            sQuery += " ORDER BY JOINDATE ";
             
             
            string sQuery = "SELECT USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, LEVELNO, CONVERT(VARCHAR(11), JOINDATE , 113) JOINDATE, REFERID,  REF_NAME , IMAGENAME AS IMAGE  ";
            sQuery += " , TLBV, TRBV, CFL, CFR, NETBV, CAST(ISNULL(TLBV ,0) AS INT) + CAST(ISNULL(TRBV, 0) AS INT) TOT_TBV, CAST(ISNULL(CFL ,0 ) AS INT) + CAST(ISNULL(CFR , 0 ) AS INT) TOT_CBV , NO_OF_INVITES";
            sQuery += " , USER_STATUS  , ISNULL(PRODUCTTYPE , '0') PRODUCTTYPE , MEMBER_STATUS , UPGRADED_PAID_DEACTIVE";
            sQuery += " , CASE WHEN USER_STATUS IN ('P','PA')  THEN (SELECT SUM(BV) FROM FN_GENEOLOGY_TREE(USERID)) ELSE 0 END  as TOT_BV,  CASE WHEN USER_STATUS IN('P','PA') THEN (SELECT COUNT(*) FROM FN_GENEOLOGY_TREE(USERID)) ELSE 0 END as TOT_MEM";
            sQuery += " FROM REGISTRION_DETAILS_VIEW ";
            sQuery += " WHERE REFERID = '" + refID + "'   AND ACTIVESTATUS ='A' AND MEMBER_STATUS = 'PAID_MEMBER' ";
            sQuery += " ORDER BY JOINDATE ";
              
             */


            string sQuery = "SELECT F.USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, ACTUAL_LEVEL LEVELNO,  CONVERT(VARCHAR(11), JOINDATE , 113) JOINDATE, ";
            sQuery += " IMAGE   , REFERID,  REF_NAME , TLBV, TRBV, CFL, CFR, NETBV,  ";
            sQuery += " CAST(ISNULL(TLBV ,0) AS INT) + CAST(ISNULL(TRBV, 0) AS INT) TOT_TBV, CAST(ISNULL(CFL ,0 ) AS INT) + CAST(ISNULL(CFR , 0 ) AS INT) TOT_CBV ,  ";
            sQuery += " NO_OF_INVITES , USER_STATUS  , ISNULL(PRODUCTTYPE , '0') PRODUCTTYPE , MEMBER_STATUS , UPGRADED_PAID_DEACTIVE ,  ";
            sQuery += " CASE WHEN USER_STATUS IN ('P','PA')  THEN (SELECT SUM(BV) FROM FN_GENEOLOGY_TREE(F.USERID)) ELSE 0 END  AS TOT_BV,  "; 
            sQuery += " CASE WHEN USER_STATUS IN('P','PA') THEN (SELECT COUNT(*) FROM FN_GENEOLOGY_TREE(F.USERID)) ELSE 0 END AS TOT_MEM ,  ";
            sQuery += " CALCULATED_LEVEL, I.IMAGENAME REFER_IMAGE_NAME, F.OCCUPATION, F.CITY_NAME , USER_STATUS_DTLS  ";

            // This below line added by Sudhindra on 16-09-14. Purpose : display activation date instead of join date in the genealogy.
            sQuery += " , ACTIVATION_DATE ,  CONVERT(VARCHAR(11), ACTIVATION_DATE , 113) ACTIVATION_DATE_113 ";
            sQuery += " , NETWORK_NO_OF_AFFILIATES ";
            sQuery += " FROM FN_GENEOLOGY_TREE_ALL_NETWORK_MEMBERS('" + refID + "','PAID_MEMBER','A') F ";
        	sQuery += " INNER JOIN TBL_IMAGEDETAIL I ON F.REFERID = I.USERID  ";
            //sQuery += " WHERE REFERID = '" + refID + "' ";
            sQuery += " WHERE PLACEMENTID = '" + refID + "' ORDER BY ACTIVATION_DATE DESC";

            return GetDataTable(sQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    // This method is taking too much time to execute... Use GetMyAffiliatesDetails_fromActive_ByRefID instead of this
    public DataSet GetMyAffiliatesDetails_By_RefID(string refID)
    {
        try
        {

            string sQuery = "SELECT F.USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, ACTUAL_LEVEL LEVELNO,  CONVERT(VARCHAR(11), JOINDATE , 113) JOINDATE, ";
            sQuery += " IMAGE, REFERID,  REF_NAME ,  ";
            sQuery += " NO_OF_INVITES , USER_STATUS  , ISNULL(PRODUCTTYPE , '0') PRODUCTTYPE , MEMBER_STATUS , UPGRADED_PAID_DEACTIVE ,  ";
            sQuery += " CALCULATED_LEVEL, I.IMAGENAME REFER_IMAGE_NAME, F.OCCUPATION, F.CITY_NAME , USER_STATUS_DTLS  ";
            sQuery += " , ACTIVATION_DATE ,  CONVERT(VARCHAR(11), ACTIVATION_DATE , 113) ACTIVATION_DATE_113 ";
            sQuery += " ,ISNULL( NETWORK_NO_OF_AFFILIATES,0) NETWORK_NO_OF_AFFILIATES ";
            sQuery += " FROM FN_GENEOLOGY_TREE_VERSION_2('" + refID + "','PAID_MEMBER','A') F ";
            sQuery += " INNER JOIN TBL_IMAGEDETAIL I ON F.REFERID = I.USERID  ";
            sQuery += " WHERE PLACEMENTID = '" + refID + "' ORDER BY ACTIVATION_DATE DESC";

            return GetDataSet(sQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;   
        }
    }


    public DataSet GetMyAffiliatesDetails_fromActive_ByRefID(string refID)
    {
        try
        {

            string sQuery = "SELECT F.USERID, F.NAME fullname, F.MOBILENO, F.EMAILID, F.PLACEMENT, F.PLACEMENTID, F.REFERID, F.CALCULATED_LEVEL, F.CITY_ID, F.STATE_ID, ";
            sQuery = String.Concat(sQuery, " F.ACTIVATION_DATE,  CONVERT(VARCHAR(12),F.ACTIVATION_DATE, 113)   ACTIVATION_DATE_113, F.AFFILIATE_DATE , I.IMAGENAME [IMAGE], ");
            sQuery = String.Concat(sQuery, " C.CITY_NAME, O.OCCUPATION, ISNULL(D.NETWORK_NO_OF_AFFILIATES , 0) NETWORK_NO_OF_AFFILIATES ");
            sQuery = String.Concat(sQuery, " , CASE WHEN ISNULL(P.USERID , '') = '' THEN 'Affiliate' WHEN ISNULL(P.USERID , '') != '' THEN 'Premium Affiliate' END USER_STATUS_DTLS ");
            sQuery = String.Concat(sQuery, " FROM FN_GENEOLOGY_TREE_AFFILIATES('" + refID + "') F ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_IMAGEDETAIL I ON F.USERID = I.USERID ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_EDITPROFILE E ON F.USERID = E.USERID ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN CITIES C ON E.[CITY/AREA] = C.CITY_ID ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_OCCUPATION O ON E.OCCUPATION = O.ID  ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_USER_INVITATIONS_DATA D ON F.USERID = D.USERID ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_PREMIUM_AFFILIATES P ON F.USERID = P.USERID ");
            sQuery = String.Concat(sQuery, " WHERE PLACEMENTID = '" + refID + "' ORDER BY AFFILIATE_DATE DESC");
 
            return GetDataSet(sQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable GetDownLineAffiliatesDetails_fromActive_ByRefID(string refID)
    {
        try
        {

            string sQuery = "SELECT F.USERID, F.NAME fullname, F.MOBILENO, F.EMAILID, F.PLACEMENT, F.PLACEMENTID, F.REFERID, F.CALCULATED_LEVEL, F.CITY_ID, F.STATE_ID, ";
            sQuery = String.Concat(sQuery, " F.ACTIVATION_DATE,  CONVERT(VARCHAR(12),F.ACTIVATION_DATE, 113)   ACTIVATION_DATE_113, F.AFFILIATE_DATE , I.IMAGENAME [IMAGE], ");
            sQuery = String.Concat(sQuery, " C.CITY_NAME, O.OCCUPATION, D.NETWORK_NO_OF_AFFILIATES ");
            sQuery = String.Concat(sQuery, " , CASE WHEN ISNULL(P.USERID , '') = '' THEN 'Affiliate' WHEN ISNULL(P.USERID , '') != '' THEN 'Premium Affiliate' END USER_STATUS_DTLS ");
            sQuery = String.Concat(sQuery, " FROM FN_GENEOLOGY_TREE_AFFILIATES('" + refID + "') F ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_IMAGEDETAIL I ON F.USERID = I.USERID ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_EDITPROFILE E ON F.USERID = E.USERID ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN CITIES C ON E.[CITY/AREA] = C.CITY_ID ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_OCCUPATION O ON E.OCCUPATION = O.ID  ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_USER_INVITATIONS_DATA D ON F.USERID = D.USERID ");
            sQuery = String.Concat(sQuery, " LEFT OUTER JOIN TBL_PREMIUM_AFFILIATES P ON F.USERID = P.USERID ");
            sQuery = String.Concat(sQuery, " ORDER BY AFFILIATE_DATE DESC");

            return GetDataTable(sQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable GetRegistrationDetails_By_UserID(string userID, bool bActiveOnly = false)
    {
        try
        {
            string sQuery = "SELECT USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, LEVELNO, CONVERT(VARCHAR(11), JOINDATE , 113) JOINDATE, REFERID,  REF_NAME , IMAGENAME AS IMAGE  ";
            sQuery += " , TLBV, TRBV, CFL, CFR, NETBV, CAST(ISNULL(TLBV ,0) AS INT) + CAST(ISNULL(TRBV, 0) AS INT) TOT_TBV, CAST(ISNULL(CFL ,0 ) AS INT) + CAST(ISNULL(CFR , 0 ) AS INT) TOT_CBV , NO_OF_INVITES";
            sQuery += " , USER_STATUS , ISNULL(PRODUCTTYPE , '0') PRODUCTTYPE , MEMBER_STATUS, UPGRADED_PAID_DEACTIVE";
            sQuery += " FROM REGISTRION_DETAILS_VIEW ";
            sQuery += " WHERE USERID = '" + userID + "'";

            if (bActiveOnly == true)
                sQuery += " AND ACTIVESTATUS ='A' ";

            sQuery += " ORDER BY JOINDATE ";
            return GetDataTable(sQuery, true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable zGetRegistrationDetails_Tree_By_RefID(string refID)
    {
        try
        {
            //string sQuery = "WITH tree (USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, ACTUAL_LEVEL, JOINDATE , IMAGE , REFERID, REF_NAME, CALCULATED_LEVEL, TLBV, TRBV, CFL, CFR, NETBV , NO_OF_INVITES, USER_STATUS , PRODUCTTYPE , MEMBER_STATUS , UPGRADED_PAID_DEACTIVE) as ";
            //sQuery += " ( SELECT  USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, LEVELNO AS ACTUAL_LEVEL,  CONVERT(VARCHAR(11), JOINDATE , 113) JOINDATE , IMAGENAME  IMAGE , REFERID,  REF_NAME, 0 AS CALCULATED_LEVEL";
            //sQuery += "      , TLBV, TRBV, CFL, CFR, NETBV, ISNULL(NO_OF_INVITES , 0) NO_OF_INVITES , USER_STATUS  , ISNULL(PRODUCTTYPE , '0') PRODUCTTYPE, MEMBER_STATUS , UPGRADED_PAID_DEACTIVE";
            //sQuery += "     FROM mfloatdb.REGISTRION_DETAILS_VIEW ";
            //sQuery += "     WHERE REFERID = '" + refID + "'  AND ACTIVESTATUS ='A' AND MEMBER_STATUS = 'PAID_MEMBER' ";
            //sQuery += "  UNION ALL ";
            //sQuery += "  SELECT C2.USERID , C2.FULLNAME ,  C2.MOBILENO , C2.EMAILID, C2.PLACEMENT, C2.LEVELNO, CONVERT(VARCHAR(11), C2.JOINDATE , 113) JOINDATE , C2.IMAGENAME IMAGE , C2.REFERID,  C2.REF_NAME, TREE.CALCULATED_LEVEL + 1 ";
            //sQuery += "      , C2.TLBV, C2.TRBV, C2.CFL, C2.CFR, C2.NETBV, ISNULL(C2.NO_OF_INVITES , 0) NO_OF_INVITES , C2.USER_STATUS  , ISNULL(C2.PRODUCTTYPE , '0') PRODUCTTYPE , C2.MEMBER_STATUS , C2.UPGRADED_PAID_DEACTIVE ";
            //sQuery += "     FROM mfloatdb.REGISTRION_DETAILS_VIEW c2  ";
            //sQuery += "     INNER JOIN tree ON tree.userid = c2.referid WHERE C2.ACTIVESTATUS ='A' AND C2.MEMBER_STATUS = 'PAID_MEMBER' ) ";
            //sQuery += " SELECT USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, ACTUAL_LEVEL, JOINDATE , REFERID, REF_NAME , IMAGE, CALCULATED_LEVEL  ";
            //sQuery += " , TLBV, TRBV, CFL, CFR, NETBV , NO_OF_INVITES , USER_STATUS  , PRODUCTTYPE , MEMBER_STATUS , UPGRADED_PAID_DEACTIVE FROM tree ORDER BY JOINDATE ";

            string sQuery = " SELECT USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, ACTUAL_LEVEL, CONVERT(VARCHAR(11), JOINDATE , 113) JOINDATE , REFERID, REF_NAME , IMAGE, CALCULATED_LEVEL  ";
            sQuery += " , TLBV, TRBV, CFL, CFR, NETBV , NO_OF_INVITES , USER_STATUS  , PRODUCTTYPE , MEMBER_STATUS , UPGRADED_PAID_DEACTIVE FROM FN_GENEOLOGY_TREE('"+ refID +"') ORDER BY JOINDATE ";


            return GetDataTable(sQuery, true);
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    public DataTable GetRegistrationDetails_Tree_By_RefID(string refID,string status,string activeornot)
    {
        try
        {
            
            //string sQuery = " SELECT USERID , FULLNAME ,  MOBILENO , EMAILID, PLACEMENT, ACTUAL_LEVEL, CONVERT(VARCHAR(11), JOINDATE , 113) JOINDATE , REFERID, REF_NAME , IMAGE, CALCULATED_LEVEL  ";
            //sQuery += " , TLBV, TRBV, CFL, CFR, NETBV , NO_OF_INVITES , USER_STATUS_DTLS  , PRODUCTTYPE , MEMBER_STATUS , UPGRADED_PAID_DEACTIVE,OCCUPATION,CITY_NAME ";
            //// This below line added by Sudhindra on 16-09-14. Purpose : display activation date instead of join date in the genealogy.
            //sQuery += " , ACTIVATION_DATE ,  CONVERT(VARCHAR(11), ACTIVATION_DATE , 113) ACTIVATION_DATE_113 ";
            //sQuery += " FROM FN_GENEOLOGY_TREE_ALL_NETWORK_MEMBERS('" + refID + "','" + status + "','" + activeornot + "') ORDER BY ACTIVATION_DATE ";


            string sQuery = " SELECT F.USERID , F.FULLNAME ,  F.MOBILENO , F.EMAILID, F.PLACEMENT, F.ACTUAL_LEVEL, CONVERT(VARCHAR(11), F.JOINDATE , 113) JOINDATE , F.REFERID, F.REF_NAME , F.IMAGE, F.CALCULATED_LEVEL  ";
            sQuery += " , F.TLBV, F.TRBV, F.CFL, F.CFR, F.NETBV , F.NO_OF_INVITES , F.USER_STATUS_DTLS  , F.PRODUCTTYPE , F.MEMBER_STATUS , F.UPGRADED_PAID_DEACTIVE,F.OCCUPATION,CITY_NAME ";
            // This below line added by Sudhindra on 15-10-14. Purpose : display referal image .
            sQuery += " , F.ACTIVATION_DATE ,  CONVERT(VARCHAR(11), F.ACTIVATION_DATE , 113) ACTIVATION_DATE_113 , I.IMAGENAME REFER_IMAGE_NAME ";
            sQuery += " , NETWORK_NO_OF_AFFILIATES "; 
            sQuery += " FROM FN_GENEOLOGY_TREE_ALL_NETWORK_MEMBERS('" + refID + "','" + status + "','" + activeornot + "') F ";
            sQuery += " INNER JOIN TBL_IMAGEDETAIL I ON F.REFERID = I.USERID  ";
            sQuery += " ORDER BY F.ACTIVATION_DATE DESC";
            

            return GetDataTable(sQuery, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


    public DataTable GetMyAffiliatesDetails_Tree_By_RefID(string refID, string status, string activeornot)
    {
        try
        {

            string sQuery = " SELECT F.USERID , F.FULLNAME ,  F.MOBILENO , F.EMAILID, F.PLACEMENT, F.ACTUAL_LEVEL, CONVERT(VARCHAR(11), F.JOINDATE , 113) JOINDATE , F.REFERID, F.REF_NAME , F.IMAGE, F.CALCULATED_LEVEL  ";
            sQuery += " , F.NO_OF_INVITES , F.USER_STATUS_DTLS  , F.PRODUCTTYPE , F.MEMBER_STATUS , F.UPGRADED_PAID_DEACTIVE,F.OCCUPATION,CITY_NAME ";
            sQuery += " , F.ACTIVATION_DATE ,  CONVERT(VARCHAR(11), F.ACTIVATION_DATE , 113) ACTIVATION_DATE_113 , I.IMAGENAME REFER_IMAGE_NAME ";
            sQuery += " , NETWORK_NO_OF_AFFILIATES ";
            sQuery += " FROM FN_GENEOLOGY_TREE_VERSION_2('" + refID + "','" + status + "','" + activeornot + "') F ";
            sQuery += " INNER JOIN TBL_IMAGEDETAIL I ON F.REFERID = I.USERID  ";
            sQuery += " ORDER BY F.ACTIVATION_DATE DESC";


            return GetDataTable(sQuery, true);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
}