﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Data;
/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.ComponentModel.ToolboxItem(false)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 

[ScriptService]
public class wsUserDetails : System.Web.Services.WebService
{

    [WebMethod(EnableSession = true)]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
    public string GetTableData()
    {
        var echo = int.Parse(HttpContext.Current.Request.Params["sEcho"]);
        var displayLength = int.Parse(HttpContext.Current.Request.Params["iDisplayLength"]);
        var displayStart = int.Parse(HttpContext.Current.Request.Params["iDisplayStart"]);
        var sortOrder = HttpContext.Current.Request.Params["sSortDir_0"].ToString(CultureInfo.CurrentCulture);
        var roleId = HttpContext.Current.Request.Params["roleId"].ToString(CultureInfo.CurrentCulture);
        var userid = HttpContext.Current.Request.Params["userid"].ToString(CultureInfo.CurrentCulture);
        
        var records = GetRecords().ToList();
//        var records = GetRecords(displayLength, displayStart).ToList();
        // var records = GetRecordsFromDatabaseWithFilter().ToList();
        if (!records.Any())
        {
            return string.Empty;
        }

        var orderedResults = sortOrder == "asc"
                             ? records.OrderBy(o => o.userid)
                             : records.OrderByDescending(o => o.userid);
        var itemsToSkip = displayStart == 0
                          ? 0
                          : displayStart;
        var pagedResults = orderedResults.Skip(itemsToSkip).Take(displayLength).ToList();
        var hasMoreRecords = false;

        var sb = new StringBuilder();
        sb.Append(@"{" + "\"sEcho\": " + echo + ",");
        sb.Append("\"recordsTotal\": " + records.Count + ",");
        sb.Append("\"recordsFiltered\": " + records.Count + ",");
        sb.Append("\"iTotalRecords\": " + records.Count + ",");
        sb.Append("\"iTotalDisplayRecords\": " + records.Count + ",");
        sb.Append("\"aaData\": [");
        foreach (var result in pagedResults)
        {
            if (hasMoreRecords)
            {
                sb.Append(",");
            }
            sb.Append("[");
            sb.Append("\"" + result.name + "\",");
            sb.Append("\"" + result.emailid + "\",");
            sb.Append("\"" + result.mobileno + "\",");
            sb.Append("\"" + result.userid + "\",");
            sb.Append("\"<img class='image-details' src='content/details_open.png' runat='server' height='16' width='16' alt='View Details'/>\"");
            sb.Append("]");
            hasMoreRecords = true;
        }
        sb.Append("]}");
        return sb.ToString();
    }

    private static IEnumerable<UserDetails> GetRecords(int displayLength, int displayStart)
    {
        DataTable dsResend = new DataTable();
        usernetworkdata userdata = new usernetworkdata();
        dsResend = userdata.getInActiveByUserID(HttpContext.Current.Session["userid"].ToString(),displayLength, displayStart+1);

        List<UserDetails> target = dsResend.AsEnumerable()
              .Select(row => new UserDetails
              {
                  name = row.Field<string>("name"),
                  emailid = row.Field<string>("emailid"),
                  mobileno = row.Field<string>("mobileno"),
                  userid = row.Field<string>("userid")
              }).ToList();
        return target;
    }
    private static IEnumerable<UserDetails> GetRecords()
    {
        DataSet dsResend = new DataSet();
        usernetworkdata userdata = new usernetworkdata();
        dsResend = userdata.getInActiveByUserID(HttpContext.Current.Session["userid"].ToString());

        List<UserDetails> target = dsResend.Tables[0].AsEnumerable()
              .Select(row => new UserDetails
              {
                  name = row.Field<string>("name"),
                  emailid = row.Field<string>("emailid"),
                  mobileno = row.Field<string>("mobileno"),
                  userid = row.Field<string>("userid")
              }).ToList();
        return target;

    }

}