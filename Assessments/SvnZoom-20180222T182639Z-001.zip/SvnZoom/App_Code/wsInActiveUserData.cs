﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Text;
using System.Web.Script.Services;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.ServiceModel.Web;
using System.Web.Script.Services;
using System.Globalization;

/// <summary>
/// Summary description for WebService1
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.ComponentModel.ToolboxItem(false)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class wsInActiveUserData : System.Web.Services.WebService
{

    //1/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////1//
    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json,
     BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]
    public string UGetItems()
    {
        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);
        int iDisplayLength = ToInt(HttpContext.Current.Request.Params["iDisplayLength"]);
        int iDisplayStart = ToInt(HttpContext.Current.Request.Params["iDisplayStart"]);
        string rawSearch = HttpContext.Current.Request.Params["sSearch"];
        var userid = HttpContext.Current.Request.Params["uid"].ToString(CultureInfo.CurrentCulture);

        string participant = HttpContext.Current.Request.Params["iParticipant"];

        var sb = new StringBuilder();
        //WHERE
        //                                  activeuser='NA'  AND referalID='"+ userid +"'
        var whereClause = string.Empty;
        if (participant != null)
        {
            if (participant.Length > 0)
            {
                sb.Append(" Where name like ");
                sb.Append("'%" + participant + "%'");
                sb.Append(" AND activeuser = ");
                sb.Append("NA");
                sb.Append(" AND referalID = ");
                sb.Append("'" + userid + "'");
                whereClause = sb.ToString();
            }
        }
        else
        {
            sb.Append(" Where activeuser = ");
            sb.Append("'NA'");
            sb.Append(" AND referalID = ");
            sb.Append("'" + userid + "'");
            whereClause = sb.ToString();
        }
        sb.Clear();

        var filteredWhere = string.Empty;

        var wrappedSearch = "'%" + rawSearch + "%'";

        if (rawSearch.Length > 0)
        {

            sb.Append(" WHERE emailid LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR user LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR mobileno LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR joindate LIKE ");
            sb.Append(wrappedSearch);

            filteredWhere = sb.ToString();
        }


        //ORDERING

        sb.Clear();

        string orderByClause = string.Empty;

        sb.Append(";");
        sb.Append(ToInt(HttpContext.Current.Request.Params["iSortCol_0"]));
        sb.Append(";");
        sb.Append(" ");

        sb.Append(HttpContext.Current.Request.Params["sSortDir_0"]);

        orderByClause = sb.ToString();

        if (!String.IsNullOrEmpty(orderByClause))
        {

            orderByClause = orderByClause.Replace(";0;", ", userid ");
            orderByClause = orderByClause.Replace(";1;", ", name ");


            orderByClause = orderByClause.Remove(0, 1);
        }
        else
        {
            orderByClause = "userid ASC";
        }
        orderByClause = "ORDER BY " + orderByClause;

        sb.Clear();
        // string uu = HttpContext.Current.Session["userid"].ToString();
        var numberOfRowsToReturn = "";
        numberOfRowsToReturn = iDisplayLength == -1 ? "TotalRows" : (iDisplayStart + iDisplayLength).ToString();
        //dsResend = userdata.getInActiveByUserID(HttpContext.Current.Session["userid"].ToString());
        //	                            @MA ( userid, name )
        //	                                Select userid, name 
        //	                                FROM [tbl_freememreg]
        //@MA ( sno,userid, name,joindate,emailid,mobileno)
        //                           Select sno,userid, name,joindate,emailid,mobileno
        //                           FROM [tbl_freememreg] 
        //                               WHERE
        //                                    activeuser='NA'  AND referalID="+HttpContext.Current.Session["userid"].ToString()+"'

        //WHERE
        //                                   activeuser='NA'  AND referalID='"+ userid +"'
        string query = @" 
                             declare @MA TABLE(sno bigint,  userid VARCHAR(50), name VARCHAR(100),joindate VARCHAR(50),emailid VARCHAR(50),mobileno VARCHAR(50))
                           INSERT
                            INTO
                                    @MA ( userid, name,emailid,mobileno,joindate )
   	                                Select userid, name,emailid,mobileno,joindate
                                    FROM [tbl_freememreg]
                                      
	                                {4}                   

                            SELECT *
                            FROM
	                            (SELECT row_number() OVER ({0}) AS RowNumber
		                              , *
	                             FROM
		                             (SELECT (SELECT count([@MA].userid)
				                              FROM
					                              @MA) AS TotalRows
			                               , ( SELECT  count( [@MA].userid) FROM @MA {1}) AS TotalDisplayRows			   
			                               ,[@MA].userid
			                               ,[@MA].name   
			                               ,[@MA].emailid    
			                               ,[@MA].mobileno   
			                               ,[@MA].joindate        
		                              FROM
			                              @MA {1}) RawResults) Results
                            WHERE
	                            RowNumber BETWEEN {2} AND {3}";


        query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            var DB = new SqlCommand();
            DB.Connection = con;
            DB.CommandText = query;
            var data = DB.ExecuteReader();

            var totalDisplayRecords = "";
            var totalRecords = "";
            string outputJson = string.Empty;

            var rowClass = "";
            var count = 0;

            while (data.Read())
            {

                if (totalRecords.Length == 0)
                {
                    totalRecords = data["TotalRows"].ToString();
                    totalDisplayRecords = data["TotalDisplayRows"].ToString();
                }
                sb.Append("{");
                sb.AppendFormat(@"""DT_RowId"": ""{0}""", count++);
                sb.Append(",");
                sb.AppendFormat(@"""DT_RowClass"": ""{0}""", rowClass);
                sb.Append(",");
                sb.AppendFormat(@"""4"": ""{0}""", data["userid"]);
                sb.Append(",");
                sb.AppendFormat(@"""0"": ""{0}""", data["name"]);
                sb.Append(",");
                sb.AppendFormat(@"""1"": ""{0}""", data["emailid"]);
                sb.Append(",");
                sb.AppendFormat(@"""2"": ""{0}""", data["mobileno"]);
                sb.Append(",");
                sb.AppendFormat(@"""3"": ""{0}""", data["joindate"]);
                sb.Append("},");
            }

            // handles zero records
            if (totalRecords.Length == 0)
            {
                sb.Append("{");
                sb.Append(@"""sEcho"": ");
                sb.AppendFormat(@"""{0}""", sEcho);
                sb.Append(",");
                sb.Append(@"""iTotalRecords"": 0");
                sb.Append(",");
                sb.Append(@"""iTotalDisplayRecords"": 0");
                sb.Append(", ");
                sb.Append(@"""aaData"": [ ");
                sb.Append("]}");
                outputJson = sb.ToString();

                return outputJson;
            }
            outputJson = sb.Remove(sb.Length - 1, 1).ToString();
            sb.Clear();

            sb.Append("{");
            sb.Append(@"""sEcho"": ");
            sb.AppendFormat(@"""{0}""", sEcho);
            sb.Append(",");
            sb.Append(@"""iTotalRecords"": ");
            sb.Append(totalRecords);
            sb.Append(",");
            sb.Append(@"""iTotalDisplayRecords"": ");
            sb.Append(totalDisplayRecords);
            sb.Append(", ");
            sb.Append(@"""aaData"": [ ");
            sb.Append(outputJson);
            sb.Append("]}");
            outputJson = sb.ToString();

            return outputJson;
        }

        // var connectionString = ConfigurationManager.ConnectionStrings["conn_str"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);

        //try
        //{
        //    conn.Open();
        //}
        //catch (Exception e)
        //{
        //    Console.WriteLine(e.ToString());
        //}


    }
    //1/////////////////////End/////////////////////////Savitri/////////////////////////////End/////////////////1//
    public static int ToInt(string toParse)
    {
        int result;
        if (int.TryParse(toParse, out result)) return result;

        return result;
    }


    //2/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////2//

    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json,
     BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]

    public string AGetRawData()
    {
        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);
        int iDisplayLength = ToInt(HttpContext.Current.Request.Params["iDisplayLength"]);
        int iDisplayStart = ToInt(HttpContext.Current.Request.Params["iDisplayStart"]);
        string rawSearch = HttpContext.Current.Request.Params["sSearch"];
        var userid = HttpContext.Current.Request.Params["uid"].ToString(CultureInfo.CurrentCulture);

        string participant = HttpContext.Current.Request.Params["iParticipant"];

        var sb = new StringBuilder();

        var whereClause = string.Empty;
        if (participant != null)
        {
            if (participant.Length > 0)
            {
                sb.Append(" Where name like ");
                sb.Append("'%" + participant + "%'");
                whereClause = sb.ToString();
            }
        }

        else
        {
            sb.Append(" Where v1.activeuser = ");
            sb.Append("'NA'");
            whereClause = sb.ToString();
        }
        sb.Clear();

        var filteredWhere = string.Empty;

        var wrappedSearch = "'%" + rawSearch + "%'";

        if (rawSearch.Length > 0)
        {
            sb.Append(" WHERE joindate LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR userid LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR mobileno LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR city LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_id LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_mobile LIKE ");
            sb.Append(wrappedSearch);

            filteredWhere = sb.ToString();
        }


        //ORDERING

        sb.Clear();

        string orderByClause = string.Empty;
        sb.Append(";");
        sb.Append(ToInt(HttpContext.Current.Request.Params["iSortCol_0"]));
        sb.Append(";");

        sb.Append(" ");

        sb.Append(HttpContext.Current.Request.Params["sSortDir_0"]);

        orderByClause = sb.ToString();

        if (!String.IsNullOrEmpty(orderByClause))
        {

            orderByClause = orderByClause.Replace(";0;", ", joindate ");
            orderByClause = orderByClause.Replace(";1;", ", joindate ");
            orderByClause = orderByClause.Replace(";2;", ", userid ");
            orderByClause = orderByClause.Replace(";3;", ", name ");
            orderByClause = orderByClause.Replace(";4;", ", mobileno ");
            orderByClause = orderByClause.Replace(";5;", ", city ");
            orderByClause = orderByClause.Replace(";6;", ", ref_id ");
            orderByClause = orderByClause.Replace(";7;", ", ref_name ");
            orderByClause = orderByClause.Replace(";8;", ", ref_mobile ");  

            orderByClause = orderByClause.Remove(0, 1);
        }
        else
        {
            orderByClause = "joindate ASC";
        }
        orderByClause = "ORDER BY " + orderByClause;

        sb.Clear();
        var numberOfRowsToReturn = "";
        numberOfRowsToReturn = iDisplayLength == -1 ? "TotalRows" : (iDisplayStart + iDisplayLength).ToString();
        string query = @" 
                             
                            declare @MA TABLE(sno bigint,  userid VARCHAR(50), name VARCHAR(100),joindate DATETIME,emailid VARCHAR(50),mobileno VARCHAR(50), city VARCHAR(100),ref_id VARCHAR(50),ref_name VARCHAR(50),ref_mobile VARCHAR(50))
                            INSERT
                            INTO
                                    @MA ( joindate,userid, name,mobileno,city,ref_id,ref_name,ref_mobile )

                                        SELECT CAST(v1.JOINDATE AS DATETIME) AS joindate,v1.USERID AS userid, v1.NAME AS name, 
                                         v1.MOBILENO AS mobileno, c.city_name AS city, v1.REFERALID AS ref_id,v2.NAME AS ref_name, v1.REFERAL_MOBILE AS ref_mobile 
	                                        FROM ALL_MEMBERS_VIEW v1 inner join ALL_MEMBERS_VIEW v2 on v1.REFERALID=v2.USERID and v1.invalid_data_status =0
	                                         left outer join cities c on v1.city=c.city_id 
                                        
	                                {4}                   

                            SELECT *
                            FROM
	                            (SELECT row_number() OVER ({0}) AS RowNumber
		                              , *
	                             FROM
		                             (SELECT (SELECT count([@MA].userid)
				                              FROM
					                              @MA) AS TotalRows
			                               , ( SELECT  count( [@MA].userid) FROM @MA {1}) AS TotalDisplayRows  			   
			                               ,[@MA].sno
			                               ,[@MA].joindate   			   
			                               ,[@MA].userid
			                               ,[@MA].name   
			                               ,[@MA].mobileno    
			                               ,[@MA].city
			                               ,[@MA].ref_id   
			                               ,[@MA].ref_name 
			                               ,[@MA].ref_mobile           
		                              FROM
			                              @MA {1}) RawResults) Results
                            WHERE
	                            RowNumber BETWEEN {2} AND {3}";


        query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            var DB = new SqlCommand();
            DB.Connection = con;
            DB.CommandText = query;
            var data = DB.ExecuteReader();

            var totalDisplayRecords = "";
            var totalRecords = "";
            string outputJson = string.Empty;

            var rowClass = "";
            var count = 0;

            while (data.Read())
            {

                if (totalRecords.Length == 0)
                {
                    totalRecords = data["TotalRows"].ToString();
                    totalDisplayRecords = data["TotalDisplayRows"].ToString();
                }
                sb.Append("{");
                sb.AppendFormat(@"""DT_RowId"": ""{0}""", count++);
                sb.Append(",");
                sb.AppendFormat(@"""DT_RowClass"": ""{0}""", rowClass);
                sb.Append(",");
                sb.AppendFormat(@"""0"": ""{0}""", data["sno"]);
                sb.Append(",");
                sb.AppendFormat(@"""1"": ""{0}""", data["joindate"]);
                sb.Append(",");
                sb.AppendFormat(@"""2"": ""{0}""", data["userid"]);
                sb.Append(",");
                sb.AppendFormat(@"""3"": ""{0}""", data["name"]);
                sb.Append(",");
                sb.AppendFormat(@"""4"": ""{0}""", data["mobileno"]);
                sb.Append(",");
                sb.AppendFormat(@"""5"": ""{0}""", data["city"]);
                sb.Append(",");
                sb.AppendFormat(@"""6"": ""{0}""", data["ref_id"]);
                sb.Append(",");
                sb.AppendFormat(@"""7"": ""{0}""", data["ref_name"]);
                sb.Append(",");
                sb.AppendFormat(@"""8"": ""{0}""", data["ref_mobile"]);
                sb.Append("},");
            }//joindate,userid, name,mobileno,city,ref_id,ref_name,ref_mobile

            // handles zero records
            if (totalRecords.Length == 0)
            {
                sb.Append("{");
                sb.Append(@"""sEcho"": ");
                sb.AppendFormat(@"""{0}""", sEcho);
                sb.Append(",");
                sb.Append(@"""iTotalRecords"": 0");
                sb.Append(",");
                sb.Append(@"""iTotalDisplayRecords"": 0");
                sb.Append(", ");
                sb.Append(@"""aaData"": [ ");
                sb.Append("]}");
                outputJson = sb.ToString();

                return outputJson;
            }
            outputJson = sb.Remove(sb.Length - 1, 1).ToString();
            sb.Clear();

            sb.Append("{");
            sb.Append(@"""sEcho"": ");
            sb.AppendFormat(@"""{0}""", sEcho);
            sb.Append(",");
            sb.Append(@"""iTotalRecords"": ");
            sb.Append(totalRecords);
            sb.Append(",");
            sb.Append(@"""iTotalDisplayRecords"": ");
            sb.Append(totalDisplayRecords);
            sb.Append(", ");
            sb.Append(@"""aaData"": [ ");
            sb.Append(outputJson);
            sb.Append("]}");
            outputJson = sb.ToString();

            return outputJson;
        }

        // var connectionString = ConfigurationManager.ConnectionStrings["conn_str"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);

        //try
        //{
        //    conn.Open();
        //}
        //catch (Exception e)
        //{
        //    Console.WriteLine(e.ToString());
        //}


    }

    //2///////////////////End///////////////////////////Savitri///////////////////////End////////////////////////2/




    //3/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////3//

    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json,
     BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]

    public string AGetAllData()
    {
        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);
        int iDisplayLength = ToInt(HttpContext.Current.Request.Params["iDisplayLength"]);
        int iDisplayStart = ToInt(HttpContext.Current.Request.Params["iDisplayStart"]);
        string rawSearch = HttpContext.Current.Request.Params["sSearch"];
        var userid = HttpContext.Current.Request.Params["uid"].ToString(CultureInfo.CurrentCulture);

        string participant = HttpContext.Current.Request.Params["iParticipant"];

        var sb = new StringBuilder();

        var whereClause = string.Empty;
        if (participant != null)
        {
            if (participant.Length > 0)
            {
                sb.Append(" Where name like ");
                sb.Append("'%" + participant + "%'");
                whereClause = sb.ToString();
            }
        }

       
        sb.Clear();

        var filteredWhere = string.Empty;

        var wrappedSearch = "'%" + rawSearch + "%'";

        if (rawSearch.Length > 0)
        {

            sb.Append(" WHERE joindate LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR userid LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR mobileno LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR city LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_id LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_mobile LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_INV LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_AC LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_IN_AC LIKE ");
            sb.Append(wrappedSearch);


            filteredWhere = sb.ToString();
        }


        //ORDERING

        sb.Clear();

        string orderByClause = string.Empty;
        sb.Append(";");
        sb.Append(ToInt(HttpContext.Current.Request.Params["iSortCol_0"]));
        sb.Append(";");
        sb.Append(" ");

        sb.Append(HttpContext.Current.Request.Params["sSortDir_0"]);

        orderByClause = sb.ToString();

        if (!String.IsNullOrEmpty(orderByClause))
        {


            orderByClause = orderByClause.Replace(";0;", ", joindate ");
            orderByClause = orderByClause.Replace(";1;", ", joindate ");
            orderByClause = orderByClause.Replace(";2;", ", userid ");
            orderByClause = orderByClause.Replace(";3;", ", name ");
            orderByClause = orderByClause.Replace(";4;", ", mobileno ");
            orderByClause = orderByClause.Replace(";5;", ", city  ");
            orderByClause = orderByClause.Replace(";6;", ", ref_id ");
            orderByClause = orderByClause.Replace(";7;", ", ref_name ");
            orderByClause = orderByClause.Replace(";8;", ", ref_mobile ");
            orderByClause = orderByClause.Replace(";9;", ", T_INV ");
            orderByClause = orderByClause.Replace(";10;", ", T_AC ");
            orderByClause = orderByClause.Replace(";11;", ", T_IN_AC ");


            orderByClause = orderByClause.Remove(0, 1);
        }
        else
        {
            orderByClause = "JOINDATE DESC";
        }
        orderByClause = "ORDER BY " + orderByClause;

        sb.Clear();
        // string uu = HttpContext.Current.Session["userid"].ToString();
        var numberOfRowsToReturn = "";
        numberOfRowsToReturn = iDisplayLength == -1 ? "TotalRows" : (iDisplayStart + iDisplayLength).ToString();
        
        string query = @" 
                             
                            declare @MA TABLE(sno bigint,  userid VARCHAR(50), name VARCHAR(100),joindate VARCHAR(50),emailid VARCHAR(50),mobileno VARCHAR(50), city VARCHAR(100),ref_id VARCHAR(50),ref_name VARCHAR(50),ref_mobile VARCHAR(50),T_INV int,T_AC int,T_IN_AC int )
                            INSERT
                            INTO
                                    @MA ( joindate,userid, name,mobileno,city,ref_id,ref_name,ref_mobile,T_INV,T_AC,T_IN_AC)

                                        SELECT CAST(v1.JOINDATE AS DATETIME) AS joindate,v1.USERID AS userid, v1.NAME AS name, 
                                         v1.MOBILENO AS mobileno, c.city_name AS city, v1.REFERALID AS ref_id,v2.NAME AS ref_name, v1.REFERAL_MOBILE AS ref_mobile,
                                         d.PERSONAL_INVITED as  T_INV, d.PERSONAL_ACTIVATED as  T_AC,
                                         (d.PERSONAL_INVITED-d.PERSONAL_ACTIVATED) as  T_IN_AC
	                                        FROM ALL_MEMBERS_VIEW v1 inner join ALL_MEMBERS_VIEW v2 on v1.REFERALID=v2.USERID and v1.invalid_data_status =0
	                                         left outer join cities c on v1.city=c.city_id 
	                                          left outer join TBL_USER_INVITATIONS_DATA d on v1.userid=d.userid                                     
                                        
	                                {4}                   

                            SELECT *
                            FROM
	                            (SELECT row_number() OVER ({0}) AS RowNumber
		                              , *
	                             FROM
		                             (SELECT (SELECT count([@MA].userid)
				                              FROM
					                              @MA) AS TotalRows
			                               , ( SELECT  count( [@MA].userid) FROM @MA {1}) AS TotalDisplayRows  
			                               ,[@MA].sno    
			                               ,[@MA].joindate   			   
			                               ,[@MA].userid
			                               ,[@MA].name   
			                               ,[@MA].mobileno    
			                               ,[@MA].city
			                               ,[@MA].ref_id   
			                               ,[@MA].ref_name 
			                               ,[@MA].ref_mobile    
			                               ,[@MA].T_INV
			                               ,[@MA].T_AC 
			                               ,[@MA].T_IN_AC           
		                              FROM
			                              @MA {1}) RawResults) Results
                            WHERE
	                            RowNumber BETWEEN {2} AND {3}";


        query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            var DB = new SqlCommand();
            DB.Connection = con;
            DB.CommandText = query;
            var data = DB.ExecuteReader();

            var totalDisplayRecords = "";
            var totalRecords = "";
            string outputJson = string.Empty;

            var rowClass = "";
            var count = 0;

            while (data.Read())
            {

                if (totalRecords.Length == 0)
                {
                    totalRecords = data["TotalRows"].ToString();
                    totalDisplayRecords = data["TotalDisplayRows"].ToString();
                }
                sb.Append("{");
                sb.AppendFormat(@"""DT_RowId"": ""{0}""", count++);
                sb.Append(",");
                sb.AppendFormat(@"""DT_RowClass"": ""{0}""", rowClass);
                sb.Append(",");
                sb.AppendFormat(@"""0"": ""{0}""", data["sno"]);
                sb.Append(",");
                sb.AppendFormat(@"""1"": ""{0}""", data["joindate"]);
                sb.Append(",");
                sb.AppendFormat(@"""2"": ""{0}""", data["userid"]);
                sb.Append(",");
                sb.AppendFormat(@"""3"": ""{0}""", data["name"]);
                sb.Append(",");
                sb.AppendFormat(@"""4"": ""{0}""", data["mobileno"]);
                sb.Append(",");
                sb.AppendFormat(@"""5"": ""{0}""", data["city"]);
                sb.Append(",");
                sb.AppendFormat(@"""6"": ""{0}""", data["ref_id"]);
                sb.Append(",");
                sb.AppendFormat(@"""7"": ""{0}""", data["ref_name"]);
                sb.Append(",");
                sb.AppendFormat(@"""8"": ""{0}""", data["ref_mobile"]);
                sb.Append(",");
                sb.AppendFormat(@"""9"": ""{0}""", data["T_INV"]);
                sb.Append(",");
                sb.AppendFormat(@"""10"": ""{0}""", data["T_AC"]);
                sb.Append(",");
                sb.AppendFormat(@"""11"": ""{0}""", data["T_IN_AC"]);
                sb.Append("},");
            }//joindate,userid, name,mobileno,city,ref_id,ref_name,ref_mobile,T_INV,T_AC,TOTAL_ELIGIBLE,T_IN_AC

            // handles zero records
            if (totalRecords.Length == 0)
            {
                sb.Append("{");
                sb.Append(@"""sEcho"": ");
                sb.AppendFormat(@"""{0}""", sEcho);
                sb.Append(",");
                sb.Append(@"""iTotalRecords"": 0");
                sb.Append(",");
                sb.Append(@"""iTotalDisplayRecords"": 0");
                sb.Append(", ");
                sb.Append(@"""aaData"": [ ");
                sb.Append("]}");
                outputJson = sb.ToString();

                return outputJson;
            }
            outputJson = sb.Remove(sb.Length - 1, 1).ToString();
            sb.Clear();

            sb.Append("{");
            sb.Append(@"""sEcho"": ");
            sb.AppendFormat(@"""{0}""", sEcho);
            sb.Append(",");
            sb.Append(@"""iTotalRecords"": ");
            sb.Append(totalRecords);
            sb.Append(",");
            sb.Append(@"""iTotalDisplayRecords"": ");
            sb.Append(totalDisplayRecords);
            sb.Append(", ");
            sb.Append(@"""aaData"": [ ");
            sb.Append(outputJson);
            sb.Append("]}");
            outputJson = sb.ToString();

            return outputJson;
        }

        // var connectionString = ConfigurationManager.ConnectionStrings["conn_str"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);

        //try
        //{
        //    conn.Open();
        //}
        //catch (Exception e)
        //{
        //    Console.WriteLine(e.ToString());
        //}


    }

    //3///////////////////End///////////////////////////Savitri///////////////////////End////////////////////////3/



    //4/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////4//

    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json,
     BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]

    public string AGetActiveData()
    {
        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);
        int iDisplayLength = ToInt(HttpContext.Current.Request.Params["iDisplayLength"]);
        int iDisplayStart = ToInt(HttpContext.Current.Request.Params["iDisplayStart"]);
        string rawSearch = HttpContext.Current.Request.Params["sSearch"];
        var userid = HttpContext.Current.Request.Params["uid"].ToString(CultureInfo.CurrentCulture);

        string participant = HttpContext.Current.Request.Params["iParticipant"];

        var sb = new StringBuilder();

        var whereClause = string.Empty;
        if (participant != null)
        {
            if (participant.Length > 0)
            {
                sb.Append(" Where name like ");
                sb.Append("'%" + participant + "%'");
                whereClause = sb.ToString();
            }
        }
        else
        {
            sb.Append(" Where v1.activeuser = ");
            sb.Append("'A'");
            whereClause = sb.ToString();
        }


        sb.Clear();

        var filteredWhere = string.Empty;

        var wrappedSearch = "'%" + rawSearch + "%'";

        if (rawSearch.Length > 0)
        {
            sb.Append(" WHERE DOA LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR DOJ LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR userid LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR mobileno LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR city LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_id LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_mobile LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_INV LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_AC LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_IN_AC LIKE ");
            sb.Append(wrappedSearch);

            filteredWhere = sb.ToString();
        }


        //ORDERING

        sb.Clear();

        string orderByClause = string.Empty;
        sb.Append(";");
        sb.Append(ToInt(HttpContext.Current.Request.Params["iSortCol_0"]));
        sb.Append(";");
        sb.Append(" ");

        sb.Append(HttpContext.Current.Request.Params["sSortDir_0"]);

        orderByClause = sb.ToString();

        if (!String.IsNullOrEmpty(orderByClause))
        {
            orderByClause = orderByClause.Replace(";0;", ", DOA_DT ");
            orderByClause = orderByClause.Replace(";1;", ", DOA_DT ");
            orderByClause = orderByClause.Replace(";2;", ", DOJ ");
            orderByClause = orderByClause.Replace(";3;", ", userid ");
            orderByClause = orderByClause.Replace(";4;", ", name ");
            orderByClause = orderByClause.Replace(";5;", ", mobileno ");
			orderByClause = orderByClause.Replace(";6;", ", city ");
			orderByClause = orderByClause.Replace(";7;", ", ref_id ");
			orderByClause = orderByClause.Replace(";8;", ", ref_name ");
			orderByClause = orderByClause.Replace(";9;", ", ref_mobile ");
			orderByClause = orderByClause.Replace(";10;", ", T_INV ");
			orderByClause = orderByClause.Replace(";11;", ", T_AC ");
			orderByClause = orderByClause.Replace(";12;", ", T_IN_AC ");

            orderByClause = orderByClause.Remove(0, 1);

        }
        else
        {
            orderByClause = " DOA_DT ";
        }
        orderByClause = "ORDER BY " + orderByClause;

        sb.Clear();
        var numberOfRowsToReturn = "";
        numberOfRowsToReturn = iDisplayLength == -1 ? "TotalRows" : (iDisplayStart + iDisplayLength).ToString();
        string query = @" 
                             
                            declare @MA TABLE(sno bigint, DOJ DATETIME,DOA DATETIME, userid VARCHAR(50), name VARCHAR(100),mobileno VARCHAR(50), city VARCHAR(100),ref_id VARCHAR(50),ref_name VARCHAR(50),ref_mobile VARCHAR(50),T_INV int,T_AC int,T_IN_AC int )
                            INSERT
                            INTO
                                    @MA (DOJ, DOA, userid, name, mobileno, city, ref_id, ref_name, ref_mobile, T_INV, T_AC, T_IN_AC )

                                        SELECT CAST(v1.JOINDATE AS DATETIME) AS DOJ, CAST(v1.ACTIVATION_DATE AS DATETIME) AS DOA,v1.USERID AS userid,ltrim(v1.NAME) AS name, 
                                         v1.MOBILENO AS mobileno, c.city_name AS city, v1.REFERALID AS ref_id,v2.NAME AS ref_name, v1.REFERAL_MOBILE AS ref_mobile,
                                         d.PERSONAL_INVITED as  T_INV, d.PERSONAL_ACTIVATED as  T_AC,
                                         (d.PERSONAL_INVITED-d.PERSONAL_ACTIVATED) as  T_IN_AC
	                                        FROM ALL_MEMBERS_VIEW v1 inner join ALL_MEMBERS_VIEW v2 on v1.REFERALID=v2.USERID and v1.invalid_data_status =0
	                                         left outer join cities c on v1.city=c.city_id 
	                                          left outer join TBL_USER_INVITATIONS_DATA d on v1.userid=d.userid                                     
                                        
	                                {4}                   

                            SELECT * FROM
	                            (SELECT row_number() OVER ({0}) AS RowNumber , *
	                             FROM
		                             (  SELECT (SELECT count([@MA].userid) FROM  @MA) AS TotalRows
			                               , ( SELECT  count( [@MA].userid) FROM @MA {1}) AS TotalDisplayRows  
			                               ,[@MA].sno   
                                           ,CONVERT(varchar(17), [@MA].DOA , 113) DOA
			                               ,[@MA].DOJ /*CONVERT(varchar(17), [@MA].DOJ , 113) DOJ*/
                                           ,[@MA].DOA DOA_DT
			                               ,[@MA].userid
			                               ,[@MA].name   
			                               ,[@MA].mobileno    
			                               ,[@MA].city
			                               ,[@MA].ref_id   
			                               ,[@MA].ref_name 
			                               ,[@MA].ref_mobile    
			                               ,[@MA].T_INV
			                               ,[@MA].T_AC
			                               ,[@MA].T_IN_AC           
		                                FROM @MA {1}) RawResults) Results
                                 WHERE RowNumber BETWEEN {2} AND {3}";


        query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            var DB = new SqlCommand();
            DB.Connection = con;
            DB.CommandText = query;
            var data = DB.ExecuteReader();

            var totalDisplayRecords = "";
            var totalRecords = "";
            string outputJson = string.Empty;

            var rowClass = "";
            var count = 0;

            while (data.Read())
            {

                if (totalRecords.Length == 0)
                {
                    totalRecords = data["TotalRows"].ToString();
                    totalDisplayRecords = data["TotalDisplayRows"].ToString();
                }
                sb.Append("{");
                sb.AppendFormat(@"""DT_RowId"": ""{0}""", count++);
                sb.Append(",");
                sb.AppendFormat(@"""DT_RowClass"": ""{0}""", rowClass);
                sb.Append(",");
                sb.AppendFormat(@"""0"": ""{0}""", data["sno"]);
                sb.Append(",");
                sb.AppendFormat(@"""2"": ""{0}""", data["DOJ"]);
                sb.Append(",");
                sb.AppendFormat(@"""1"": ""{0}""", data["DOA_DT"]);
                sb.Append(",");
                sb.AppendFormat(@"""3"": ""{0}""", data["userid"]);
                sb.Append(",");
                sb.AppendFormat(@"""4"": ""{0}""", data["name"]);
                sb.Append(",");
                sb.AppendFormat(@"""5"": ""{0}""", data["mobileno"]);
                sb.Append(",");
                sb.AppendFormat(@"""6"": ""{0}""", data["city"]);
                sb.Append(",");
                sb.AppendFormat(@"""7"": ""{0}""", data["ref_id"]);
                sb.Append(",");
                sb.AppendFormat(@"""8"": ""{0}""", data["ref_name"]);
                sb.Append(",");
                sb.AppendFormat(@"""9"": ""{0}""", data["ref_mobile"]);
                sb.Append(",");
                sb.AppendFormat(@"""10"": ""{0}""", data["T_INV"]);
                sb.Append(",");
                sb.AppendFormat(@"""11"": ""{0}""", data["T_AC"]);
                sb.Append(",");
                sb.AppendFormat(@"""12"": ""{0}""", data["T_IN_AC"]);
                sb.Append("},");
            }//DOJ,DOA,userid, name,mobileno,city,ref_id,ref_name,ref_mobile,T_INV,T_AC,TOTAL_ELIGIBLE,T_IN_AC

            // handles zero records
            if (totalRecords.Length == 0)
            {
                sb.Append("{");
                sb.Append(@"""sEcho"": ");
                sb.AppendFormat(@"""{0}""", sEcho);
                sb.Append(",");
                sb.Append(@"""iTotalRecords"": 0");
                sb.Append(",");
                sb.Append(@"""iTotalDisplayRecords"": 0");
                sb.Append(", ");
                sb.Append(@"""aaData"": [ ");
                sb.Append("]}");
                outputJson = sb.ToString();

                return outputJson;
            }
            outputJson = sb.Remove(sb.Length - 1, 1).ToString();
            sb.Clear();

            sb.Append("{");
            sb.Append(@"""sEcho"": ");
            sb.AppendFormat(@"""{0}""", sEcho);
            sb.Append(",");
            sb.Append(@"""iTotalRecords"": ");
            sb.Append(totalRecords);
            sb.Append(",");
            sb.Append(@"""iTotalDisplayRecords"": ");
            sb.Append(totalDisplayRecords);
            sb.Append(", ");
            sb.Append(@"""aaData"": [ ");
            sb.Append(outputJson);
            sb.Append("]}");
            outputJson = sb.ToString();

            return outputJson;
        }


    }

    //4///////////////////End///////////////////////////Savitri///////////////////////End////////////////////////4/




    //5/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////5//
    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json,
     BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]
    public string UGetInActiveData()
    {
        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);
        int iDisplayLength = ToInt(HttpContext.Current.Request.Params["iDisplayLength"]);
        int iDisplayStart = ToInt(HttpContext.Current.Request.Params["iDisplayStart"]);
        string rawSearch = HttpContext.Current.Request.Params["sSearch"];
        var userid = HttpContext.Current.Request.Params["uid"].ToString(CultureInfo.CurrentCulture);

        string participant = HttpContext.Current.Request.Params["iParticipant"];

        var sb = new StringBuilder();
        //WHERE
        //                                  activeuser='NA'  AND referalID='"+ userid +"'
        var whereClause = string.Empty;
        if (participant != null)
        {
            if (participant.Length > 0)
            {
                sb.Append(" Where name like ");
                sb.Append("'%" + participant + "%'");
                sb.Append(" AND activeuser = ");
                sb.Append("NA");
                sb.Append(" AND referalID = ");
                sb.Append("'" + userid + "'");
                whereClause = sb.ToString();
            }
        }
        else
        {
            sb.Append(" Where activeuser = ");
            sb.Append("'NA'");
            sb.Append(" AND referalID = ");
            sb.Append("'" + userid + "'");
            whereClause = sb.ToString();
        }
        sb.Clear();

        var filteredWhere = string.Empty;

        var wrappedSearch = "'%" + rawSearch + "%'";

        if (rawSearch.Length > 0)
        {

            sb.Append(" WHERE joindate LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(wrappedSearch);
            sb.Append(" OR userid LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR mobileno LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR city LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR DOJ LIKE ");
            sb.Append(wrappedSearch);

            filteredWhere = sb.ToString();
        }


        //ORDERING

        sb.Clear();

        string orderByClause = string.Empty;
        sb.Append(";");
        sb.Append(ToInt(HttpContext.Current.Request.Params["iSortCol_0"]));
        sb.Append(";");
        sb.Append(" ");
        sb.Append(HttpContext.Current.Request.Params["sSortDir_0"]);

        orderByClause = sb.ToString();

        if (!String.IsNullOrEmpty(orderByClause))
        {

            orderByClause = orderByClause.Replace(";0;", ", userid ");
            orderByClause = orderByClause.Replace(";1;", ", name ");


            orderByClause = orderByClause.Remove(0, 1);
        }
        else
        {
            orderByClause = "DOJ DESC";
        }
        orderByClause = "ORDER BY " + orderByClause;

        sb.Clear();
        // string uu = HttpContext.Current.Session["userid"].ToString();
        var numberOfRowsToReturn = "";
        numberOfRowsToReturn = iDisplayLength == -1 ? "TotalRows" : (iDisplayStart + iDisplayLength).ToString();
        
        string query = @" declare @MA TABLE(sno bigint,  userid VARCHAR(50), name VARCHAR(100),joindate VARCHAR(50),emailid VARCHAR(50),mobileno VARCHAR(50), city VARCHAR(100))
                           INSERT INTO
                                    @MA ( userid, name,emailid,mobileno,joindate,city )
   	                                Select userid, name,emailid,mobileno,joindate,c.city_name
                                    FROM [tbl_freememreg]
                                    left outer join cities c on tbl_freememreg.city=c.city_id 
                                      
	                                {4}                   

                            SELECT *
                            FROM
	                            (SELECT row_number() OVER ({0}) AS RowNumber
		                              , TotalRows, TotalDisplayRows, userid, NAME, EMAILID, MOBILENO, JOINDATE, CITY
	                             FROM
		                             (SELECT (SELECT count([@MA].userid) FROM @MA) AS TotalRows
			                               , ( SELECT  count( [@MA].userid) FROM @MA {1}) AS TotalDisplayRows
			                               ,[@MA].userid
			                               ,[@MA].name   
			                               ,[@MA].emailid    
			                               ,[@MA].mobileno   
			                               ,[@MA].joindate   
                                           ,CAST([@MA].joindate AS DATETIME) DOJ
			                               ,[@MA].city        
		                              FROM
			                              @MA {1}) RawResults) Results
                            WHERE
	                            RowNumber BETWEEN {2} AND {3}";


        query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            var DB = new SqlCommand();
            DB.Connection = con;
            DB.CommandText = query;
            var data = DB.ExecuteReader();

            var totalDisplayRecords = "";
            var totalRecords = "";
            string outputJson = string.Empty;

            var rowClass = "";
            var count = 0;

            while (data.Read())
            {

                if (totalRecords.Length == 0)
                {
                    totalRecords = data["TotalRows"].ToString();
                    totalDisplayRecords = data["TotalDisplayRows"].ToString();
                }
                sb.Append("{");
                sb.AppendFormat(@"""DT_RowId"": ""{0}""", count++);
                sb.Append(",");
                sb.AppendFormat(@"""DT_RowClass"": ""{0}""", rowClass);
                //sb.Append(",");
                //sb.AppendFormat(@"""4"": ""{0}""", data["userid"]);
                sb.Append(",");
                sb.AppendFormat(@"""4"": ""{0}""", data["city"]);
                sb.Append(",");
                sb.AppendFormat(@"""1"": ""{0}""", data["name"]);
                sb.Append(",");
                sb.AppendFormat(@"""2"": ""{0}""", data["mobileno"]);
                sb.Append(",");
                sb.AppendFormat(@"""3"": ""{0}""", data["emailid"]);
                //sb.Append(",");
                //sb.AppendFormat(@"""3"": ""{0}""", data["joindate"]);
                sb.Append("},");
            }

            // handles zero records
            if (totalRecords.Length == 0)
            {
                sb.Append("{");
                sb.Append(@"""sEcho"": ");
                sb.AppendFormat(@"""{0}""", sEcho);
                sb.Append(",");
                sb.Append(@"""iTotalRecords"": 0");
                sb.Append(",");
                sb.Append(@"""iTotalDisplayRecords"": 0");
                sb.Append(", ");
                sb.Append(@"""aaData"": [ ");
                sb.Append("]}");
                outputJson = sb.ToString();

                return outputJson;
            }
            outputJson = sb.Remove(sb.Length - 1, 1).ToString();
            sb.Clear();

            sb.Append("{");
            sb.Append(@"""sEcho"": ");
            sb.AppendFormat(@"""{0}""", sEcho);
            sb.Append(",");
            sb.Append(@"""iTotalRecords"": ");
            sb.Append(totalRecords);
            sb.Append(",");
            sb.Append(@"""iTotalDisplayRecords"": ");
            sb.Append(totalDisplayRecords);
            sb.Append(", ");
            sb.Append(@"""aaData"": [ ");
            sb.Append(outputJson);
            sb.Append("]}");
            outputJson = sb.ToString();

            return outputJson;
        }

        // var connectionString = ConfigurationManager.ConnectionStrings["conn_str"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);

        //try
        //{
        //    conn.Open();
        //}
        //catch (Exception e)
        //{
        //    Console.WriteLine(e.ToString());
        //}


    }
    //5/////////////////////End/////////////////////////Savitri/////////////////////////////End/////////////////5//



    //6/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////6//
    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json,
     BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]
    public string AGetAffiliateData()
    {
        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);
        int iDisplayLength = ToInt(HttpContext.Current.Request.Params["iDisplayLength"]);
        int iDisplayStart = ToInt(HttpContext.Current.Request.Params["iDisplayStart"]);
        string rawSearch = HttpContext.Current.Request.Params["sSearch"];
        var userid = HttpContext.Current.Request.Params["uid"].ToString(CultureInfo.CurrentCulture);

        string participant = HttpContext.Current.Request.Params["iParticipant"];

        var sb = new StringBuilder();
        //WHERE
        //                                  activeuser='NA'  AND referalID='"+ userid +"'
        var whereClause = string.Empty;
        if (participant != null)
        {
            if (participant.Length > 0)
            {
                sb.Append(" Where name like ");
                sb.Append("'%" + participant + "%'");
                sb.Append(" AND activeuser = ");
                sb.Append("NA");
                sb.Append(" AND referalID = ");
                sb.Append("'" + userid + "'");
                whereClause = sb.ToString();
            }
        }
        sb.Clear();

        var filteredWhere = string.Empty;

        var wrappedSearch = "'%" + rawSearch + "%'";

        if (rawSearch.Length > 0)
        {

            sb.Append(" WHERE DOAF LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR DOA LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR DOJ LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR userid LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR mobileno LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR city LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_id LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_mobile LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_INV LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_AC LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_IN_AC LIKE ");
            sb.Append(wrappedSearch);

            filteredWhere = sb.ToString();
        }


        //ORDERING

        sb.Clear();

        string orderByClause = string.Empty;
        sb.Append(";");
        sb.Append(ToInt(HttpContext.Current.Request.Params["iSortCol_0"]));
        sb.Append(";");
        sb.Append(" ");

        sb.Append(HttpContext.Current.Request.Params["sSortDir_0"]);

        orderByClause = sb.ToString();

        if (!String.IsNullOrEmpty(orderByClause))
        {

            //orderByClause = orderByClause.Replace("0", ", userid ");
            //orderByClause = orderByClause.Replace("1", ", name ");


            orderByClause = orderByClause.Replace(";0;", ", DOAF ");
            orderByClause = orderByClause.Replace(";1;", ", DOAF ");
            orderByClause = orderByClause.Replace(";2;", ", DOA ");
            orderByClause = orderByClause.Replace(";3;", ", DOJ ");
            orderByClause = orderByClause.Replace(";4;", ", userid ");
            orderByClause = orderByClause.Replace(";5;", ", name ");
            orderByClause = orderByClause.Replace(";6;", ", mobileno ");
            orderByClause = orderByClause.Replace(";7;", ", city ");
            orderByClause = orderByClause.Replace(";8;", ", ref_id ");
            orderByClause = orderByClause.Replace(";9;", ", ref_name ");
            orderByClause = orderByClause.Replace(";10;", ", ref_mobile ");
            orderByClause = orderByClause.Replace(";11;", ", T_INV ");
            orderByClause = orderByClause.Replace(";12;", ", T_AC ");
            orderByClause = orderByClause.Replace(";13;", ", T_IN_AC ");


            orderByClause = orderByClause.Remove(0, 1);
        }
        else
        {
            orderByClause = "DOAF DESC";
        }
        orderByClause = "ORDER BY " + orderByClause;

        sb.Clear();
        // string uu = HttpContext.Current.Session["userid"].ToString();
        var numberOfRowsToReturn = "";
        numberOfRowsToReturn = iDisplayLength == -1 ? "TotalRows" : (iDisplayStart + iDisplayLength).ToString();

        string query = @"declare @MA TABLE(sno bigint,  userid VARCHAR(50), name VARCHAR(100),DOJ datetime,DOA datetime,DOAF datetime,mobileno VARCHAR(50), city VARCHAR(100),ref_id VARCHAR(50),ref_name VARCHAR(50),ref_mobile VARCHAR(50),T_INV int,T_AC int,T_IN_AC int )
                        INSERT INTO @MA 
                        ( DOJ,DOA, DOAF,userid, name,mobileno,city,ref_id,ref_name,ref_mobile,T_INV,T_AC,T_IN_AC)
            SELECT CAST(R1.JOINDATE AS DATETIME) AS DOJ, R1.ACTIVATION_DATE AS DOA, R1.AFFILIATE_DATE AS DOAF, R1.USERID , R1.FULLNAME AS name, 
             R1.MOBILENO , c.city_name AS city, R1.REFERID AS ref_id, v2.NAME AS ref_name, R1.SponsorUserID AS ref_mobile,
             d.PERSONAL_INVITED as  T_INV, d.PERSONAL_ACTIVATED as  T_AC,
             (d.PERSONAL_INVITED-d.PERSONAL_ACTIVATED) as  T_INA
                FROM tbl_registration R1 
					inner join ALL_MEMBERS_VIEW v2 on R1.REFERID = v2.USERID
					left outer join cities c on R1.city=c.city_id 
					left outer join TBL_USER_INVITATIONS_DATA d on R1.userid=d.userid       
                                      
	                                {4}                   

                            SELECT *
                            FROM
	                            (SELECT row_number() OVER ({0}) AS RowNumber
		                              , *
	                             FROM
		                             (SELECT (SELECT count([@MA].userid)
				                              FROM
					                              @MA) AS TotalRows
			                               
                                           ,( SELECT  count( [@MA].userid) FROM @MA ) AS TotalDisplayRows  

			                               ,[@MA].sno   
                                           ,CONVERT(varchar(17), [@MA].DOJ , 113) DOJ
                                           ,CONVERT(varchar(17), [@MA].DOA , 113) DOA
                                           ,CONVERT(varchar(17), [@MA].DOAF , 113) DOAF 
                                           ,[@MA].userid
                                           ,[@MA].name   
                                           ,[@MA].mobileno    
                                           ,[@MA].city
                                           ,[@MA].ref_id   
                                           ,[@MA].ref_name 
                                           ,[@MA].ref_mobile    
                                           ,[@MA].T_INV
                                           ,[@MA].T_AC 
                                           ,[@MA].T_IN_AC      
		                              FROM
			                              @MA {1}) RawResults) Results
                            WHERE
	                            RowNumber BETWEEN {2} AND {3}";


        query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            var DB = new SqlCommand();
            DB.Connection = con;
            DB.CommandText = query;
            var data = DB.ExecuteReader();

            var totalDisplayRecords = "";
            var totalRecords = "";
            string outputJson = string.Empty;

            var rowClass = "";
            var count = 0;

            while (data.Read())
            {

                if (totalRecords.Length == 0)
                {
                    totalRecords = data["TotalRows"].ToString();
                    totalDisplayRecords = data["TotalDisplayRows"].ToString();
                }
                sb.Append("{");
                sb.AppendFormat(@"""DT_RowId"": ""{0}""", count++);
                sb.Append(",");
                sb.AppendFormat(@"""DT_RowClass"": ""{0}""", rowClass);
                sb.Append(",");
                sb.AppendFormat(@"""0"": ""{0}""", data["sno"]);
                sb.Append(",");
                sb.AppendFormat(@"""1"": ""{0}""", data["DOAF"]);
                sb.Append(",");
                sb.AppendFormat(@"""2"": ""{0}""", data["DOA"]);
                sb.Append(",");
                sb.AppendFormat(@"""3"": ""{0}""", data["DOJ"]);
                sb.Append(",");
                sb.AppendFormat(@"""4"": ""{0}""", data["userid"]);
                sb.Append(",");
                sb.AppendFormat(@"""5"": ""{0}""", data["name"]);
                sb.Append(",");
                sb.AppendFormat(@"""6"": ""{0}""", data["mobileno"]);
                sb.Append(",");
                sb.AppendFormat(@"""7"": ""{0}""", data["city"]);
                sb.Append(",");
                sb.AppendFormat(@"""8"": ""{0}""", data["ref_id"]);
                sb.Append(",");
                sb.AppendFormat(@"""9"": ""{0}""", data["ref_name"]);
                sb.Append(",");
                sb.AppendFormat(@"""10"": ""{0}""", data["ref_mobile"]);
                sb.Append(",");
                sb.AppendFormat(@"""11"": ""{0}""", data["T_INV"]);
                sb.Append(",");
                sb.AppendFormat(@"""12"": ""{0}""", data["T_AC"]);
                sb.Append(",");
                sb.AppendFormat(@"""13"": ""{0}""", data["T_IN_AC"]);
                sb.Append("},");
            }

            // handles zero records
            if (totalRecords.Length == 0)
            {
                sb.Append("{");
                sb.Append(@"""sEcho"": ");
                sb.AppendFormat(@"""{0}""", sEcho);
                sb.Append(",");
                sb.Append(@"""iTotalRecords"": 0");
                sb.Append(",");
                sb.Append(@"""iTotalDisplayRecords"": 0");
                sb.Append(", ");
                sb.Append(@"""aaData"": [ ");
                sb.Append("]}");
                outputJson = sb.ToString();

                return outputJson;
            }
            outputJson = sb.Remove(sb.Length - 1, 1).ToString();
            sb.Clear();

            sb.Append("{");
            sb.Append(@"""sEcho"": ");
            sb.AppendFormat(@"""{0}""", sEcho);
            sb.Append(",");
            sb.Append(@"""iTotalRecords"": ");
            sb.Append(totalRecords);
            sb.Append(",");
            sb.Append(@"""iTotalDisplayRecords"": ");
            sb.Append(totalDisplayRecords);
            sb.Append(", ");
            sb.Append(@"""aaData"": [ ");
            sb.Append(outputJson);
            sb.Append("]}");
            outputJson = sb.ToString();

            return outputJson;
        }

        // var connectionString = ConfigurationManager.ConnectionStrings["conn_str"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);

        //try
        //{
        //    conn.Open();
        //}
        //catch (Exception e)
        //{
        //    Console.WriteLine(e.ToString());
        //}


    }
    //6/////////////////////End/////////////////////////Savitri/////////////////////////////End/////////////////6//


    //7/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////7//
    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json,
     BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]
    public string AGetPremiumAffiliateData()
    {
        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);
        int iDisplayLength = ToInt(HttpContext.Current.Request.Params["iDisplayLength"]);
        int iDisplayStart = ToInt(HttpContext.Current.Request.Params["iDisplayStart"]);
        string rawSearch = HttpContext.Current.Request.Params["sSearch"];
        var userid = HttpContext.Current.Request.Params["uid"].ToString(CultureInfo.CurrentCulture);

        string participant = HttpContext.Current.Request.Params["iParticipant"];

        var sb = new StringBuilder();
        //WHERE
        //                                  activeuser='NA'  AND referalID='"+ userid +"'
        var whereClause = string.Empty;
        if (participant != null)
        {
            if (participant.Length > 0)
            {
                sb.Append(" Where name like ");
                sb.Append("'%" + participant + "%'");
                sb.Append(" AND activeuser = ");
                sb.Append("NA");
                sb.Append(" AND referalID = ");
                sb.Append("'" + userid + "'");
                whereClause = sb.ToString();
            }
        }
        sb.Clear();

        var filteredWhere = string.Empty;

        var wrappedSearch = "'%" + rawSearch + "%'";

        if (rawSearch.Length > 0)
        {

            sb.Append(" WHERE DOAF LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR userid LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR mobileno LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR city LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_id LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_mobile LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR BV LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_INV LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_AC LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_IN_AC LIKE ");
            sb.Append(wrappedSearch);

            filteredWhere = sb.ToString();
        }


        //ORDERING

        sb.Clear();

        string orderByClause = string.Empty;
        sb.Append(";");
        sb.Append(ToInt(HttpContext.Current.Request.Params["iSortCol_0"]));
        sb.Append(";");
        sb.Append(" ");

        sb.Append(HttpContext.Current.Request.Params["sSortDir_0"]);

        orderByClause = sb.ToString();

        if (!String.IsNullOrEmpty(orderByClause))
        {

            //orderByClause = orderByClause.Replace("0", ", userid ");
            //orderByClause = orderByClause.Replace("1", ", name ");


            orderByClause = orderByClause.Replace(";0;", ", DOAF ");
            orderByClause = orderByClause.Replace(";1;", ", DOAF ");
            orderByClause = orderByClause.Replace(";2;", ", userid ");
            orderByClause = orderByClause.Replace(";3;", ", name ");
            orderByClause = orderByClause.Replace(";4;", ", mobileno ");
            orderByClause = orderByClause.Replace(";5;", ", city ");
            orderByClause = orderByClause.Replace(";6;", ", ref_id ");
            orderByClause = orderByClause.Replace(";7;", ", ref_name ");
            orderByClause = orderByClause.Replace(";8;", ", ref_mobile ");
            orderByClause = orderByClause.Replace(";9;", ", BV ");
            orderByClause = orderByClause.Replace(";10;", ", T_INV ");
            orderByClause = orderByClause.Replace(";11;", ", T_AC ");
            orderByClause = orderByClause.Replace(";12;", ", T_IN_AC ");

            orderByClause = orderByClause.Remove(0, 1);
        }
        else
        {
            orderByClause = "DOAF DESC";
        }
        orderByClause = "ORDER BY " + orderByClause;

        sb.Clear();
        // string uu = HttpContext.Current.Session["userid"].ToString();
        var numberOfRowsToReturn = "";
        numberOfRowsToReturn = iDisplayLength == -1 ? "TotalRows" : (iDisplayStart + iDisplayLength).ToString();

        string query = @"declare @MA TABLE(sno bigint, DOAF datetime, userid VARCHAR(50), name VARCHAR(100),mobileno VARCHAR(50), city VARCHAR(100),ref_id VARCHAR(50),ref_name VARCHAR(50),ref_mobile VARCHAR(50),BV int,T_INV int,T_AC int,T_IN_AC int )
                        INSERT INTO @MA 
                        ( DOAF,userid, name,mobileno,city,ref_id,ref_name,ref_mobile,T_INV,T_AC,T_IN_AC)
            SELECT R1.AFFILIATE_DATE AS DOAF, R1.USERID , R1.FULLNAME AS name, 
             R1.MOBILENO , c.city_name AS city, R1.REFERID AS ref_id, v2.NAME AS ref_name, R1.SponsorUserID AS ref_mobile,
             d.PERSONAL_INVITED as  T_INV, d.PERSONAL_ACTIVATED as  T_AC,
             (d.PERSONAL_INVITED-d.PERSONAL_ACTIVATED) as  T_INA
              FROM TBL_PREMIUM_AFFILIATES PAF   left outer join tbl_registration R1 on PAF.userid = R1.userid
               
					inner join ALL_MEMBERS_VIEW v2 on r1.REFERID = v2.USERID  and v2.invalid_data_status =0
					left outer join cities c on R1.city=c.city_id 
					left outer join TBL_USER_INVITATIONS_DATA d on PAF.userid=d.userid      
                                      
	                                {4}                   

                            SELECT *
                            FROM
	                            (SELECT row_number() OVER ({0}) AS RowNumber
		                              , *
	                             FROM
		                             (SELECT (SELECT count([@MA].userid)
				                              FROM
					                              @MA) AS TotalRows
			                               
                                           ,( SELECT  count( [@MA].userid) FROM @MA ) AS TotalDisplayRows  

			                               ,[@MA].sno  
                                           ,[@MA].DOAF
                                           ,[@MA].userid
                                           ,[@MA].name   
                                           ,[@MA].mobileno    
                                           ,[@MA].city
                                           ,[@MA].ref_id   
                                           ,[@MA].ref_name 
                                           ,[@MA].ref_mobile  
                                           , 0 as BV   
                                           ,[@MA].T_INV
                                           ,[@MA].T_AC 
                                           ,[@MA].T_IN_AC      
		                              FROM
			                              @MA {1}) RawResults) Results
                            WHERE
	                            RowNumber BETWEEN {2} AND {3}";


        query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            var DB = new SqlCommand();
            DB.Connection = con;
            DB.CommandText = query;
            var data = DB.ExecuteReader();

            var totalDisplayRecords = "";
            var totalRecords = "";
            string outputJson = string.Empty;

            var rowClass = "";
            var count = 0;

            while (data.Read())
            {

                if (totalRecords.Length == 0)
                {
                    totalRecords = data["TotalRows"].ToString();
                    totalDisplayRecords = data["TotalDisplayRows"].ToString();
                }
                sb.Append("{");
                sb.AppendFormat(@"""DT_RowId"": ""{0}""", count++);
                sb.Append(",");
                sb.AppendFormat(@"""DT_RowClass"": ""{0}""", rowClass);
                sb.Append(",");
                sb.AppendFormat(@"""0"": ""{0}""", data["sno"]);
                sb.Append(",");
                sb.AppendFormat(@"""1"": ""{0}""", data["DOAF"]);
                sb.Append(",");
                sb.AppendFormat(@"""2"": ""{0}""", data["userid"]);
                sb.Append(",");
                sb.AppendFormat(@"""3"": ""{0}""", data["name"]);
                sb.Append(",");
                sb.AppendFormat(@"""4"": ""{0}""", data["mobileno"]);
                sb.Append(",");
                sb.AppendFormat(@"""5"": ""{0}""", data["city"]);
                sb.Append(",");
                sb.AppendFormat(@"""6"": ""{0}""", data["ref_id"]);
                sb.Append(",");
                sb.AppendFormat(@"""7"": ""{0}""", data["ref_name"]);
                sb.Append(",");
                sb.AppendFormat(@"""8"": ""{0}""", data["ref_mobile"]);
                sb.Append(",");
                sb.AppendFormat(@"""9"": ""{0}""", data["BV"]);
                sb.Append(",");
                sb.AppendFormat(@"""10"": ""{0}""", data["T_INV"]);
                sb.Append(",");
                sb.AppendFormat(@"""11"": ""{0}""", data["T_AC"]);
                sb.Append(",");
                sb.AppendFormat(@"""12"": ""{0}""", data["T_IN_AC"]);
                sb.Append("},");
            }

            // handles zero records
            if (totalRecords.Length == 0)
            {
                sb.Append("{");
                sb.Append(@"""sEcho"": ");
                sb.AppendFormat(@"""{0}""", sEcho);
                sb.Append(",");
                sb.Append(@"""iTotalRecords"": 0");
                sb.Append(",");
                sb.Append(@"""iTotalDisplayRecords"": 0");
                sb.Append(", ");
                sb.Append(@"""aaData"": [ ");
                sb.Append("]}");
                outputJson = sb.ToString();

                return outputJson;
            }
            outputJson = sb.Remove(sb.Length - 1, 1).ToString();
            sb.Clear();

            sb.Append("{");
            sb.Append(@"""sEcho"": ");
            sb.AppendFormat(@"""{0}""", sEcho);
            sb.Append(",");
            sb.Append(@"""iTotalRecords"": ");
            sb.Append(totalRecords);
            sb.Append(",");
            sb.Append(@"""iTotalDisplayRecords"": ");
            sb.Append(totalDisplayRecords);
            sb.Append(", ");
            sb.Append(@"""aaData"": [ ");
            sb.Append(outputJson);
            sb.Append("]}");
            outputJson = sb.ToString();

            return outputJson;
        }

        // var connectionString = ConfigurationManager.ConnectionStrings["conn_str"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);

        //try
        //{
        //    conn.Open();
        //}
        //catch (Exception e)
        //{
        //    Console.WriteLine(e.ToString());
        //}


    }
    //7/////////////////////End/////////////////////////Savitri/////////////////////////////End/////////////////7//

    //8///////////////////Start/////////////////////////Savitri/////////////////////////////Start////////////////8//

    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json,
     BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]

    public string UGetAllData()
    {
        int sEcho = ToInt(HttpContext.Current.Request.Params["sEcho"]);
        int iDisplayLength = ToInt(HttpContext.Current.Request.Params["iDisplayLength"]);
        int iDisplayStart = ToInt(HttpContext.Current.Request.Params["iDisplayStart"]);
        string rawSearch = HttpContext.Current.Request.Params["sSearch"];
        var userid = HttpContext.Current.Request.Params["uid"].ToString(CultureInfo.CurrentCulture);

        string participant = HttpContext.Current.Request.Params["iParticipant"];

        var sb = new StringBuilder();

        var whereClause = string.Empty;
        if (participant != null)
        {
            if (participant.Length > 0)
            {
                sb.Append(" Where name like ");
                sb.Append("'%" + participant + "%'");
                whereClause = sb.ToString();
            }
        }


        sb.Clear();

        var filteredWhere = string.Empty;

        var wrappedSearch = "'%" + rawSearch + "%'";

        if (rawSearch.Length > 0)
        {

            sb.Append(" WHERE joindate LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR userid LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR mobileno LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR city LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_id LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_name LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR ref_mobile LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_INV LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_AC LIKE ");
            sb.Append(wrappedSearch);
            sb.Append(" OR T_IN_AC LIKE ");
            sb.Append(wrappedSearch);

            filteredWhere = sb.ToString();
        }


        //ORDERING

        sb.Clear();

        string orderByClause = string.Empty;
        sb.Append(ToInt(HttpContext.Current.Request.Params["iSortCol_0"]));

        sb.Append(" ");

        sb.Append(HttpContext.Current.Request.Params["sSortDir_0"]);

        orderByClause = sb.ToString();

        if (!String.IsNullOrEmpty(orderByClause))
        {

            orderByClause = orderByClause.Replace("0", ", userid ");
            orderByClause = orderByClause.Replace("1", ", name ");


            orderByClause = orderByClause.Remove(0, 1);
        }
        else
        {
            orderByClause = "name ASC";
        }
        orderByClause = "ORDER BY " + orderByClause;

        sb.Clear();
        // string uu = HttpContext.Current.Session["userid"].ToString();
        var numberOfRowsToReturn = "";
        numberOfRowsToReturn = iDisplayLength == -1 ? "TotalRows" : (iDisplayStart + iDisplayLength).ToString();
        string query = @" 
                             
                            declare @MA TABLE(sno bigint,  userid nVARCHAR(50), name VARCHAR(100),joindate nVARCHAR(50),emailid nVARCHAR(50),mobileno nVARCHAR(50), city VARCHAR(100),ref_id nVARCHAR(50),ref_name nVARCHAR(50),ref_mobile nVARCHAR(50),T_INV int,T_AC int,T_IN_AC int )
                            INSERT
                            INTO
                                    @MA ( joindate,userid, name,mobileno,city,ref_id,ref_name,ref_mobile,T_INV,T_AC,T_IN_AC)

                                        SELECT CAST(v1.JOINDATE AS DATETIME) AS joindate,v1.USERID AS userid, v1.NAME AS name, 
                                         v1.MOBILENO AS mobileno, c.cityname AS city, v1.REFERALID AS ref_id,v2.NAME AS ref_name, v1.REFERAL_MOBILE AS ref_mobile,
                                         d.PERSONAL_INVITED as  T_INV, d.PERSONAL_ACTIVATED as  T_AC,
                                         (d.PERSONAL_INVITED-d.PERSONAL_ACTIVATED) as  T_IN_AC
	                                        FROM ALL_MEMBERS_VIEW v1 inner join ALL_MEMBERS_VIEW v2 on v1.REFERALID=v2.USERID
	                                         left outer join tbl_cities c on v1.city=c.cityid 
	                                          left outer join TBL_USER_INVITATIONS_DATA d on v1.userid=d.userid                                     
                                        
	                                {4}                   

                            SELECT *
                            FROM
	                            (SELECT row_number() OVER ({0}) AS RowNumber
		                              , *
	                             FROM
		                             (SELECT (SELECT count([@MA].userid)
				                              FROM
					                              @MA) AS TotalRows
			                               , ( SELECT  count( [@MA].userid) FROM @MA {1}) AS TotalDisplayRows  
			                               ,[@MA].joindate   			   
			                               ,[@MA].userid
			                               ,[@MA].name   
			                               ,[@MA].mobileno    
			                               ,[@MA].city
			                               ,[@MA].ref_id   
			                               ,[@MA].ref_name 
			                               ,[@MA].ref_mobile    
			                               ,[@MA].T_INV
			                               ,[@MA].T_AC 
			                               ,[@MA].T_IN_AC           
		                              FROM
			                              @MA {1}) RawResults) Results
                            WHERE
	                            RowNumber BETWEEN {2} AND {3}";


        query = String.Format(query, orderByClause, filteredWhere, iDisplayStart + 1, numberOfRowsToReturn, whereClause);

        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString(); ;
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            var DB = new SqlCommand();
            DB.Connection = con;
            DB.CommandText = query;
            var data = DB.ExecuteReader();

            var totalDisplayRecords = "";
            var totalRecords = "";
            string outputJson = string.Empty;

            var rowClass = "";
            var count = 0;

            while (data.Read())
            {

                if (totalRecords.Length == 0)
                {
                    totalRecords = data["TotalRows"].ToString();
                    totalDisplayRecords = data["TotalDisplayRows"].ToString();
                }
                sb.Append("{");
                sb.AppendFormat(@"""DT_RowId"": ""{0}""", count++);
                sb.Append(",");
                sb.AppendFormat(@"""DT_RowClass"": ""{0}""", rowClass);
                sb.Append(",");
                sb.AppendFormat(@"""0"": ""{0}""", data["joindate"]);
                sb.Append(",");
                sb.AppendFormat(@"""1"": ""{0}""", data["userid"]);
                sb.Append(",");
                sb.AppendFormat(@"""2"": ""{0}""", data["name"]);
                sb.Append(",");
                sb.AppendFormat(@"""3"": ""{0}""", data["mobileno"]);
                sb.Append(",");
                sb.AppendFormat(@"""4"": ""{0}""", data["city"]);
                sb.Append(",");
                sb.AppendFormat(@"""5"": ""{0}""", data["ref_id"]);
                sb.Append(",");
                sb.AppendFormat(@"""6"": ""{0}""", data["ref_name"]);
                sb.Append(",");
                sb.AppendFormat(@"""7"": ""{0}""", data["ref_mobile"]);
                sb.Append(",");
                sb.AppendFormat(@"""8"": ""{0}""", data["T_INV"]);
                sb.Append(",");
                sb.AppendFormat(@"""9"": ""{0}""", data["T_AC"]);
                sb.Append(",");
                sb.AppendFormat(@"""10"": ""{0}""", data["T_IN_AC"]);
                sb.Append("},");
            }//joindate,userid, name,mobileno,city,ref_id,ref_name,ref_mobile,T_INV,T_AC,TOTAL_ELIGIBLE,T_IN_AC

            // handles zero records
            if (totalRecords.Length == 0)
            {
                sb.Append("{");
                sb.Append(@"""sEcho"": ");
                sb.AppendFormat(@"""{0}""", sEcho);
                sb.Append(",");
                sb.Append(@"""iTotalRecords"": 0");
                sb.Append(",");
                sb.Append(@"""iTotalDisplayRecords"": 0");
                sb.Append(", ");
                sb.Append(@"""aaData"": [ ");
                sb.Append("]}");
                outputJson = sb.ToString();

                return outputJson;
            }
            outputJson = sb.Remove(sb.Length - 1, 1).ToString();
            sb.Clear();

            sb.Append("{");
            sb.Append(@"""sEcho"": ");
            sb.AppendFormat(@"""{0}""", sEcho);
            sb.Append(",");
            sb.Append(@"""iTotalRecords"": ");
            sb.Append(totalRecords);
            sb.Append(",");
            sb.Append(@"""iTotalDisplayRecords"": ");
            sb.Append(totalDisplayRecords);
            sb.Append(", ");
            sb.Append(@"""aaData"": [ ");
            sb.Append(outputJson);
            sb.Append("]}");
            outputJson = sb.ToString();

            return outputJson;
        }

    }

    ////8//////////////////End///////////////////////////Savitri///////////////////////End///////////////////////8//
}
