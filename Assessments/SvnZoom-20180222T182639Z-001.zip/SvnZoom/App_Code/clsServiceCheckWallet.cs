﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.Services;
using System.Web.Script.Services;
using System.ServiceModel.Web;

/// <summary>
/// Summary description for clsServiceCheckWallet
/// </summary>
public class clsServiceCheckWallet : BaseClass
{
    SqlTransaction Transaction = null;
    HttpContext context;
    string emailId = HttpContext.Current.Request.Params["emailId"];
    string password = HttpContext.Current.Request.Params["password"];
    string amount = HttpContext.Current.Request.Params["amount"];
    string outputJson = string.Empty;

    [WebMethod]
    [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json,BodyStyle = WebMessageBodyStyle.Bare, Method = "GET")]
    public virtual string validateWalletDetails(string emailId, string password, string amount)
    {
        string result = "";
       // string searchText = context.Request.QueryString["q"];
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str"].ToString();
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();
                Transaction = con.BeginTransaction();
                //SqlConnection con = new SqlConnection("Data Source=SERVER;user id=sqluser;password=sqluser;persist security info=true; Initial Catalog=MFLOAT_DB");
                
                //SqlCommand cmd = new SqlCommand("SELECT f.FULLNAME, f.USER_ID, i.imagename FROM TMP_USER_DATA f INNER JOIN tbl_imagedetail i ON f.USER_ID = i.userid where f.USER_ID Like @Search + '%'", con);
                string SQLQuery = "SELECT UW.USERID+'##'+MBOILE+'##'+ CASE WHEN ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) < " + amount + " THEN CAST(ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) AS NVARCHAR) ELSE '" + amount + "' END AS WALLET_BALANCE FROM TBL_USER_WALLET_CURRENT_BALANCES UWCB INNER JOIN TBL_USERWALLET UW ON UWCB.USERID = UW.USERID WHERE UW.EMAILID = '" + emailId + "' AND UW.PASSWORD = '" + password + "'";

                
                result= GetSingleValue(SQLQuery, true);

                if (result == null || result.Equals(""))
                {
                    result = "Invalid Email Id or Password";
                }

                //System.out.println("Result..........."+result);

                return result;
            }
            catch
            {
                return result;
            }
            finally
            {
                con.Close();
            }
        }

        //string result = "";
        //Session session = HibernateUtil.SessionFactory.openSession();

        //try
        //{
        //    SqlConnection db = new SqlConnection("connstringhere");
        //    Transaction = db.BeginTransaction();
        //    Query query = session.createSQLQuery("SELECT UW.USERID+'##'+MBOILE+'##'+ CASE WHEN ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) < " + amount + " THEN CAST(ISNULL(INVITATION_BONUS_AMT,0)+ISNULL(GIFT_AMOUNT,0) AS NVARCHAR) ELSE '" + amount + "' END AS WALLET_BALANCE FROM TBL_USER_WALLET_CURRENT_BALANCES UWCB INNER JOIN TBL_USERWALLET UW ON UWCB.USERID = UW.USERID WHERE UW.EMAILID = :emailId AND UW.PASSWORD = :password");
        //    query.setString("emailId", emailId);
        //    query.setString("password", password);
        //    result = (string)query.uniqueResult();

        //    if (result == null || result.Equals(""))
        //    {
        //        result = "Invalid Email Id or Password";
        //    }

        //    //System.out.println("Result..........."+result);

        //}
        //finally
        //{
        //    session.close();
        //}
        //return result;
    }

	public clsServiceCheckWallet()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}