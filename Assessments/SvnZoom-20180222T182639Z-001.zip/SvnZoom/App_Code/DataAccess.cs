﻿/****************************** Module Header ******************************\
* Module Name:    DataAccess.cs
* Project:        CSASPNETSearchEngine
* Copyright (c) Microsoft Corporation
*
* This class is a Data Access Layer which does database operations.
* 
* This source is subject to the Microsoft Public License.
* See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL.
* All other rights reserved.
*
\*****************************************************************************/

using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

//namespace CSASPNETSearchEngine
//{
    /// <summary>
    /// This class is used to access database.
    /// </summary>
    public class DataAccess
    {
        /// <summary>
        /// Retrieve an individual record from database.
        /// </summary>
        /// <param name="id">Record id</param>
        /// <returns>A found record</returns>
        public Article GetArticle(long id)
        {
            List<Article> articles = QueryList("select * from [TABLE_SPORTSANDNEWS] where [sno] = " + id.ToString());

            // Only return the first record.
            if (articles.Count > 0)
            {
                return articles[0];
            }
            return null;
        }

        /// <summary>
        /// Retrieve all records from database.
        /// </summary>
        /// <returns></returns>
        public List<Article> GetAll()
        {
            return QueryList("select * from [TABLE_SPORTSANDNEWS]");
        }

        /// <summary>
        /// Search records from database.
        /// </summary>
        /// <param name="keywords">the list of keywords</param>
        /// <returns>all found records</returns>
        public List<Article> Search(List<string> keywords, string tablename, string column1, string column2)
        {
            // Generate a complex Sql command.
            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.Append("select title, dbo.udf_StripHTML(content) from  ");
            sqlBuilder.Append(tablename );
            sqlBuilder.Append(" where ");
            foreach (string item in keywords)
            {
                sqlBuilder.AppendFormat("(" + column1 + " like '%{0}%' or " + column2 + " like '%{0}%') and ", item);
               // sqlBuilder.AppendFormat("([Title] like '%{0}%' or [DEscription] like '%{0}%') and ", item);
            }

            // Remove unnecessary string " and " at the end of the command.
            string sql = sqlBuilder.ToString(0, sqlBuilder.Length - 5);

            return QueryList(sql);
        }

        #region Helpers

        /// <summary>
        /// Create a connected SqlCommand object.
        /// </summary>
        /// <param name="cmdText">Command text</param>
        /// <returns>SqlCommand object</returns>
        protected SqlCommand GenerateSqlCommand(string cmdText)
        {

            SqlConnection conn =new SqlConnection( ConfigurationManager.AppSettings["conn_str"].ToString());
            // Read Connection String from web.config file.
            //SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyDatabaseConnectionString"].ConnectionString);
            SqlCommand cmd = new SqlCommand(cmdText, conn);
            cmd.Connection.Open();
            return cmd;
        }

        /// <summary>
        /// Create an Article object from a SqlDataReader object.
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        protected Article ReadArticle(SqlDataReader reader)
        {
            Article article = new Article();

            article.ID = (long)reader["sno"];
            article.Title = (string)reader["Title"];
            article.Content = (string)reader["Description"];

            return article;
        }

        /// <summary>
        /// Excute a Sql command.
        /// </summary>
        /// <param name="cmdText">Command text</param>
        /// <returns></returns>
        protected List<Article> QueryList(string cmdText)
        {
            List<Article> articles = new List<Article>();

            SqlCommand cmd = GenerateSqlCommand(cmdText);
            using (cmd.Connection)
            {
                SqlDataReader reader = cmd.ExecuteReader();

                // Transform records to a list.
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        articles.Add(ReadArticle(reader));
                    }
                }
            }
            return articles;
        }

        #endregion
    }
//}