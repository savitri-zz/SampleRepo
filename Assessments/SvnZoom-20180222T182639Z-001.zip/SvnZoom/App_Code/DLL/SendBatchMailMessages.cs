using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.IO;

/// <summary>
/// Summary description for SendBatchMailMessages
/// </summary>
public class SendBatchMailMessages
{
	public SendBatchMailMessages()
	{
		//
		// TODO: Add constructor logic here
		//
        string host = CommonSetting.smtphost.ToString();
        SendMail(host);
	}

    private void SendMail(string hostname)
    {

        string to = "";
        string from = "";
        string[] filename = new string[3];
        string msgText = "";
        string subject = "";
        string bannerfile = "";
        string programid = "";
        DateTime submitDate = new DateTime();
        
        string participantid = "";
        string JobID = "";

        try
        {
            
            DataTable dt = new DataTable();
            dt = GetUnsentMails();
            DataTable participantInfo = null;
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                to = dt.Rows[i]["EmailId"].ToString();
                from = dt.Rows[i]["From"].ToString();
                participantid = dt.Rows[i]["participantId"].ToString();
                JobID = dt.Rows[i]["jobid"].ToString();
                string jobstatus = GetJobStatus(JobID);
                if (!jobstatus.Equals(""))
                {
                    continue;
                }
                participantInfo = GetParticipantInfo(participantid);
                msgText = ReplaceParticipantTags(participantInfo,dt.Rows[i]["MsgText"].ToString());
                subject = dt.Rows[i]["Subject"].ToString();
                programid = dt.Rows[i]["programid"].ToString();
                subject = dt.Rows[i]["Subject"].ToString();
                string dirName = dt.Rows[i]["ProgramId"].ToString();

                DirectoryInfo objDir = new DirectoryInfo(HttpContext.Current.Server.MapPath(".\\MailAttachments") + @"\" + dirName);
                DirectoryInfo objBanner = new DirectoryInfo(HttpContext.Current.Server.MapPath(".\\MailBanner") + @"\" + dirName);
                for (int j = 0; j < 3; j++)
                {
                    if (!dt.Rows[i]["Attachment" + (j + 1)].ToString().Trim().Equals(""))
                    {
                        filename[j] = dirName + @"\" + programid + @"\" + dt.Rows[i]["Attachment" + (j + 1)];
                    }
                    else
                    {
                        filename[j] = "";
                    }
                }
                if (!dt.Rows[i]["Banner"].ToString().Trim().Equals(""))
                {
                    bannerfile = objBanner + "/" + dt.Rows[i]["Banner"].ToString();
                }
                else
                {
                    bannerfile = "";
                }
              //  submitDate = "";
               
                try
                {
                    string cc="";
                    string bcc="";
                    SendMailFile sm = new SendMailFile();
                    sm.SendMailMultipleAttachmentBanner(from, to, cc, bcc, subject, msgText, filename, bannerfile);
                   // new SendMailMultipleAttachmentBanner(from, to, filename, msgText, subject, bannerfile, submitDate);
                }
                catch (Exception e)
                {
                    throw e;
                    continue;
                }

               UpdateParticipantStatus(participantid, JobID);
            }

        }
        catch (Exception e)
        {
            
        }

    }

    private DataTable GetUnsentMails()
    {
        BaseClass bs = new BaseClass();
        DataTable dt = new DataTable();
        string strSQL = "select  mt.jobid, tp.participantid participantId,tp.ProgramId,tp.EmailId,mj.[From],mj.Subject,mj.Message,mj.SubmitDate,mj.Banner,mj.MsgText,mj.Attachment1,mj.Attachment2,mj.Attachment3 from TIGAdmin_MsgToTable mt,TIGAdmin_participant tp,TIGAdmin_MsgJobTable mj where mt.status='0' and mt.participantid=tp.participantid and mj.jobid=mt.jobid and mj.JobStatus is null order by mj.SubmitDate desc";
        dt = bs.GetDataTable(strSQL,false);
        return dt;
    }

    private DataTable GetParticipantInfo(string participantid)
    {
        BaseClass bs = new BaseClass();
        DataTable dt = new DataTable();
        string sql = "select ParticipantId,EmailId,CompanyName,FirstName,LastName,MI,P.UserKey,(select FieldName from TigProgramField where ProgramFieldId=pr.userkey and ProgramId=P.programId ) UserKeyLabel from TigAdmin_participant P,TigAdmin_programTable Pr where p.programId=pr.programId and participantId='" + participantid + "'";
        dt = bs.GetDataTable(sql,false);
        return dt;

    }

    private string GetJobStatus(string JobID)
    {
        BaseClass bs = new BaseClass();
        DataTable dt = new DataTable();
        string sql = "select JobStatus from TIGMsgToTable jobid=" + JobID;
        dt = bs.GetDataTable(sql,false);
        string jobstatus = "";
        if (dt.Rows.Count > 0)
        {
            jobstatus = dt.Rows[0]["JobStatus"].ToString();
        }
        else
        {
            jobstatus = "";
        }
        return jobstatus;
    }
    private string ReplaceParticipantTags(DataTable dt, string msg)
    {
        Hashtable tagProp = new Hashtable();
        tagProp.Add("<#ParticpantFirstName#>", dt.Rows[0]["FirstName"].ToString());
        tagProp.Add("<#ParticipantLastName#>", dt.Rows[0]["LastName"].ToString());
        tagProp.Add("<#CompanyName#>", dt.Rows[0]["CompanyName"].ToString());
        tagProp.Add("<#UserKeyLabel#>", dt.Rows[0]["UserKeyLabel"].ToString());
        tagProp.Add("<#UserKey#>", dt.Rows[0]["UserKey"].ToString());
        msg = ConvertTagString(msg, tagProp);
        return msg;
    }
    private string ConvertTagString(string text, Hashtable tagProp)
    {
       // StringBuilder textBuffer = new StringBuilder(text);
        //for all element in that properties
        IDictionaryEnumerator en = tagProp.GetEnumerator();

        //Enum keys = tagProp.Keys();
        string key = "";
        string value = "";
        while (en.MoveNext())
        {
            key = (String)en.Key;
            value = (String)en.Value;
            text.Replace(key, value);
            
        }
        return text;
    }
    private void UpdateParticipantStatus(string participantid, string jobid)
    {
        BaseClass bs = new BaseClass();
        string updatequery = "update TIGAdmin_MsgToTable set status='1', sentDateTime=getDate() where participantid=" + participantid + "and JobId=" + jobid;
        bs.fnExecuteNonQuery(updatequery,false);
    }
}
