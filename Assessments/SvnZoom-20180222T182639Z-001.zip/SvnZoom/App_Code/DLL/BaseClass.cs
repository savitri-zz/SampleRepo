using System;
using System.Data; 
using System.Data.SqlClient; 
using System.Configuration;


	public class BaseClass
	{
		public BaseClass()
		{
			
		}
		
		public DataTable GetDataTable(string strSQL, bool IsMasterDB)
		{
			try
			{
				DataSet ObjDs = new DataSet();
                ObjDs = SqlHelper.ExecuteDataset(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL);           
				return ObjDs.Tables[0];
			}
			catch (Exception Ex)
			{
				  throw Ex; 
			}
		}

        public DataSet GetDataSet(string strSQL, bool IsMasterDB)
		{
			try
			{
				DataSet ObjDs = new DataSet();
                ObjDs = SqlHelper.ExecuteDataset(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL);           
				return ObjDs;
			}
			catch (Exception Ex)
			{
				throw Ex; 
			}
		}

        

        public string GetSingleValue(string strSQL, bool IsMasterDB)
		{
			try
			{
				Object tmpObj;
                tmpObj = SqlHelper.ExecuteScalar(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL);           
				if (tmpObj != null)				
					return tmpObj.ToString();
				else
					return "";
			}
			catch (Exception Ex)
			{
				throw Ex; 
			}
		}

        public int fnExecuteStatement(string strSQL, bool IsMasterDB)
		{
			try
			{
				int RowsAffected = 0;
                RowsAffected = SqlHelper.ExecuteNonQuery(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL);           
				return RowsAffected;			
			}
			catch (Exception Ex)
			{
				throw Ex; 
			}
		}

    public int fnExecuteScalar(string strSQL, bool IsMasterDB)
	{
		int RowsAffected = 0;
		try
		{
      if (SqlHelper.ExecuteScalar(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL) != null)
			{
        if(SqlHelper.ExecuteScalar(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL).ToString() != "")
        {
                RowsAffected = Convert.ToInt32(SqlHelper.ExecuteScalar(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL).ToString());           
        }
        else
        {
                RowsAffected  =0;
        }
			}
			else
			{
				RowsAffected = 0;
			}
			return RowsAffected;			
		}
		catch (Exception Ex)
		{
            throw Ex; 
		}
	}

        public object ExecuteScalar(string strSQL, bool IsMasterDB)
		{
			try
			{
                return SqlHelper.ExecuteScalar(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL);           
			}
			catch (Exception Ex)
			{
				throw Ex; 
			}
		}


        public SqlDataReader fnExecuteReader(string strSQL, bool IsMasterDB)
	    {
		    try
		    {
			    SqlDataReader ObjDr ;
                ObjDr = SqlHelper.ExecuteReader(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL);
			    return ObjDr;
		    }
		    catch (Exception Ex)
		    {
			    throw Ex; 
		    }
	    }
        public int fnExecuteNonQuery(string strSQL, bool IsMasterDB)
		{
			try
			{
                int i = SqlHelper.ExecuteNonQuery(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL);
				return i;
			}
			catch (Exception Ex)
			{
				throw Ex; 
			}
		}


        public int fnRunProcedure(string strProcedureName, string[] arrParamList, string[] arrParamValues, bool IsMasterDB)
        {
            try
            {
                if (arrParamList.Length != arrParamValues.Length)
                {
                    throw new Exception("Parameter List & Parameter Values are not Same in Length - Error From fnRunProcedure() fiunction of BaseClass");  
                }

                SqlParameter[] parm = new SqlParameter[arrParamList.Length]; 
                int i;

                for (i = 0; i < arrParamList.Length; i++)
                {
                    parm[i] = new SqlParameter(arrParamList[i] ,arrParamValues[i]);
                }

                i = SqlHelper.ExecuteNonQuery(CommonSetting.GetConnectionString(IsMasterDB) , CommandType.StoredProcedure, strProcedureName , parm);
                return i;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        public DataTable fnRunProcedureDatatable(string strProcedureName, string[] arrParamList, string[] arrParamValues, bool IsMasterDB)
        {
            try
            {
                DataSet ObjDs = new DataSet();
                if (arrParamList.Length != arrParamValues.Length)
                {
                    throw new Exception("Parameter List & Parameter Values are not Same in Length - Error From fnRunProcedure() fiunction of BaseClass");
                }

                SqlParameter[] parm = new SqlParameter[arrParamList.Length];
                int i;

                for (i = 0; i < arrParamList.Length; i++)
                {
                    parm[i] = new SqlParameter(arrParamList[i], arrParamValues[i]);
                }

                ObjDs = SqlHelper.ExecuteDataset(CommonSetting.GetConnectionString(IsMasterDB), CommandType.StoredProcedure, strProcedureName, parm);
                return ObjDs.Tables[0];
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        
        public void UpdateDataSet(string strSql, ref  DataSet dsDataset, string strTableName, bool IsMasterDB) 
		{                                                                                                                                                                             
			if (strTableName.Trim()== "")
			{     
				Exception ex=new Exception("Invalid Table");
                throw (ex);       
			}
 			//DataSet ds = new DataSet();
            SqlConnection cnCon = new SqlConnection(CommonSetting.GetConnectionString(IsMasterDB));
			cnCon.Open();
			SqlCommand Objcommand = cnCon.CreateCommand();
			SqlTransaction ObjTransaction;                  
			SqlDataAdapter da = new SqlDataAdapter();
			ObjTransaction = cnCon.BeginTransaction();
			
            try
			{
                Objcommand.Transaction = ObjTransaction;
                Objcommand.Connection =cnCon;
				Objcommand.CommandText = strSql;
				da.SelectCommand = Objcommand ;

                SqlCommandBuilder objcb = new SqlCommandBuilder(da);
				da.Update(dsDataset, strTableName);
				ObjTransaction.Commit();                        

				cnCon.Close(); 
			}
			catch 
			{
				try
				{
					dsDataset.RejectChanges(); 
    				ObjTransaction.Rollback();
    			}
                catch 
                {
                }
			}
			finally 
			{                                               
				cnCon.Close();
			}
		}

        protected int fnExecuteTransaction(SqlConnection mySQLConn, SqlTransaction myTrans, string strSQL)
        {
            try
            {
                SqlCommand objCmd = new SqlCommand(strSQL, mySQLConn, myTrans);
                return objCmd.ExecuteNonQuery(); 
            }
            catch (Exception Ex)
            {
                throw Ex; 
            }
        }

        public void fnInsertBulkCopy(DataTable dt, string SQLQuery, bool IsMasterDB)
        {
            try
            {
                SqlConnection cnCon = new SqlConnection(CommonSetting.GetConnectionString(IsMasterDB));
                using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(cnCon))
                {
                    DataSet dsDataset = new DataSet();
                    //Set the database table name
                    sqlBulkCopy.DestinationTableName = "tbl_Role_Screen_Permssion";
                    //UpdateDataSet(SQLQuery, ref dsDataset, "tbl_Role_Screen_Permssion", true );

                    using (SqlCommand cmd = new SqlCommand(SQLQuery, cnCon))
                    {
                        cnCon.Open();
                        cmd.ExecuteNonQuery();
                    }

                    //[OPTIONAL]: Map the DataTable columns with that of the database table
                    sqlBulkCopy.ColumnMappings.Add("RoleID", "RoleID");
                    sqlBulkCopy.ColumnMappings.Add("ScreenName", "ScreenName");
                    sqlBulkCopy.ColumnMappings.Add("PermissionID", "PermissionID");
                    sqlBulkCopy.WriteToServer(dt);
                    cnCon.Close();
                }
                //int i = SqlHelper.ExecuteNonQuery(CommonSetting.GetConnectionString(IsMasterDB), CommandType.Text, strSQL);
                //return i;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }

            //using (SqlConnection con = new SqlConnection(consString))
            //{
            //    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
            //    {
            //        //Set the database table name
            //        sqlBulkCopy.DestinationTableName = "dbo.Customers";

            //        //[OPTIONAL]: Map the DataTable columns with that of the database table
            //        sqlBulkCopy.ColumnMappings.Add("Id", "CustomerId");
            //        sqlBulkCopy.ColumnMappings.Add("Name", "Name");
            //        sqlBulkCopy.ColumnMappings.Add("Country", "Country");
            //        con.Open();
            //        sqlBulkCopy.WriteToServer(dt);
            //        con.Close();
            //    }
            //}
        }

	}

