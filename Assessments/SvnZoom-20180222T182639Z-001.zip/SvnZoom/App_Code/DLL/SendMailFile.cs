using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using System.Net.Mime;

/// <summary>
/// Summary description for SendMail
/// </summary>
public class SendMailFile
{
    public string hostname;
    public SendMailFile()
	{
		//
		// TODO: Add constructor logic here
		//
        hostname = CommonSetting.smtphost.ToString();
	}

    public void SendingMail(string from, string to, string subject, string body)
    {
        try
        {
            hostname = CommonSetting.smtphost.ToString();
            SmtpClient smtpMailObj = new SmtpClient();
            smtpMailObj.Host = hostname;
            smtpMailObj.Send(from, to, subject, body);
           // Response.Write("Your Message has been sent successfully");
        }
        catch (Exception Ex)
        {

            throw Ex;
            
        }
    }

    public void SendmailMailMessage(string from, string to, string subject, string body)
    {
        MailMessage Mail = new MailMessage();

        MailAddress ma = new MailAddress(from);
        Mail.From = ma;
        Mail.To.Add(to);

        Mail.Subject = subject;

        Mail.Body = body;

        try
        {
            SmtpClient smtpMailObj = new SmtpClient();
            hostname = CommonSetting.smtphost.ToString();
            smtpMailObj.Host = hostname;
            smtpMailObj.Send(Mail);
          //  Response.Write("Your Message has been sent successfully");
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public void SendMailwithCCBCC(string from, string to, string cc, string bcc, string subject, string body)
    {
               
        MailMessage Mail = new MailMessage();
        MailAddress ma = new MailAddress(from);
        Mail.From = ma;
        Mail.To.Add(to);


        if (cc.Trim().Length != 0)
            Mail.CC.Add(cc);

        if (bcc.Trim().Length != 0)
            Mail.Bcc.Add(bcc);

        Mail.Subject = subject;

        Mail.Body = body;

        try
        {
            SmtpClient smtpMailObj = new SmtpClient();
            hostname = CommonSetting.smtphost.ToString();
            smtpMailObj.Host = hostname;
            smtpMailObj.Send(Mail);
           // Response.Write("Your Message has been sent successfully");
        }
        catch (Exception Ex)
        {

            throw Ex;

        }

    }

    public void SendMailHTMLOutput(string from, string to, string subject, string body)
    {
        //MailMessage Mail = new MailMessage();
        //MailAddress ma = new MailAddress(from);
        //Mail.From = ma;
        //Mail.To.Add(to);

        //Mail.Subject = subject;

        //Mail.IsBodyHtml = true;
        //Mail.Body = body;

        try
        {
            //SmtpClient smtpMailObj = new SmtpClient();
            //hostname = CommonSetting.smtphost.ToString();
            //smtpMailObj.Host = hostname;
            //smtpMailObj.Send(Mail);
           // Response.Write("Your Message has been sent successfully");

            MailMessage mail = new MailMessage();
            mail.To.Add(to);

            mail.From = new MailAddress(from);
            mail.Subject = subject;

            string Body = body;
            mail.Body = Body;

            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            //smtp.Host = "win1.hostgator.in";
            //smtp.Credentials = new System.Net.NetworkCredential("info@mfloat.in", "Mfloat@1234");

            string SMTP_HOST = System.Configuration.ConfigurationManager.AppSettings["SMTP_HOST"].ToString();
            string SMTP_PORT = System.Configuration.ConfigurationManager.AppSettings["SMTP_PORT"].ToString();
            string INFO_MAIL_UID = System.Configuration.ConfigurationManager.AppSettings["INFO_MAIL_UID"].ToString();
            string INFO_MAIL_PWD = System.Configuration.ConfigurationManager.AppSettings["INFO_MAIL_PWD"].ToString();

            smtp.Host = SMTP_HOST;
            smtp.Credentials = new System.Net.NetworkCredential(INFO_MAIL_UID, INFO_MAIL_PWD);
            smtp.Port = Convert.ToInt32(SMTP_PORT);

            string sIsDebugMode = System.Configuration.ConfigurationManager.AppSettings["IsDebugMode"].ToString();

            if (sIsDebugMode == "true")
            {
                return ;
            }

            smtp.Send(mail);

            mail.Dispose();

        }
        catch (Exception Ex)
        {

            throw Ex;

        }

          
    }

    public void SendMailHTMLOutput(string from, string to, string subject, MailMessage body)
    {
        // overloading method.
        try
        {   
            //body.To.Add(to);
            body.From = new MailAddress(from);
            body.Subject = subject;
            body.To.Add(to);
            body.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            //smtp.Host = "win1.hostgator.in";
            //smtp.Credentials = new System.Net.NetworkCredential("info@mfloat.in", "Mfloat@1234");

            string SMTP_HOST = System.Configuration.ConfigurationManager.AppSettings["SMTP_HOST"].ToString();
            string SMTP_PORT = System.Configuration.ConfigurationManager.AppSettings["SMTP_PORT"].ToString();
            string INFO_MAIL_UID = System.Configuration.ConfigurationManager.AppSettings["INFO_MAIL_UID"].ToString();
            string INFO_MAIL_PWD = System.Configuration.ConfigurationManager.AppSettings["INFO_MAIL_PWD"].ToString();

            smtp.Host = SMTP_HOST;
            smtp.Credentials = new System.Net.NetworkCredential(INFO_MAIL_UID, INFO_MAIL_PWD);
            smtp.Port = Convert.ToInt32(SMTP_PORT);

            string sIsDebugMode = System.Configuration.ConfigurationManager.AppSettings["IsDebugMode"].ToString();

            if (sIsDebugMode == "true")
            {
                return;
            }

            smtp.Send(body);

            
            //smtp.Host = "mail.mfloat.in";
            //smtp.Credentials = new System.Net.NetworkCredential
            //     ("somagangaraju@gmail.com", "ganga@7722");
            //smtp.Port = int.Parse(ConfigurationManager.AppSettings["Port"]);

        }
        catch (Exception Ex)
        {

            throw Ex;

        }


    }
    public void SendMailCCBCCHTMLOutput(string from, string to, string cc, string bcc, string subject, string body)
    {
        MailMessage Mail = new MailMessage();
        MailAddress ma = new MailAddress(from);
        Mail.From = ma;
        Mail.To.Add(to);


        if (cc.Trim().Length != 0)
            Mail.CC.Add(cc);

        if (bcc.Trim().Length != 0)
            Mail.Bcc.Add(bcc);

        Mail.Subject = subject;

        Mail.IsBodyHtml = true;
        Mail.Body = body;

        try
        {
            SmtpClient smtpMailObj = new SmtpClient();
            hostname = CommonSetting.smtphost.ToString();
            smtpMailObj.Host = hostname;
            smtpMailObj.Send(Mail);
           // Response.Write("Your Message has been sent successfully");
        }
        catch (Exception Ex)
        {

            throw Ex;

        }


    }

    public void SendMailAttachment(string from, string to, string cc, string bcc, string subject, string body, string attachment)
    {
        MailMessage Mail = new MailMessage();
        MailAddress ma = new MailAddress(from);
        Mail.From = ma;
        Mail.To.Add(to);


        if (cc.Trim().Length != 0)
            Mail.CC.Add(cc);

        if (bcc.Trim().Length != 0)
            Mail.Bcc.Add(bcc);

        Mail.Subject = subject;


        if (attachment.Length != 0)
        {
            string sAttach = attachment.Replace("\\", "\\\\");
            Mail.Attachments.Add(new Attachment(sAttach));
        }


        Mail.IsBodyHtml = true;
        Mail.Body = body;

        try
        {
            SmtpClient smtpMailObj = new SmtpClient();
            hostname = CommonSetting.smtphost.ToString();
            smtpMailObj.Host = hostname;
            smtpMailObj.Send(Mail);
            //Response.Write("Your Message has been sent successfully");
        }
        catch (Exception Ex)
        {

            throw Ex;

        }


    }


    public void SendMailMultipleAttachment(string from, string to, string cc, string bcc, string subject, string body, string[] attachment)
    {
        MailMessage Mail = new MailMessage();
        MailAddress ma = new MailAddress(from);
        Mail.From = ma;
        Mail.To.Add(to);


        if (cc.Trim().Length != 0)
            Mail.CC.Add(cc);

        if (bcc.Trim().Length != 0)
            Mail.Bcc.Add(bcc);

        Mail.Subject = subject;


        if (attachment.Length != 0)
        {
            for (int i = 0; i < attachment.Length; i++)
            {
                string sAttach = attachment[i].Replace("\\", "\\\\");
                Mail.Attachments.Add(new Attachment(sAttach));
            }
        }


        Mail.IsBodyHtml = true;
        Mail.Body = body;

        try
        {
            SmtpClient smtpMailObj = new SmtpClient();
            hostname = CommonSetting.smtphost.ToString();
            smtpMailObj.Host = hostname;
            smtpMailObj.Send(Mail);
            //Response.Write("Your Message has been sent successfully");
        }
        catch (Exception Ex)
        {

            throw Ex;

        }


    }

    public void SendMailMultipleAttachmentBanner(string from, string to, string cc, string bcc, string subject, string body, string[] attachment, string banner)
    {
        MailMessage Mail = new MailMessage();
        MailAddress ma = new MailAddress(from);
        Mail.From = ma;
        Mail.To.Add(to);


        if (cc.Trim().Length != 0)
            Mail.CC.Add(cc);

        if (bcc.Trim().Length != 0)
            Mail.Bcc.Add(bcc);

        Mail.Subject = subject;
        

       
       

        Mail.IsBodyHtml = true;
        Mail.Body = body;
        
        string htmlimage = "";
        if (banner.Length != 0)
        {
            if (banner.Trim().Equals(""))
            {
                htmlimage = "<img src=" + banner + ">";
                Mail.Headers.Add("Content-ID", htmlimage);
            }
        }


        if (attachment.Length != 0)
        {
            for (int i = 0; i < attachment.Length; i++)
            {
                string sAttach = attachment[i].Replace("\\", "\\\\");
                Mail.Attachments.Add(new Attachment(sAttach));
            }
        }


       
        try
        {
            SmtpClient smtpMailObj = new SmtpClient();
            hostname = CommonSetting.smtphost.ToString();
            smtpMailObj.Host = hostname;
            smtpMailObj.Send(Mail);
            //Response.Write("Your Message has been sent successfully");
        }
        catch (Exception Ex)
        {

            throw Ex;

        }  
        
    }





    public void SendMailFromEvent(string from, string to, string subject, string body)
    {
        try
        {

            MailMessage mail = new MailMessage();
            mail.To.Add(to);

            mail.From = new MailAddress(from);
            mail.Subject = subject;

            string Body = body;
            mail.Body = Body;

            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();


            //smtp.Host = "win1.hostgator.in";
            //smtp.Credentials = new System.Net.NetworkCredential("event.affiliates@mfloat.in", "Mfloat@1234");

            string SMTP_HOST = System.Configuration.ConfigurationManager.AppSettings["SMTP_HOST"].ToString();
            string SMTP_PORT = System.Configuration.ConfigurationManager.AppSettings["SMTP_PORT"].ToString();
            string EVENT_MAIL_UID = System.Configuration.ConfigurationManager.AppSettings["EVENT_MAIL_UID"].ToString();
            string EVENT_MAIL_PWD = System.Configuration.ConfigurationManager.AppSettings["EVENT_MAIL_PWD"].ToString();

            smtp.Host = SMTP_HOST;
            smtp.Credentials = new System.Net.NetworkCredential(EVENT_MAIL_UID, EVENT_MAIL_PWD);
            smtp.Port = Convert.ToInt32(SMTP_PORT);

            string sIsDebugMode = System.Configuration.ConfigurationManager.AppSettings["IsDebugMode"].ToString();

            if (sIsDebugMode == "true")
            {
                return;
            }

            smtp.Send(mail);
        }
        catch (Exception Ex)
        {

            throw Ex;

        }


    }

}
