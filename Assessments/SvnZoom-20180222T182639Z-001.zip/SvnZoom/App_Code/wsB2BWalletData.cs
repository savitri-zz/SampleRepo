﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Text;
using System.Web.Script.Services;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.ServiceModel.Web;
using System.Web.Script.Services;
using System.Globalization;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for WebService1
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.ComponentModel.ToolboxItem(false)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class wsB2BWalletData : System.Web.Services.WebService
{


   
    public class WalletUser
    {
        public string TRANSACTIONID { get; set; }
        public string AMOUNT { get; set; }
        public string STATUS { get; set; }

    }


   

    public static int ToInt(string toParse)
    {
        int result;
        if (int.TryParse(toParse, out result)) return result;
        return result;
    }

    public class ClientUser
    {
        public string EMAILID { get; set; }
        public string MOBILENO { get; set; }
        public string USERID { get; set; }
        public string NAME { get; set; }
        public string STATUS { get; set; }

    }


    //4/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////4//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string validateWalletDetails(string emailId, string password, string amount, string transid, string btnid, string apikey, string apipwd)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str1"].ToString(); ;
        EncryptDecryptQueryString objEncrypt = new EncryptDecryptQueryString();
  
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            try
            {
                //connection.Open();
                //Transaction = connection.BeginTransaction();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            string commandNAME = "USP_DEDUCT_WALLET_AMOUNT";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@EMAIL_ID", emailId);
            command.Parameters.AddWithValue("@WALLET_PASSWORD", password);
            command.Parameters.AddWithValue("@REQUESTED_AMOUNT", ToInt(amount));
            // command.Parameters.AddWithValue("@TRANSACTION_ID", transid1);
            command.Parameters.AddWithValue("@OTHER_APP_TRANSACTION_ID", transid);

            //string btn = objEncrypt.Decrypt(btnid, "r0b1nr0y").ToString();
            //string key = objEncrypt.Decrypt(apikey, "r0b1nr0y").ToString();
            //string pwd = objEncrypt.Decrypt(apipwd, "r0b1nr0y").ToString();
            //command.Parameters.AddWithValue("@BUTTON_ID", btn);
            //command.Parameters.AddWithValue("@API_WALLET_KEY", key);
            //command.Parameters.AddWithValue("@API_WALLET_PASSWORD", pwd);

            
            command.Parameters.AddWithValue("@BUTTON_ID", objEncrypt.Decrypt(btnid, "r0b1nr0y"));
            command.Parameters.AddWithValue("@API_WALLET_KEY", objEncrypt.Decrypt(apikey, "r0b1nr0y"));
            command.Parameters.AddWithValue("@API_WALLET_PASSWORD", objEncrypt.Decrypt(apipwd, "r0b1nr0y"));

            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            //Transaction = connection.BeginTransaction();
            //command.Transaction = Transaction;
            command.Parameters.Add("@SUCCESS_MSG", SqlDbType.VarChar, 100); 
            command.Parameters["@SUCCESS_MSG"].Direction = ParameterDirection.Output;
            string retunvalue = "";
            string outputJson = string.Empty;
            using (SqlDataReader reader = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@SUCCESS_MSG"].Value;

                string amnt = string.Empty;
                string trasid = string.Empty;
                string status = string.Empty;
                if (retunvalue.ToUpper().Trim().Contains("INVALID CREDENTIALS"))
                {
                    amnt = "";
                    status = "INVALID CREDENTIALS";
                    trasid = "";

                }
                else if (retunvalue.ToUpper().Trim().Contains("INVALID REQUESTED AMOUNT"))
                {
                    amnt = "";
                    status = "INVALID REQUESTED AMOUNT";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("INSUFFICIENT AMOUNT"))
                {
                    string[] result = retunvalue.ToUpper().Split(':');
                    amnt = result[1].ToString();
                    status = "INSUFFICIENT AMOUNT";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    amnt = "";
                    status = "SUCCESS";
                    string[] result = retunvalue.ToUpper().Split(';');
                    trasid = result[1].ToString();
                }
                else if (retunvalue.ToUpper().Trim().Contains("ERROR"))
                {
                    amnt = "";
                    status = "NETWORK ERROR";
                    trasid = "";
                }
                else if (retunvalue.ToUpper().Trim().Contains("Duplicate"))
                {
                    amnt = "";
                    status = retunvalue;
                    trasid = "";
                }
                else 
                {
                    amnt = "";
                    status = retunvalue;
                    trasid = "";
                }


                WalletUser response = new WalletUser
                {
                    TRANSACTIONID = trasid,
                    AMOUNT = amnt,
                    STATUS = status
                };
                var javaScriptSerializer = new JavaScriptSerializer();
                outputJson = javaScriptSerializer.Serialize(response);

                return outputJson;
            }

        }

    }



    //4/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////4//


    //5/////////////////////Start/////////////////////////Savitri/////////////////////////////Start/////////////////5//
    [WebMethod]
    // [ScriptMethod(UseHttpGet = true)]
    [WebInvoke(ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, Method = "POST")]

    public string getUserDetails(string emailId, string password, string apikey, string apipwd)
    {
        //SqlTransaction Transaction = null;
        var sb = new StringBuilder();
        string connectionString = System.Configuration.ConfigurationSettings.AppSettings["conn_str1"].ToString(); ;
        EncryptDecryptQueryString objEncrypt = new EncryptDecryptQueryString();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            try
            {
                //connection.Open();
                //Transaction = connection.BeginTransaction();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            string commandNAME = "USP_GET_USER_DETAILS";
            SqlCommand command = new SqlCommand(commandNAME, connection);


            command.Parameters.AddWithValue("@EMAIL_ID", emailId);
            command.Parameters.AddWithValue("@USER_PASSWORD", password);
            command.Parameters.AddWithValue("@API_USER_KEY", objEncrypt.Decrypt(apikey, "r0b1nr0y"));
            command.Parameters.AddWithValue("@API_USER_PASSWORD", objEncrypt.Decrypt(apipwd, "r0b1nr0y"));

            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();


            command.Parameters.Add("@RETURN_STRING", SqlDbType.VarChar, 100);
            command.Parameters["@RETURN_STRING"].Direction = ParameterDirection.Output;

            string retunvalue = "";
            string outputJson = string.Empty;
            using (
                SqlDataReader reader = command.ExecuteReader())
            {
                retunvalue = (string)command.Parameters["@RETURN_STRING"].Value;

                string emailid = string.Empty;
                string name = string.Empty;
                string mobileno = string.Empty;
                string userid = string.Empty;
                string status = string.Empty;

                if (retunvalue.ToUpper().Trim().Contains("SUCCESS"))
                {
                    string[] result = retunvalue.ToUpper().Split(';');
                    mobileno = result[0].ToString();
                    name = result[1].ToString();
                    emailid = result[2].ToString();
                    userid = result[3].ToString();
                    status = result[4].ToString();
                }
                else if (retunvalue.ToUpper().Trim().Contains("INVALID CREDENTIALS"))
                {
                    status = "INVALID CREDENTIALS";
                }
                else if (retunvalue.ToUpper().Trim().Contains("MERCHANT NOT AVAILABLE"))
                {
                    status = "MERCHANT NOT AVAILABLE";
                }
                else if (retunvalue.ToUpper().Trim().Contains("SERVICE NOT AVAILABLE"))
                {
                    status = "SERVICE NOT AVAILABLE";
                }
                else
                {
                    status = retunvalue;
                }


                ClientUser response = new ClientUser
                {
                    EMAILID = emailid,
                    MOBILENO = mobileno,
                    USERID = userid,
                    NAME= name,
                    STATUS = status
                };
                var javaScriptSerializer = new JavaScriptSerializer();
                outputJson = javaScriptSerializer.Serialize(response);

                return outputJson;
            }

        }

    }

    //5/////////////////////end/////////////////////////Savitri/////////////////////////////end/////////////////5//

   

}
