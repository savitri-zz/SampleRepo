﻿/// <reference path="jquery-1.11.1.min.js" />
$(document).ready(function () { });


$(function pageLoad() {
    $('.news_tabs li').click(function () {
        alert(www);
        $(this).addClass('NewsTabSelected');
        $(this).siblings().removeClass('NewsTabSelected');
        var DivClassToDisplay = $(this).attr('id');
        $('.news_ul').removeClass('display');
        $('.' + DivClassToDisplay).addClass('display');
    });

    /*$('.LnkReadmore').click(function () {

    $news_slider = $(this).parent().parent('.news_item').next('.news_slider_div');

    $news_slider.slideToggle()

    $(".news_slider_div").not($news_slider).slideUp();

    $news_slider_head = $(this).parent().parent('.news_item');

    $news_slider_head.slideToggle()

    $(".news_item").not($news_slider_head).slideDown();

    });

    $('.dv_head_news').click(function () {
    $(this).parent().parent('.news_slider_div').prev('.news_item').slideToggle();
    $(this).parent().parent('.news_slider_div').slideToggle();
    });

    //            $('.SpnNewsTitle').each(function () {
    //                if ($(this).text().trim().length > 40) {
    //                    $(this).text($(this).text().trim().substr(0, 40) + '..');
    //                }
    //            });
    */



    //----------- TabSeletction based on page loaded
    /*
    A hidden field '.TabToHighlight' is placed in every childpage and its value
    should be 'id' of li element in masterpage
    */

    $('.tooltip').hover(function () {
        $(this).append('<p class="pop_tool pos_absolute fnt-sm br3"><img src="images/icons/icon_top_arrow.png" class="DvMiddle" style="top: -25px;">' + $(this).attr('data-title') + '</p>');
        $('.pop_tool', this).addClass('nowrap').css('left', "-" + ($('.pop_tool', this).outerWidth() - $(this).width()) / 2 + "px");

    }, function () {
        $('.pop_tool').remove();
    });

    $('.news_tabs > li#' + $('.TabToHighlight').val()).addClass('NewsTabSelected');
    //----------- End of Tabselection

    $('.SpnPageType').each(function () {
        if ($(this).text() == "") {
            $($(this).prev('p')).hide();
        }

    });

    $('.SpnNewsDescr').each(function () {
        if ($(this).text().trim().length > 110) {
            $(this).text($(this).text().trim().substr(0, 110) + '..');
        }
    });


    $('.item_title').click(function () {
        $('.popup_wrapper').slideDown();
        $('body').css('overflow-y', 'hidden');
        $('.news_slider_div').scrollTop(0); 
        var $DivNews = $(this).parents().eq(2);
        $('.LnkFullPage').attr('href', $('.HdnLnkFullPage', $DivNews).text());
        $('.Spn_FullTitle').text($('.item_title', $DivNews).text());
        $('.Spn_FullPubDetails').text($('.item_pub', $DivNews).text());
        // $('.dv_Descr_news').html($('.item_des', $DivNews).text());
        $('.dv_Descr_news').html($('.hdnFullDes', $DivNews).val());

        $('.dv_Descr_news a').each(function () {
            $('.dv_Descr_news a').removeAttr('href');
        });
    });

    $(window).resize(function () {
        if ($(window).width() < 960) {
            $('.popup_wrapper').css({ 'position': 'absolute', 'height': $(document).height() });
            $('body').css('overflow-y', 'auto');
        }
        else {
            $('.popup_wrapper').css({ 'position': 'fixed', 'height': $(window).height() });
            //$('body').css('overflow-y', 'hidden');
        }
    });
    $(document).keyup(function (r) {
        if (r.keyCode = 27) { $('.popup_wrapper').slideUp(); $('body').css('overflow-y', 'auto'); }
    });
    $('.popup_wrapper').click(function (g) {
        $(this).slideUp();
        $('body').css('overflow-y', 'auto');
    });
    $('.subcontainerPop').click(function (g) {
        g.stopPropagation();
    });


    $('.news_slider_div').scroll(function () {

        var scroll = $('.news_slider_div').scrollTop();

        if (scroll >= 20) {
            $('.dv_head_news').addClass('absolute');
            $('.dv_sub_head_news').addClass('addmargin');
            $('.Spn_FullTitle').removeClass('fnt-xlg').addClass('fnt-15');
        } else {
            $('.dv_head_news').removeClass('absolute');
            $('.dv_sub_head_news').removeClass('addmargin');
            $('.Spn_FullTitle').removeClass('fnt-15').addClass('fnt-xlg');
        }
    });

    $('.dvclose').click(function () {
        $('.popup_wrapper').slideUp();
        $('body').css('overflow-y', 'auto');
    });

    $('.play_area>iframe').addClass('DvMiddle');
    $('.rel_games_holder img').click(function () {
        $('.play_area').html("");
        $('.play_area').append($(this).attr('data-Iframe'));
        $('.play_area>iframe').addClass('DvMiddle');
        $('.GameName').text($(this).attr('data-title'));
        $('.GameDescr>p').text($(this).attr('data-description'));
    });
    $('.propercase').each(function () {
        //var id = document.getElementById('txt_fname');
        var name = $(this).text();
        //alert(name);
        var value = toTitleCase(name);
        //alert(value);
        $(this).text(value);
    });
    $('.propercase-datatitle').each(function () {
        var name = $(this).attr('data-title');
        var value = toTitleCase(name);
        $(this).attr('data-title', value);
    });
    function toTitleCase(str) {
        return str.replace(/\w\S*/g, function (txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
    }
});