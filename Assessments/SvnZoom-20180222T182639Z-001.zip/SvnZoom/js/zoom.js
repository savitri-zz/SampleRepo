$(document).ready(function (){

    $('.small_contentdiv ul li').click(function(){

        var $parent=$(this).parent('.small_contentdiv');
        var $prent_prev=$parent.prev('.big_contentdiv');

        var x= $('.sm_img', this).attr('src');
        $('.big_content_ul').find('.big_image').attr('src', x );

        $('.big_heading').text($('.smaller_heading', this).text());
        $('.big_detail_cont').text($('.fullcontent', this).text());

    });

    $(".smaller_heading").click(function() {

        var $parent=$(this).parent('.small_contentdiv');

        $(".smaller_heading").removeClass("active");

        $( this, $parent).addClass("active");

    });

    /* $('.popup_wrapper, .pd_popup_main_div, .bg_wrapper ').css('height', $(document).height());*/

    $('.popup_wrapper, .bg_wrapper ').css('height', $(document).height());

    $('.slider_relative').css('height', $(window).height());

    /* popup script */
    $('.item_title').click(function(){
        $('.bg_wrapper').show();
        $('.popup_wrapper').show();
        $('.Popup_Cart').fadeIn(500, function () {
            $('.pd_popup_main_div').css('right', '0px').css('transition','right 0.3s linear 0s');
            $('body').css('overflow', 'hidden');
        });

        $('.slider_relative').scrollTop(0);
    });

    $('.close_popup, .back').click(function () {
        $('.bg_wrapper').hide();

        $('.pd_popup_main_div').css('right', '-800px').css('transition','right 0.3s linear 0s');
        $('.popup_wrapper').fadeOut(500);
        $('body').css('overflow-y', 'scroll');

    });


  /*  $(window).scroll( function(){

        var scroll = $(window).scrollTop();
        if (scroll >= 200) {

            $('.inner_rightside_div').css('position','fixed').css('top', '120px');

        } else {
            $('.inner_rightside_div').css('position','relative').css('top', '0px');

        }
    });*/

    /* side menu script*/

    function menu_effect()
    {

        var noOfList = $('.menu_items_div ul li').length;
        var i;

        for (i = 1; i <= noOfList; i++) {
            $('.menu_items_div ul > li:nth-child(' + i + ')').css('transition-delay', '0.' + (i - 1) + 's');
        }
    }

    //$('.menu_items_div ul > li').css('height', (100 / noOfList) + '%');


    $('.inner_menu_icon_div, .sm_menu_icon').click(function () {
        $('.menu_items_div').toggleClass('open');

        menu_effect();

        return false;
    });

    $(window).scroll( function(){

        var winscroll = $(window).scrollTop();

        if(winscroll >= 131){
            $('.hidden_icons').fadeIn(200);
            $('.menu_items_div ul').css('position','fixed').css('top', '111px');

        }else{

            $('.hidden_icons').fadeOut(200);
            $('.menu_items_div ul').css('position','relative').css('top', '0px');
        }

    });


    $(document).click(function () {

        $('.menu_items_div').removeClass('open');

    });



    /* popup scrolling script */
    $('.slider_relative').scroll(function() {

        var scroll = $('.slider_relative').scrollTop();

        if (scroll >= 100) {
            var $title=$('.content_title', '.slider_content').text();
            $('.smaller_title').text($title);
            $(".smaller_header").fadeIn(200);
            $('.popup_header').css('border-bottom', '1px solid #E6E6E6');
            $('.top_arrow').css('display','block');
        }else{
            $(".smaller_header").fadeOut(200);
            $('.popup_header').css('border-bottom', '0');
            $('.top_arrow').css('display','none');
        }

    });

    $('.top_arrow').click( function(){
        $('.slider_relative').animate({ scrollTop: 0 }, 500);
    });

    /* end popup*/


    $('.bg_theam_items').click( function(){

        var color= $(this).attr('data_value');
        $('.coverph_div').css('background', color);
    });

    /* slider script */
    var totalnoofslides = $('.slider_content').length;   //To get total no.of slides
    /* Calculating size of each slide and by adding its width,margin,border*2 */
    var slideshidden = totalnoofslides - "1";    //4 is the no of slides displaying
    var width_of_eachslide = $('.slider_content').css('width').replace("px", "");
    var marginright_of_eachslide = $('.slider_content').css('margin-right').replace("px", "");

    var border_of_eachslide = $('.slider_content').css('borderWidth').replace("px", "");
    var major_width_of_slide = Number(width_of_eachslide) + Number(marginright_of_eachslide) + Number(2 * border_of_eachslide);
    /* End of calculation */
    /* Assigning left value for container to show 4 slides and hide remaining */
    var totwidth = totalnoofslides * major_width_of_slide;
    var left = "-" + slideshidden * major_width_of_slide + "px";
    $(".slider_absolute").css('left', left).css('width', totwidth);
    /* End of assigning */
    var slider = 0;

    $('.slider_right_arrow').click(function () {

        if (slider != totalnoofslides - 1) {

            $('.slider_absolute').animate({ left: '+=' + major_width_of_slide + 'px' });
            slider++;

            var $title=$('.content_title', '.slider_content').text();
            $('.smaller_title').text($title);
        }
    });

    $('.slider_left_arrow').click(function () {

        if (slider != 0) {

            $('.slider_absolute').animate({ left: '-=' + major_width_of_slide + 'px' });
            slider--;

            var $title=$('.content_title', '.slider_content').text();
            $('.smaller_title').text($title);
        }
    });

    /* end slider script */

    /*ads popup */

    $('.bigsize_ad_div, .smallersize_ad_div').click(function () {
        $('body').css('overflow', 'hidden');
        $('.slider_top').slideDown(1000);

        image_length();
    });

    $('.close_button').click(function (){
        $('.slider_top').slideUp(1000);
        $('body').css('overflow', 'auto');
    });

    $('.sm_pr_img').click(function(){
        var sm_img=$(this).attr('src');
        $('#Image_popup').attr('src', sm_img);
        image_length();
    });

    function image_length(){

        $('.dvMiddle img').each(function () {
            //--- To make this fallow "<div><a><img/></a></div>" format----
            var height_container = $(this).parent().parent().css('height').replace('px', '');
            var height = $(this).css('height').replace('px', '');
            var diff = (Number(height_container) - Number(height)) / 2;
            if (height > 0) {
                $(this).css('margin-top', diff);
                $(this).fadeIn(500);
            }
        });

    }


    $('.viewdetails').click(function (e) {
        /*alert($(this).attr('target'));*/
        $('.dvpopcontainer').css('display', 'block');
        $('.dvpopcontainer').delay(4000).fadeOut(100,function() {
            var url = "http://www.flipkart.com/";
            window.open(url,'_blank');
        });
    });

   /* $('#userimg').click(function(){
        $('.pf_img_slider').css('display', 'block');
        $('body').css('overflow', 'hidden');
        image_length();
    });
*/
    $('.close_pfimg').click( function() {
        $('.pf_img_slider').css('display', 'none');
        $('body').css('overflow', 'auto');
    });


    $('.tumb_img').click(function(){
        var tum= $(this).attr('src').replace('pf_thumbnail','pf_originail');
        $('.pfimg_largesize').attr('src',tum);
        image_length();

    });


});


$(document).keyup(function (e) {
    if (e.keyCode == 27) {
        $('.bg_wrapper').hide();
        $('.pd_popup_main_div').css('right', '-924px').css('transition','right 0.3s linear 0s');
        $('.popup_wrapper').delay(400).fadeOut();
        $('body').css('overflow', 'scroll');

    }   // esc
});
